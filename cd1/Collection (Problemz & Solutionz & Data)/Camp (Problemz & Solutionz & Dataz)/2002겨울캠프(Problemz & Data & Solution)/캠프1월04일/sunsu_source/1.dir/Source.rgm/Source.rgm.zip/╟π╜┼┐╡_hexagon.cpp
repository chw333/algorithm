#include <stdio.h>
#include <fstream.h>

#define  LEFT   0
#define  RIGHT  1
#define  BOTTOM 2

int Nums[6][3];

int tn[6], trn[6], MaxSum;
bool v[6];

void Input()
{
	int i;

	ifstream in("hexagon.in");

	for( i = 0; i < 6; i++ )
		in >> Nums[i][0] >> Nums[i][1] >> Nums[i][2];

	in.close();
}

int N( int idx, int l, int trn )
{
	return( Nums[idx][( l + trn ) % 3] );
}

void BT( int idx )
{
	int i, j;

	if( idx == 6 )
	{
		j = 0;
		for( i = 0; i <= 5; i++ )
			j += N( tn[i], BOTTOM, trn[i] );
		if( j > MaxSum ) MaxSum = j;
		return;
	}

	for( i = 1; i <= 5; i++ )
	{
		if( v[i] == true ) continue;

		v[i] = true;
		tn[idx] = i;
		for( j = 0; j <= 2; j++ )
		{
			if( N( tn[idx - 1], LEFT, trn[idx - 1] ) != N( i, RIGHT, j ) ) continue;
			if( idx == 5 && N( i, LEFT, j ) != N( tn[0], RIGHT, trn[0] ) ) continue;
			trn[idx] = j;
			BT( idx + 1 );
		}
		v[i] = false;
	}
}

void Process()
{
	int i;

	tn[0] = 0; v[0] = true;
	for( i = 0; i <= 2; i++ )
	{
		trn[0] = i;
		BT( 1 );
	}
}

void Output()
{
	ofstream out("hexagon.out");

	if( MaxSum == 0 ) out << "impossible";
	else out << MaxSum;

	out.close();
}

void main()
{
	Input();
	Process();
	Output();
}
