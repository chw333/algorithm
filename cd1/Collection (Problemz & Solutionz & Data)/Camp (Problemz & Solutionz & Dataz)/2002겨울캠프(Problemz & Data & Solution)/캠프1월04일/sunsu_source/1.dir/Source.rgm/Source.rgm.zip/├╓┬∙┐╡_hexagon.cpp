#include<fstream.h>

ifstream in("hexagon.in");
ofstream out("hexagon.out");

int data[7][4], hap, check[101][101];

void main()
{
	int i, j, k, m1, m2, min, c, v1, v2, k2;
	for(i=1;i<=6;i++)
	{
		in>>data[i][1]>>data[i][2]>>data[i][3];
		hap+=data[i][1]+data[i][2]+data[i][3];
	}
	for(k=1;k<=6;k++)
	{
		min=99999;
		for(i=1;i<=6;i++)
		{
			for(j=1;j<=3;j++)
			{
				if(data[i][j]<min)
				{
					min=data[i][j];
					m1=i;m2=j;
				}
			}
		}
		c=0;
		if(min==99999){out<<"impossible";break;}
		v1=0; v2=0;
		for(i=1;i<=6;i++)
		{
			if(i!=m1)
			{
				for(j=1;j<=3;j++)
				{
					if(data[i][j]==min)
					{
						check[min][m1]++;
						check[min][i]++;
						for(k2=1;k2<=100;k2++)
						{
							v1=v1+check[min][k2];
							if(check[min][k2]!=0)v2++;
						}
						if(v2>v1/2){
						hap-=min*2;
						data[m1][m2]=99999;
						data[i][j]=99999;
						c=1;
						break;}
						else
						{
							data[m1][m2]=99999;
							data[i][j]=99999;							
							check[min][m1]--;
							check[min][i]--;
						}
					}
				}
			}
			if(c==1){break;}
		}
		if(c!=1){data[m1][m2]=99999;k--;}
	}
	if(k==7){out<<hap;}
}
/*
20 9999 5
10 10 9999
10 9999 5
2 5 9999 
3  5
9999 5 3*/