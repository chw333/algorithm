#include<fstream.h>

int l[6][3], chk[6][3], sum = 0, visit[6];
int dat[3][3] = {{0, 1, 2}, {1, 2, 0}, {2, 0, 1}};
int h;

void input(void)
{
	int i, j;

	ifstream in ("hexagon.in");

	for(i = 0; i < 6; i++){
		for(j = 0; j < 3; j++){
			in >> l[i][j];
		}
	}

	in.close();
}

void output(void)
{
	ofstream out ("hexagon.out");

	if(sum == 0){
		out << "impossible";
	}
	else{
		out << sum;
	}

	out.close();
}

void dfs(int t, int tt, int d)
{
	int i, j, s;

	if(d == 5){
		s = 0;
		if(l[t][dat[tt][1]] != l[0][h]){
			return;
		}
		chk[t][dat[tt][1]] = 1;
		for(i = 0; i < 6; i++){
			for(j = 0; j < 3; j++){
				if(chk[i][j] == 0){
					s += l[i][j];
				}
			}
		}
		chk[t][dat[tt][1]] = 0;
		if(s > sum){
			sum = s;
		}
		return;
	}
	for(i = 1; i < 6; i++){
		if(visit[i] == 1){
			continue;
		}
		for(j = 0; j < 3; j++){
			if(l[t][dat[tt][1]] == l[i][j] && chk[i][j] == 0){
				chk[t][dat[tt][1]] = 1;
				chk[i][j] = 1;
				visit[i] = 1;
				dfs(i, j, d + 1);
				chk[t][dat[tt][1]] = 0;
				chk[i][j] = 0;
				visit[i] = 0;
			}
		}
	}
}

void main(void)
{	
	input();
	chk[0][0] = 1;
	h = 0;
	dfs(0, 0, 0);
	chk[0][0] = 0;
	chk[0][1] = 1;
	h = 1;
	dfs(0, 1, 0);
	chk[0][1] = 0;
	chk[0][2] = 1;
	h = 2;
	dfs(0, 2, 0);
	chk[0][2] = 0;
	output();
}