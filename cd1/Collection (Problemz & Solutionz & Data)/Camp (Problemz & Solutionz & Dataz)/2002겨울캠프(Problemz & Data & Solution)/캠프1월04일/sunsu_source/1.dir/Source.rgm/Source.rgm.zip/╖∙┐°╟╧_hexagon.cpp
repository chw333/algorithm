#include <fstream.h>

const int left[3] = {2,0,1}, right[3] = {0,1,2}, out[3] = {1,2,0};
short int data[6][3];
short int ans = -1;

void i_stream()
{
	ifstream in ("hexagon.in");
	int i;
	for (i = 0;i < 6;i++)
		in >> data[i][0] >> data[i][1] >> data[i][2];
}

void dolli(int a, int b, int c, int d, int e, int f)
{
	int i,j,k,l,m,n;
	for (i = 0;i < 3;i++)
	{
		for (j = 0;j < 3;j++)
		{
			if (data[a][left[i]] != data[b][right[j]])
				continue;
			for (k = 0;k < 3;k++)
			{
				if (data[b][left[j]] != data[c][right[k]])
					continue;
				for (l = 0;l < 3;l++)
				{
					if (data[c][left[k]] != data[d][right[l]])
						continue;
					for (m = 0;m < 3;m++)
					{
						if (data[d][left[l]] != data[e][right[m]])
							continue;
						for (n = 0;n < 3;n++)
						{
							if (data[e][left[m]] != data[f][right[n]])
								continue;
							if (data[f][left[n]] != data[a][right[i]])
								continue;
							if (ans < data[a][out[i]] + data[b][out[j]] + data[c][out[k]] + data[d][out[l]] + data[e][out[m]] + data[f][out[n]])
								ans = data[a][out[i]] + data[b][out[j]] + data[c][out[k]] + data[d][out[l]] + data[e][out[m]] + data[f][out[n]];
						}
					}
				}
			}
		}
	}
}

void process()
{
	short int i,j,k,l,m,n;
	for (i = 0;i < 6;i++)
	{
		for (j = 0;j < 6;j++)
		{
			if (i == j)
				continue;
			for (k = 0;k < 6;k++)
			{
				if (i == k || j == k)
					continue;
				for (l = 0;l < 6;l++)
				{
					if (i == l || j == l || k == l)
						continue;
					for (m = 0;m < 6;m++)
					{
						if (i == m || j == m || k == m || l == m)
							continue;
						for (n = 0;n < 6;n++)
						{
							if (i == n || j == n || k == n || l == n || m == n)
								continue;
							dolli(i,j,k,l,m,n);
						}
					}
				}
			}
		}
	}
}

void o_stream()
{
	ofstream out ("hexagon.out");
	if (ans == -1)
		out << "impossible";
	else
		out << ans;
}

void main()
{
	i_stream();
	process();
	o_stream();
}