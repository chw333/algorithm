#include <stdio.h>
#include <memory.h>
#define InputFile "hexagon.in"
#define OutputFile "hexagon.out"
#define MAXT 6

void Input ( ) ;
void Process ( ) ;
void Find ( int Depth ) ;

int i , j , k ;
int RSoln ;

struct DataStyle
{
	int x , y , z ;
} Data [ MAXT ] ;

struct StackStyle
{
	bool Visit [ MAXT ] ;
	int Soln ;
	int First ;
	int Last ;
} Stack [ MAXT ] ;

void main ( )
{
	Input ( ) ;
	Process ( ) ;
}

void Input ( )
{
	FILE * Inf = fopen ( InputFile , "rt" ) ;
	for ( i = 0 ; i < MAXT ; i ++ )
	{
		fscanf ( Inf , "%d %d %d" , &Data [ i ] . x , &Data [ i ] . y , &Data [ i ] . z ) ;
	}

	fclose ( Inf ) ;
}

void Process ( )
{
	Stack [ 0 ] . Visit [ 0 ] = true ;
	Stack [ 0 ] . First = Data [ 0 ] . x ;
	Stack [ 0 ] .  Soln = Data [ 0 ] . z ;
	Stack [ 0 ] .  Last = Data [ 0 ] . y ;
	Find ( 0 ) ;

	Stack [ 0 ] . First = Data [ 0 ] . y ;
	Stack [ 0 ] .  Last = Data [ 0 ] . x ;
	Stack [ 0 ] .  Soln = Data [ 0 ] . z ;
	Find ( 0 ) ;

	Stack [ 0 ] . First = Data [ 0 ] . z ;
	Stack [ 0 ] .  Last = Data [ 0 ] . y ;
	Stack [ 0 ] .  Soln = Data [ 0 ] . x ;
	Find ( 0 ) ;

	FILE * Ouf = fopen ( OutputFile , "wt" ) ;
	if ( RSoln == 0 )
	{
		fprintf ( Ouf , "impossible" ) ;
	}
	else
	{
		fprintf ( Ouf , "%d" , RSoln ) ;
	}
	fclose ( Ouf ) ;
}

void Find ( int Depth )
{
	int i ;
	if ( Depth == ( MAXT - 2 ) )
	{
		for ( i = 0 ; i <= MAXT ; i ++ )
		{
			if ( !Stack [ Depth ] . Visit [ i ] )
			{
				if ( Stack [ Depth ] . First == Data [ i ] . z && Stack [ Depth ] . Last == Data [ i ] . x )
				{
					Stack [ Depth ] . Soln += Data [ i ] . y ;
					if ( Stack [ Depth ] . Soln > RSoln )
					{
						RSoln = Stack [ Depth ] . Soln ;
					}
				}
				if ( Stack [ Depth ] . First == Data [ i ] . x && Stack [ Depth ] . Last == Data [ i ] . y )
				{
					Stack [ Depth ] . Soln += Data [ i ] . z ;
					if ( Stack [ Depth ] . Soln > RSoln )
					{
						RSoln = Stack [ Depth ] . Soln ;
					}
				}
				if ( Stack [ Depth ] . First == Data [ i ] . y && Stack [ Depth ] . Last == Data [ i ] . z )
				{
					Stack [ Depth ] . Soln += Data [ i ] . x ;
					if ( Stack [ Depth ] . Soln > RSoln )
					{
						RSoln = Stack [ Depth ] . Soln ;
					}
				}
				break ;
			}
		}
	}
	else
	{
		for ( i = 1 ; i <= MAXT ; i ++ )
		{
			if ( !Stack [ Depth ] . Visit [ i ] )
			{
				if ( Data [ i ] . x == Stack [ Depth ] . Last )
				{
					Stack [ Depth + 1 ] = Stack [ Depth ] ;
					Stack [ Depth + 1 ] . Visit [ i ] = true ;
					Stack [ Depth + 1 ] . Soln += Data [ i ] . y ;
					Stack [ Depth + 1 ] . Last = Data [ i ] . z ;
					Find ( Depth + 1 ) ;
				}
				if ( Data [ i ] . y == Stack [ Depth ] . Last )
				{
					Stack [ Depth + 1 ] = Stack [ Depth ] ;
					Stack [ Depth + 1 ] . Visit [ i ] = true ;
					Stack [ Depth + 1 ] . Soln += Data [ i ] . z ;
					Stack [ Depth + 1 ] . Last = Data [ i ] . x ;
					Find ( Depth + 1 ) ;
				}
				if ( Data [ i ] . z == Stack [ Depth ] . Last )
				{
					Stack [ Depth + 1 ] = Stack [ Depth ] ;
					Stack [ Depth + 1 ] . Visit [ i ] = true ;
					Stack [ Depth + 1 ] . Soln += Data [ i ] . x ;
					Stack [ Depth + 1 ] . Last = Data [ i ] . y ;
					Find ( Depth + 1 ) ;
				}
			}
		}
	}
}