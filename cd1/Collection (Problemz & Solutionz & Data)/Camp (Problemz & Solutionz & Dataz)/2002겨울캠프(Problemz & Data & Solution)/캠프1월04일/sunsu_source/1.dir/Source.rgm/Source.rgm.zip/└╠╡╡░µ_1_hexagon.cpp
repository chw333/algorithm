#include <fstream.h>
const int N=6;
int Data[N][3];
int Stack[20],Answer=-1;
bool Use[N];
void bstr(int depth,int Ans)
{
	int i,j;
	if (depth<N)
	{
		for (i=1;i<N;i++)
			if (Use[i]==false)
				for (j=0;j<3;j++)
					if (Data[i][j]==Stack[depth-1])
					{
						Use[i]=true;
						Stack[depth]=Data[i][(j+1)%3];
						bstr(depth+1,Ans+Data[i][(j+2)%3]);
						Use[i]=false;
					}
	}
	else
	{
		for (i=1;i<=N;i++)
			if (Use[i]==false)
				for (j=0;j<3;j++)
					if (Data[i][j]==Stack[depth-1] && Stack[0]==Data[i][(j+1)%3])
					{
						if (Ans+Data[i][(j+2)%3]>Answer) Answer=Ans+Data[i][(j+2)%3];
					}
	}
}
void ipt()
{
	ifstream in("hexagon.in");
	int i,j;
	for (i=0;i<N;i++)
		for (j=0;j<3;j++)
			in >> Data[i][j];
}
void prs()
{
	Use[0]=true;
	int i,j,k;
	for (i=0;i<3;i++)
	{
		Stack[0]=Data[0][(i+1)%3];
		Stack[1]=Data[0][(i+2)%3];
		bstr(2,Data[0][i]);
	}
}
void opt()
{
	ofstream out("hexagon.out");
	if (Answer>-1)
	{
		out << Answer;
	}
	else
	{
		out << "impossible";
	}
}
void main()
{
	ipt();
	prs();
	opt();
}
