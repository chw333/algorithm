#include <fstream.h>

int M=-999999;
int D[6][3];
int I[6];
int V[6];

void init()
{
	int i,j;

	ifstream in ("hexagon.in");
	for (i=0;i<6;i++) {
		for (j=0;j<3;j++) {
			in >> D[i][j];
		}
	}
	in.close();
}

void recall(int w, int c, int s)
{
	int k,j,l;

	if (c==6) {
		l=I[w]-1;
		if (l==-1) l=2;
		k=I[s]+1;
		if (k==3) k=0;
		if (D[w][l]==D[s][k]) {
			k=0;
			for (j=0;j<6;j++) {
				k+=D[j][I[j]];
			}
			if (k>M) M=k;
		}
		return;
	}

	for (k=0;k<6;k++) {
		if (V[k]) continue;
		l=I[w]-1;
		if (l==-1) l=2;
		for (j=0;j<3;j++) {
			if (D[w][l]!=D[k][j]) continue;
			l=j-1;
			if (l==-1) l=2;
			V[k]=1;
			I[k]=l;
			recall(k,c+1,s);
			V[k]=0;
		}
	}
}

void process()
{
	int i,j;

//	for (i=0;i<6;i++) {
		V[0]=1;
		for (j=0;j<3;j++) {
			I[0]=j;
			recall(0,1,0);
		}
		V[0]=0;
//	}
}

void output()
{
	ofstream out ("hexagon.out");
	if (M==-999999) out << "impossible"; else out << M;
	out.close();
}

void main()
{
	init();
	process();
	output();
}
