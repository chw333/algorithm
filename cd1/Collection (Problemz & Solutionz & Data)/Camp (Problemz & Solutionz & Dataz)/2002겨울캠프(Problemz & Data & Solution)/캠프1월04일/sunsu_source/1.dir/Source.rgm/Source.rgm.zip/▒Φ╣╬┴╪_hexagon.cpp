#include<fstream.h>

ifstream in("hexagon.in");
ofstream out("hexagon.out");

static int Data[7][4],Visit[7],max;
static int cho;

void dfs(int cnt,int top,int gap)
{
	int i,j;
	
	if(cnt==7)
	{
		if(cho==top)
		{
			if(max<gap)
			{
				max=gap;
			}
		}
		return;
	}
				

	for(i=1;i<=6;i++)
	{
		if(Visit[i]==1)
		{
			continue;
		}
		for(j=1;j<=3;j++)
		{
			if(Data[i][j]==top)
			{
				if(j+1==4)
				{

					Visit[i]=1;					
					dfs(cnt+1,Data[i][1],gap+Data[i][j-1]);
				}
				else
				{
					Visit[i]=1;
					dfs(cnt+1,Data[i][j+1],gap+Data[i][j-1]);
				}
			}
		}
		Visit[i]=0;
	}
}






void main(void)
{
	static int i,j;

	for(i=1;i<=6;i++)
	{
		for(j=1;j<=3;j++)
		{
			in >> Data[i][j];
		}
		Data[i][0]=Data[i][3];
	}

	for(i=1;i<=3;i++)
	{
		Visit[1]=1;
		cho=Data[1][i];
		if(i+1==4)
		{
			dfs(2,Data[1][1],Data[1][i-1]);
		}
		else dfs(2,Data[1][i+1],Data[1][i-1]);
	}
	
	if(max==0)
	{
		out << "impossible";
	}
	else out << max;
	
}
