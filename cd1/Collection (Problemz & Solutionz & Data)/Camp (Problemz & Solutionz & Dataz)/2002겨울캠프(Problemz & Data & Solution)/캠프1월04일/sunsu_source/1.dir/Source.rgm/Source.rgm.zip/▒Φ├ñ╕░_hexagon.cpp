#include <fstream.h>
#include <string.h>
#include <stdlib.h>

ifstream in("hexagon.in");
ofstream out("hexagon.out");

int qus1[7] , qus2[7] , qus3[7] , i;
int max[7] , j , maximum;

void inp()
{
	for(i=0; i<6; i++) {
		in>>qus1[i]>>qus2[i]>>qus3[i];
	}
}

void maxp()
{
	for(i=0; i<6; i++) {
		if(max[i]<qus1[i]) {
			max[i]=qus1[i];
		}
		if(max[i]<qus2[i]) {
			max[i]=qus2[i];
		}
		if(max[i]<qus3[i]) {
			max[i]=qus3[i];
		}
	}
}

void outp()
{
	for(i=0; i<6; i++) {
		maximum+=max[i];
	}
	out<<maximum;
}

void main()
{
	inp();
	maxp();
	outp();
}
