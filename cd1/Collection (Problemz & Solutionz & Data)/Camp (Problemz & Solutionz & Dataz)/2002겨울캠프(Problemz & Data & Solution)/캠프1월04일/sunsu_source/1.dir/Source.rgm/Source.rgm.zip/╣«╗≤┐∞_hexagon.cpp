#include <fstream.h>
#define MIN -9999999

void btrack(int);

int t[6][3], sum, maxsum=MIN;
int byun[2], chk[6];

void main()
{
	int i, j;
	ifstream in("hexagon.in");
	for(i=0; i<6; i++) {
		for(j=0; j<3; j++) {
			in >> t[i][j];
		}
	}
	in.close();
	btrack(0);
	ofstream out("hexagon.out");
	if(maxsum==MIN) { out << "impossible"; }
	else { out << maxsum; }
	out.close();
}

void btrack(int tricnt)
{
	int i, j, k, pos;
	int l[3];
	if(tricnt==6) {
		if(sum>maxsum) { maxsum=sum; }
		return;
	}
	for(i=0; i<6; i++) {
		if(chk[i]==1) { continue; }
		for(j=0; j<3; j++) {
			pos=j;
			for(k=0; k<3; k++) {
				l[k]=t[i][pos];
				pos++;
				if(pos==3) { pos=0; }
			}
			if(tricnt==0) {
				byun[0]=l[0];
				sum+=l[1];
				byun[1]=l[2];
				chk[i]=1;
				btrack(tricnt+1);
				chk[i]=0;
				byun[1]=0;
				sum-=l[1];
				byun[0]=0;
				continue;
			}
			if(tricnt==5) {
				if(byun[0]==l[1] && byun[1]==l[2]) {
					sum+=l[0];
					chk[i]=1;
					btrack(tricnt+1);
					chk[i]=0;
					sum-=l[0];
				}
				continue;
			}
			if(byun[0]==l[1]) {
				byun[0]=l[2];
				sum+=l[0];
				chk[i]=1;
				btrack(tricnt+1);
				chk[i]=0;
				sum-=l[0];
				byun[0]=l[1];
			}
/*			if(byun[1]==l[0]) {
				byun[0]=l[2];
				sum+=l[1];
				chk[i]=1;
				btrack(tricnt+1);
				chk[i]=0;
				sum-=l[1];
				byun[0]=l[0];
			}*/
		}
	}
}
