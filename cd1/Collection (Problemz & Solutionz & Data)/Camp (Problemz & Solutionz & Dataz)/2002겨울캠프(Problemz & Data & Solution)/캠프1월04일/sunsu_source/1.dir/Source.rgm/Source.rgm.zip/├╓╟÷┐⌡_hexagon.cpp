#include<stdio.h>
#include<stdlib.h>
#include<fstream.h>

#define MAX 10 

ifstream in("hexagon.in");
ofstream out("hexagon.out");
int chk[MAX];
int max,sum;
int dt[MAX][MAX];
int tri[MAX][MAX][MAX];
int p;
/*

  tri [ ����  ][ ����� �� ][  ������� ]
  tri [ left  ][   right   ][   top     ]
	1 =  left
	2 =  right
	3 =  top
*/
void input()
{
	int i,j,k;
	for(i=1;i<=6;i++){
		for(j=1;j<=3;j++){
			in >> dt[i][j];
			tri[i][1][j] = dt[i][j];
		}
		for(j=2;j<=3;j++){
			tri[i][j][1] = tri[i][j-1][3];
			tri[i][j][2] = tri[i][j-1][1];
			tri[i][j][3] = tri[i][j-1][2];
		}
	}

}
void back(int lv,int x)
{
	int i,j;
	if(lv == 5)
	{
		if(max < sum && x == tri[1][p][1])max = sum;
	}
	else{
		for(i=1;i<=6;i++){
			if(chk[i] == false){
				for(j=1;j<=3;j++){
					if( x == tri[i][j][1])
					{
						chk[i] = true;
						sum += tri[i][j][3];
						back(lv+1,tri[i][j][2]);
						sum -= tri[i][j][3];
						chk[i] = false;
					}
				}
			}
		}
	}
}
void output()
{
	out << max;
}
void main(void)
{
	input();
	chk[1] = true;
	for(p=1;p<=3;p++){
		sum += tri[1][p][3];
		back(0,tri[1][p][2]);
		sum -= tri[1][p][3];
	}	
	output();
}
