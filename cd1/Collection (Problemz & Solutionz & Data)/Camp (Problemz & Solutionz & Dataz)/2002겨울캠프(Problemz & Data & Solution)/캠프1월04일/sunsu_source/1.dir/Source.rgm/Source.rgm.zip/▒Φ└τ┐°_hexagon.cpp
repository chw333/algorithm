#include <fstream.h>
#include <memory.h>

int tri[6][3];
int use[6][3]; //in=0, out=1
int usecnt[6];
int ans;

void input()
{
	int i;

	ifstream in ("hexagon.in");
	for(i=0; i<6; i++) in >> tri[i][0] >> tri[i][1] >> tri[i][2];
	in.close();

	memset(use, -1, sizeof(use));
}

void proc()
{
	int p[6];
	int chk[101];
	int res=0, i, j, sw;

	for(p[0]=0; p[0]<3; p[0]++) //� ���� �ٱ����� �����°�
	{
		for(p[1]=0; p[1]<3; p[1]++)
		{
			for(p[2]=0; p[2]<3; p[2]++)
			{
				for(p[3]=0; p[3]<3; p[3]++)
				{
					for(p[4]=0; p[4]<3; p[4]++)
					{
						for(p[5]=0; p[5]<3; p[5]++)
						{
							res=0;
							memset(chk, 0, sizeof(chk));
							for(i=0; i<6; i++) 
							{
								for(j=0; j<3; j++) 
								{
									if(j!=p[i]) 
									{
										chk[tri[i][j]]++;
									}
								}
							}
							sw=0;
							for(i=0; i<100; i++) 
							{
								if(chk[i]!=0 && chk[i]<2) 
								{
									sw=1;
									break;
								}
							}
							if(sw) continue;
							for(i=0; i<6; i++) res+=tri[i][p[i]];
							if(ans<res) ans=res;
						}
					}
				}
			}
		}
	}
}

void output()
{
	ofstream out ("hexagon.out");
	if(ans!=0) out << ans << endl;
	else out << "impossible" << endl;
	out.close();
}

void main()
{
	input();
	proc();
	output();
}
