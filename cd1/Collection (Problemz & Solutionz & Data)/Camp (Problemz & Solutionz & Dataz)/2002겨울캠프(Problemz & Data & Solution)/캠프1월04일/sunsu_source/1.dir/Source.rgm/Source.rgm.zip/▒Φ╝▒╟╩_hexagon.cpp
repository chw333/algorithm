#include <fstream.h>
ifstream in("hexagon.in");
ofstream out("hexagon.out");
#define N 6
int n=N;
int num[N][N];
int dab;
int ga[N][N]={{0,1,2},{1,2,0},{2,0,1}};
void Input()
{
	int i,j;
	for(i=0;i<n;i++)
		for(j=0;j<3;j++)
			in>>num[i][j];
}
void Process()
{
	int a,b,c,d,e,f,g,h,i,j,k,l;
	for(a=0;a<n;a++){
		for(b=0;b<n;b++){
			if(b!=a)
			for(c=0;c<n;c++){
				if(c!=a&&c!=b)
				for(d=0;d<n;d++){
					if(d!=a&&d!=b&&d!=c)
					for(e=0;e<n;e++){
						if(e!=a&&e!=b&&e!=c&&e!=d)
						for(f=0;f<n;f++){
							if(f!=a&&f!=b&&f!=c&&f!=d&&f!=e)
							for(g=0;g<3;g++){/////////////////////////////////////////////////////////
								for(h=0;h<3;h++){
									for(i=0;i<3;i++){
										for(j=0;j<3;j++){
											for(k=0;k<3;k++){
												for(l=0;l<3;l++){
													if(num[a][ga[g][2]]==num[b][ga[h][0]]&&num[b][ga[h][2]]==num[c][ga[i][0]]){
														if(num[c][ga[i][2]]==num[d][ga[j][0]]&&num[d][ga[j][2]]==num[e][ga[k][0]]){
															if(num[e][ga[k][2]]==num[f][ga[l][0]]&&num[f][ga[l][2]]==num[a][ga[g][0]]){
																if(dab<num[a][ga[g][1]]+num[b][ga[h][1]]+num[c][ga[i][1]]+num[d][ga[j][1]]+num[e][ga[k][1]]+num[f][ga[l][1]]){
																	dab=num[a][ga[g][1]]+num[b][ga[h][1]]+num[c][ga[i][1]]+num[d][ga[j][1]]+num[e][ga[k][1]]+num[f][ga[l][1]];
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
void Output()
{
	if(!dab) out<<"impossible";
	else out<<dab;
}
void main()
{
	Input();
	Process();
	Output();
}