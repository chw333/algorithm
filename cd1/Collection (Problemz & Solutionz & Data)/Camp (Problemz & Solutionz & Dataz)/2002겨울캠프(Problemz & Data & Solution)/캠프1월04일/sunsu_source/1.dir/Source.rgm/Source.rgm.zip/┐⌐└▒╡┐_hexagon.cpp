#include<fstream.h>
#define Min -1999999999
#define n 6
#define poly 3
#define Maxcase 3

void init(void);
void process(int , int);
void out(void);

int l[n + 1][poly + 1];
int leng[Maxcase + 1][poly + 1] = 
{
	{0 ,} , 
	{3 , 1 , 2 , 3} , 
	{2 , 3 , 1 , 2} , 
	{1 , 2 , 3 , 1} 
};
int ans = Min;
int visit[n + 1];
int selected[n + 1];

void main(void){
	init();
	out();
}

void init(void){
	int i;
	ifstream in("hexagon.in");
	for(i=1; i<=n; i++){
		in >> l[i][1] >> l[i][2] >> l[i][3];
	}
	selected[1] = 1;
	for(i=1; i<=Maxcase; i++){
		visit[1] = i;
		process(2 , l[1][leng[i][3]]);
	}
}
 
void process(int now , int dis){
	int i , k;
	int l1 , l2 , l3;
	int bc , ln;
	ln = selected[now - 1];
	bc = visit[ln];
	if(now == n + 1){
		if(l[ln][leng[bc][2]] == l[1][leng[visit[1]][1]]){
			if(ans < dis) ans = dis;
		}
		return;
	}
	for(k=2; k<=n; k++){
		if(!visit[k]){
			for(i=1; i<=Maxcase; i++){
				l1 = l[k][leng[i][1]];
				l2 = l[k][leng[i][2]];
				l3 = l[k][leng[i][3]];
				if(l1 == l[ln][leng[bc][2]]){
					selected[now] = k;
					visit[k] = i;
					process(now + 1 , dis + l3);
					visit[k] = 0;
				}
			}
		}
	}
}

void out(void){
	ofstream op("hexagon.out");
	if(ans == Min){
		op << "impossible";
	} else op<< ans;
}