#include<fstream.h>
#include<memory.h>
struct triangle{
	int left,right,bottom;
	void turning(int cnt){
		int i,temp;
		for(i=0;i<cnt;i++){
			temp=bottom;
			bottom=right;
			right=left;
			left=temp;
		}
	}
}Tri[6];
int Stack[6],Chk[6],Max=-1;
void input(void){
	int i;
	ifstream in("hexagon.in");
	for(i=0;i<6;i++){
		in >> Tri[i].left >> Tri[i].right >> Tri[i].bottom;
	}	
}
void backtrack(int cnt){
	int i,sum;
	if(cnt==6){
		if(Tri[Stack[5]].right==Tri[0].left){
			sum=0;
			for(i=0;i<6;i++){
				sum+=Tri[i].bottom;
			}
			if(Max<sum) Max=sum;
		}
		return;
	}
 	for(i=1;i<6;i++){
		if(Chk[i]!=1&&Tri[i].left==Tri[Stack[cnt-1]].right)
		{
			Chk[i]=1;
			Stack[cnt]=i;
			backtrack(cnt+1);
			Stack[cnt]=-1;
			Chk[i]=0;
		}
		if(Chk[i]!=1&&Tri[i].right==Tri[Stack[cnt-1]].right)
		{
			Chk[i]=1;
			Tri[i].turning(2);
			Stack[cnt]=i;
			backtrack(cnt+1);
			Stack[cnt]=-1;
			Tri[i].turning(1);
			Chk[i]=0;
		}
		if(Chk[i]!=1&&Tri[i].bottom==Tri[Stack[cnt-1]].right)
		{
			Chk[i]=1;
			Tri[i].turning(1);
			Stack[cnt]=i;
			backtrack(cnt+1);
			Stack[cnt]=-1;
			Tri[i].turning(2);
			Chk[i]=0;
		}
	}
}
void main(void){
	input();
	int i;
	for(i=0;i<3;i++){
		memset(Stack,-1,sizeof(int)*6);
		Chk[0]=1;
		Tri[0].turning(1);
		Stack[0]=0;
		backtrack(1);
	}
	ofstream out("hexagon.out");
	if(Max==-1) out << "impossible";
	else out << Max;
	out.close();
}