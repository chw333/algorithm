#include<fstream.h>
int Data[7][4],Sun[4][4] = {{0},{0,1,2,3},{0,2,3,1},{0,3,1,2}},Visit[7];
int Pro[6][4],sum,Max=-2000000000;
void input(void)
{
	int i;
	ifstream in("hexagon.in");
	for(i = 1;i<=6;i++){
		in >> Data[i][1] >> Data[i][2] >> Data[i][3];
	}
}
void back(int n)
{
	int i,j;
	if(n <= 6){
		for(i = 2;i<=6;i++){
			if(Visit[i] == 0){
				for(j = 1;j<=3;j++){
					if(Pro[n-1][2] == Data[i][Sun[j][1]]){
						if((n <= 5) || (n == 6 && Pro[1][1] == Data[i][Sun[j][2]])){
							Pro[n][1] = Data[i][Sun[j][1]];
							Pro[n][2] = Data[i][Sun[j][2]];
							Pro[n][3] = Data[i][Sun[j][3]];
							Visit[i] = 1;
							sum += Data[i][Sun[j][3]];
							back(n+1);
							sum -= Data[i][Sun[j][3]];
							Visit[i] = 0;
							Pro[n][1] = 0;
							Pro[n][2] = 0;
							Pro[n][3] = 0;
						}
					}
				}
			}
		}
	}
	else{
		if(Max < sum)
			Max = sum;
	}
}
void output(void)
{
	ofstream out("hexagon.out");
	out << Max;
}
void main(void)
{
	int i,j;
	input();
	for(i = 1;i<=3;i++){
		for(j = 1;j<=3;j++){
			Pro[1][j] = Data[1][Sun[i][j]];
		}
		sum = Data[1][Sun[i][3]];
		back(2);
	}
	output();
}