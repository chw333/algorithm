#include <fstream.h>
struct STR_TA {int n[3]; bool used;};
struct STR_TA TA[6];
int POS[6], SUM, MAX=-1;

void input()
{
	ifstream infile("hexagon.in");
	for (int i=0;i<6;i++) infile >> TA[i].n[0] >> TA[i].n[1] >> TA[i].n[2];
	infile.close();
}

void hexagon(int no, int p, int d)
{
	int i, j;
	TA[no].used = true;
	SUM+=TA[no].n[(p+1)%3];
	if (d==5) if (MAX==-1||MAX<SUM) {MAX=SUM; }
//	POS[d] = no;
	for (i=0;i<6;i++)
	{
		if (TA[i].used) continue;
		for (j=0;j<3;j++)
		{
			if (TA[no].n[(p+2)%3]==TA[i].n[j])
			{
				hexagon(i,j,d+1);
			}
		}
	}
	SUM-=TA[no].n[(p+1)%3];
	TA[no].used = false;
}

void output()
{
	ofstream outfile("hexagon.out");
	if (MAX!=-1) outfile << MAX;
	else outfile << "impossible";
	outfile.close();
}

void main()
{
	input();
	hexagon(0, 0, 0);
	hexagon(0, 1, 0);
	hexagon(0, 2, 0);
	output();
}