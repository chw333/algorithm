#include <fstream.h>
#define PROG "hexagon"
#define n 6
int tri[6][3];
bool visit[6];
int status[6][2]; // 0�� 1��
int result;
void input()
{
	ifstream in(PROG".in");
	int i,j;
	for(i=0;i<n;i++) {
		for(j=0;j<3;j++) {
			in >> tri[i][j];
		}
	}
}
void back(int level, int len)
{
	if(level==n) {
		if(status[level-1][1]==status[0][0] && result<len) result=len;
		return;
	}
	int i;
	for(i=0;i<n;i++) {
		if(!visit[i]) {
			visit[i]=true;
			status[level][0]=tri[i][0];
			status[level][1]=tri[i][1];
			if(status[level-1][1]==status[level][0]) back(level+1,len+tri[i][2]);
			status[level][0]=tri[i][1];
			status[level][1]=tri[i][2];
			if(status[level-1][1]==status[level][0]) back(level+1,len+tri[i][0]);
			status[level][0]=tri[i][2];
			status[level][1]=tri[i][0];
			if(status[level-1][1]==status[level][0]) back(level+1,len+tri[i][1]);
			visit[i]=false;
		}
	}
}
void process()
{
	int i;
	for(i=0;i<n;i++) {
		visit[i]=true;
		status[0][0]=tri[i][0];
		status[0][1]=tri[i][1];
		back(1,tri[i][2]);
		status[0][0]=tri[i][1];
		status[0][1]=tri[i][2];
		back(1,tri[i][0]);
		status[0][0]=tri[i][2];
		status[0][1]=tri[i][0];
		back(1,tri[i][1]);
		visit[i]=false;
	}
}
void output()
{
	ofstream out(PROG".out");
	if(result==0) out << "impossible" << endl;
	else out << result << endl;
}
void main()
{
	input();
	process();
	output();
}
