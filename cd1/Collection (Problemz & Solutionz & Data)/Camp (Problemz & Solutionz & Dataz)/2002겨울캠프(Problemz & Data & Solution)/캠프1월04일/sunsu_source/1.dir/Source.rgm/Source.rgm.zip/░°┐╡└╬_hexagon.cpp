#include<fstream.h>
#include<conio.h>

int hap=0,max=0,s,s2,dd;

int b1[200],b2[200],b3[200],c[200];
int chk[200],b1c[200],b2c[200],b3c[200];

void input()

{
	int i;
	ifstream in("hexagon.in");
	for(i=0;i<6;i++)
	{
		in >> b1[i] >> b2[i] >> b3[i];
	}

}

void back(int qw,int cnt)

{
	int i,j;
	for(i=0;i<6;i++){
		if(chk[i]==1 && cnt==5)	{
			if(qw==b1[i]){
				if(s2==1){
					if(b1[s]==b2[i]){
						b1c[i]=1;b2c[i]=1;
						back(b3[i],cnt+1);
					}
					else if(b1[s]==b3[i]){
						b1c[i]=1;b3c[i]=1;
						back(b2[i],cnt+1);
					}
				}
				else if(s2==2){
					if(b2[s]==b2[i]){
						b1c[i]=1;b2c[i]=1;
						back(b3[i],cnt+1);
					}
					else if(b2[s]==b3[i]){
						b1c[i]=1;b3c[i]=1;
						back(b2[i],cnt+1);
					}
				}
				else if(s2==3){
					if(b3[s]==b2[i]){
						b1c[i]=1;b2c[i]=1;
						back(b3[i],cnt+1);
					}
					else if(b3[s]==b3[i]){
						b1c[i]=1;b3c[i]=1;
						back(b2[i],cnt+1);
					}
				}
			}
			else if(qw==b2[i]){
				if(s2==1){
					if(b1[s]==b1[i]){
						b1c[i]=1;b2c[i]=1;
						back(b3[i],cnt+1);
					}
					else if(b1[s]==b3[i]){
						b1c[i]=1;b3c[i]=1;
						back(b1[i],cnt+1);
					}
				}
				else if(s2==2){
					if(b2[s]==b1[i]){
						b1c[i]=1;b2c[i]=1;
						back(b3[i],cnt+1);
					}
					else if(b2[s]==b3[i]){
						b1c[i]=1;b3c[i]=1;
						back(b1[i],cnt+1);
					}
				}
				else if(s2==3){
					if(b3[s]==b1[i]){
						b1c[i]=1;b2c[i]=1;
						back(b3[i],cnt+1);
					}
					else if(b3[s]==b3[i]){
						b1c[i]=1;b3c[i]=1;
						back(b1[i],cnt+1);
					}
				}
			}
			else if(qw==b3[i]){
				if(s2==1){
					if(b1[s]==b2[i]){
						b1c[i]=1;b2c[i]=1;
						back(b1[i],cnt+1);
					}
					else if(b1[s]==b3[i]){
						b1c[i]=1;b3c[i]=1;
						back(b2[i],cnt+1);
					}
				}
				else if(s2==2){
					if(b2[s]==b2[i]){
						b1c[i]=1;b2c[i]=1;
						back(b1[i],cnt+1);
					}
					else if(b2[s]==b3[i]){
						b1c[i]=1;b3c[i]=1;
						back(b2[i],cnt+1);
					}
				}
				else if(s2==3){
					if(b3[s]==b2[i]){
						b1c[i]=1;b2c[i]=1;
						back(b1[i],cnt+1);
					}
					else if(b3[s]==b3[i]){
						b1c[i]=1;b3c[i]=1;
						back(b2[i],cnt+1);
					}
				}
			}



		}
		if(cnt!=6)
		{
		if(chk[i]==0){
			if(qw==b1[i]){
				chk[i]=1;b1c[i]=1;b2c[i]=1;
				back(b2[i],cnt+1);
				b2c[i]=0;
				//b3c[i]=1;
				//back(b3[i],cnt+1);
				//b3c[i]=0;
				chk[i]=0;b1c[i]=0;
			}
			else if(qw==b2[i]){
				chk[i]=1;b2c[i]=1;//b1c[i]=1;
				//back(b1[i],cnt+1);
				//b1c[i]=0;
				b3c[i]=1;
				back(b3[i],cnt+1);
				b3c[i]=0;
				chk[i]=0;b2c[i]=0;
			}
			else if(qw==b3[i]){
				chk[i]=1;b3c[i]=1;b1c[i]=1;
				back(b1[i],cnt+1);
				b1c[i]=0;//b2c[i]=1;
				//back(b2[i],cnt+1);
				//b2c[i]=0;
				chk[i]=0;b3c[i]=0;
				}
			}
		}
			if(cnt==6 && dd!=1){
			for(j=0;j<6;j++){
				if(b1c[j]==0){
					hap+=b1[j];
				}
				else if(b2c[j]==0){
			
					hap+=b2[j];
				}
				else if(b3c[j]==0){
					hap+=b3[j];
				}
			}
			if(hap>max) max=hap;
			hap=0;
		}
	}
}


void output()

{
	ofstream out("hexagon.out");
	if(max!=0){
		out << max;
	}
	else{
		out << "impossible";
	}

}

void main()

{
	input();
	s=0;s2=1;b1c[0]=1;chk[0]=1;
	back(b1[0],0);
	chk[0]=0;b1c[0]=0;s=0;s2=2;
	b2c[0]=1;chk[0]=1;
	back(b2[0],0);
	chk[0]=0;b2c[0]=0;s=0;s2=3;
	b3c[0]=1;chk[0]=1;
	back(b3[0],0);
	chk[0]=0;b3c[0]=0;
	output();		
}