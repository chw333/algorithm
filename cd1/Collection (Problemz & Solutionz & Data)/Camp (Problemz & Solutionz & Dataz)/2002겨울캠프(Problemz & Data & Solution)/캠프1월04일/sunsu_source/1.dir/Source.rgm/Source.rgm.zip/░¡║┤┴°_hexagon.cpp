#include <fstream.h>

int ll[6][3], mt[3][3] = {{0, 1, 2}, {2, 0, 1}, {1, 2, 0}}, ans = 0;

void input(){
	int i;
	ifstream fin ("hexagon.in");
	for(i = 0 ; i < 6 ; i++)
		fin >> ll[i][0] >> ll[i][1] >> ll[i][2];
}

void process(){
	int i, j, k, l, m, n, o, p, q, r, s, t;
	
	for(i = 0 ; i < 6 ; i++){
		for(j = 0 ; j < 6 ; j++){
			if(i != j)
			for(k = 0 ; k < 6 ; k++){
				if(i != k && j != k)
				for(l = 0 ; l < 6 ; l++){
					if(i != l && j != l && k != l)
					for(m = 0 ; m < 6 ; m++){
						if(i != m && j != m && k != m && l != m)
						for(n = 0 ; n < 6 ; n++){
							if(i != n && j != n && k != n && l != n && m != n)
							for(o = 0 ; o < 3 ; o++){
								for(p = 0 ; p < 3 ; p++){
									for(q = 0 ; q < 3 ; q++){
										for(r = 0 ; r < 3 ; r++){
											for(s = 0 ; s < 3 ; s++){
												for(t = 0 ; t < 3 ; t++){
													if(ll[i][mt[o][1]] == ll[j][mt[p][0]] && ll[j][mt[p][1]] == ll[k][mt[q][0]] && ll[k][mt[q][1]] == ll[l][mt[r][0]] && ll[l][mt[r][1]] == ll[m][mt[s][0]] && ll[m][mt[s][1]] == ll[n][mt[t][0]] && ll[n][mt[t][1]] == ll[i][mt[o][0]])
														if(ans < ll[i][mt[o][2]] + ll[j][mt[p][2]] + ll[k][mt[q][2]] + ll[l][mt[r][2]] + ll[m][mt[s][2]] + ll[n][mt[t][2]])
															ans = ll[i][mt[o][2]] + ll[j][mt[p][2]] + ll[k][mt[q][2]] + ll[l][mt[r][2]] + ll[m][mt[s][2]] + ll[n][mt[t][2]];
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

void output(){
	ofstream fout ("hexagon.out");
	if(ans != 0) fout << ans;
	else fout << "impossible";
}

void main(){
	input();
	process();
	output();

}