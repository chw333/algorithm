#include <stdio.h>
#include <fstream.h>

#define MIN -99999999

ifstream in("hexagon.in");
ofstream out("hexagon.out");

int block[6][3];
int state[6][3],total;
int type[3][3]={{0,1,2},{2,0,1},{1,2,0}};
int max=MIN;

bool used_chk[6];

void input(void)
{
	int i,j;

	for(i=0; i<=5; i++)
		for(j=0; j<=2; j++)
			in >> block[i][j];
}

void gen_state(int level, int block_type, int dir_type)
{
	int i;

	for(i=0; i<=2; i++)
		state[level][i]=block[block_type][type[dir_type][i]];
}

void renewal(void)
{
/*	int i,j;
	
	for(i=0; i<=5; i++){
		for(j=0; j<=2; j++)
			cout << state[i][j] << ' ';
		cout << endl;
	}
	cout << total << endl << endl;*/
	if(total>max) max=total;
}

void back(int level)
{
	int i;

	if(level==5){
		for(i=1; i<=5; i++){
			if(used_chk[i]) continue;

			if(state[level-1][1]==block[i][0] && block[i][1]==state[0][0]){
				gen_state(level,i,0);
				total+=state[level][2];	
				used_chk[i]=1;
			
				renewal();
			
				used_chk[i]=0;
				total-=state[level][2];
			}

			if(state[level-1][1]==block[i][2] && block[i][0]==state[0][0]){
				gen_state(level,i,1);
				total+=state[level][2];	
				used_chk[i]=1;

				renewal();
				
				used_chk[i]=0;
				total-=state[level][2];
			}

			if(state[level-1][1]==block[i][1] && block[i][2]==state[0][0]){
				gen_state(level,i,2);
				total+=state[level][2];	
				used_chk[i]=1;

				renewal();
				
				used_chk[i]=0;
				total-=state[level][2];
			}
		}
	}

	else{	
		for(i=1; i<=5; i++){
			if(used_chk[i]) continue;

			if(state[level-1][1]==block[i][0]){
				gen_state(level,i,0);
				total+=state[level][2];	
				used_chk[i]=1;
			
				back(level+1);
			
				used_chk[i]=0;
				total-=state[level][2];
			}

			if(state[level-1][1]==block[i][2]){
				gen_state(level,i,1);
				total+=state[level][2];	
				used_chk[i]=1;

				back(level+1);
			
				used_chk[i]=0;
				total-=state[level][2];
			}

			if(state[level-1][1]==block[i][1]){
				gen_state(level,i,2);
				total+=state[level][2];	
				used_chk[i]=1;

				back(level+1);
			
				used_chk[i]=0;
				total-=state[level][2];
			}
		}
	}

}

void back_0(void)
{
	gen_state(0,0,0);
	total+=state[0][2];	
	back(1);
	total-=state[0][2];

	gen_state(0,0,1);
	total+=state[0][2];	
	back(1);
	total-=state[0][2];

	gen_state(0,0,2);
	total+=state[0][2];	
	back(1);
	total-=state[0][2];
}

void output(void)
{
	if(max==MIN)
		out << "impossible";
	else
		out << max;
}

void main(void)
{
	input();
	back_0();
	output();
}