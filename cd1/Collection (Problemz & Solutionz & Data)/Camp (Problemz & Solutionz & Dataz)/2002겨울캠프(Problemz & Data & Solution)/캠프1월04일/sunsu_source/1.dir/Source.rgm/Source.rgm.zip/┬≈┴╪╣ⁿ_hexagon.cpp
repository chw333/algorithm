#include <fstream.h>

#define S 7
#define B 4

ifstream in("hexagon.in");
ofstream out("hexagon.out");

int sol,cho;
int gon[S][B],visit[S];

void Input()
{
	int i,j;
	for(i=1;i<=6;i++){
		for(j=1;j<=3;j++) in>>gon[i][j];
		gon[i][0]=gon[i][3];
	}
}
int Promise(int tp, int v)
{
	if(cho==tp && sol<v) return 1;
	return 0;
}
void dfs(int cnt, int tp, int v)
{

	int i,j;	
	if(cnt==7){
		if(Promise(tp,v)) sol=v;
	} else {
		for(i=1; i<=6; i++){
			if(!visit[i]){
				for(j=1; j<=3; j++){
					if(gon[i][j]==tp){
						if(!visit[i]) visit[i]=1;
						if(j==3) dfs(cnt+1,gon[i][1],v+gon[i][j-1]); else dfs(cnt+1,gon[i][j+1],v+gon[i][j-1]);
					}
				}
				visit[i]=0;
			}
		}
	}
}
void Process()
{
	int i;
	for(i=1;i<=3;i++){
		visit[1]=1;
		cho=gon[1][i];
		if(i==3) dfs(2,gon[1][1],gon[1][i-1]); else dfs(2,gon[1][i+1],gon[1][i-1]);
	}
}
void Output()
{
	if(!sol) out<<"impossible"; else out<<sol;
}
void main()
{
	Input();
	Process();
	Output();
}
