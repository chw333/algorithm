#include <fstream.h>

#define DoNot "impossible"

ifstream in( "hexagon.in" );
ofstream out("hexagon.out");

int tri[6][3],Max,e;
int link[101][18][3],num[101];

void input()
{
	int i,j,k,l;
	for(i = 0 ; i < 6; i ++ ){
		for( j = 0 ; j < 3; j ++ ){
			in >> tri[i][j];
		}
		for( j = 0 ; j < 3; j ++ ){
			
			k = j + 1;
			if( k == 3 ) k = 0;

			l = j + 2;
			if( l > 2 )l -= 3;
			
			link[ tri[i][j] ][ num[ tri[i][j]] ][0] = i;
			link[ tri[i][j] ][ num[ tri[i][j]] ][2] = tri[i][k];
			link[ tri[i][j] ][ num[ tri[i][j]] ][1] = tri[i][l];
			num[ tri[i][j]]++;
		}
	}
}

bool visit[6];

void Dfs( int p, int hap, int cnt)
{
	int i;
	if( cnt < 5 ){
		for( i = 0 ; i < num[ p]; i ++ ){
			if( visit[ link[p][i][0]] == 0 ){
				visit[ link[p][i][0]] = 1;
				Dfs( link[p][i][2], hap + link[ p][ i][ 1], cnt + 1);
				visit[ link[p][i][0]] = 0;
			}
		}
	}
	else{
		for( i = 0 ; i < num[ p]; i ++ ){
			if( visit[ link[p][i][0]] == 0 && link[p][i][2] == tri[0][e]){
				hap += link[ p][ i][ 1];
				if( hap > Max ) Max = hap;
				break;
			}
		}
	}
}
void calc()
{
	int i,j;
	visit[0] = 1;
	for( i = 0 ; i < 3; i ++ ){
		j = i + 1;
		if( j == 3 ) j = 0;

		e = i + 2;
		if( e > 2 )e -= 3;
		
		Dfs( tri[0][i], tri[0][j], 1 ); 
	}
}
void output()
{
	if( Max == 0 )
		out << DoNot;	
	else
		out << Max;
}
void main()
{
	input();
	calc();
	output();
}
