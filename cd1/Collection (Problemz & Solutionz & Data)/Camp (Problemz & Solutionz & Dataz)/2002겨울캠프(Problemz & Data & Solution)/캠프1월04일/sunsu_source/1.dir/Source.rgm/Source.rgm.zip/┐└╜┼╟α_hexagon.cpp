#include <fstream.h>

void Input();
void Process();
void BakTrax(int level);

int in[6][3],visited[6];
int table[6][3];
long add,final;

void Input()
{
	int i,j;
	ifstream fin ("hexagon.in");
	for(i=0;i<6;i++)
		for(j=0;j<3;j++)
			fin >> in[i][j];
	fin.close();
}

void Process()
{
	visited[0]=1;
	table[0][0]=in[0][0]; table[0][1]=in[0][1]; table[0][2]=in[0][2];
	BakTrax(1);
	table[0][0]=in[0][2]; table[0][1]=in[0][0]; table[0][2]=in[0][1];
	BakTrax(1);
	table[0][0]=in[0][1]; table[0][1]=in[0][2];	table[0][2]=in[0][0];
	BakTrax(1);

	ofstream fout ("hexagon.out");
	fout << final;
	fout.close();
}

void BakTrax(int level)
{
	int i,j;

	for(i=0;i<6;i++)
	{
		if(visited[i]==0)
		{
			visited[i]=1;
			if(in[i][0]==table[level-1][1])
			{
				table[level][0]=in[i][0]; table[level][1]=in[i][1]; table[level][2]=in[i][2];
				if(level==5)
				{
					if(table[0][0]==table[level][1])
					{	
						add=0;
						for(j=0;j<level+1;j++)
							add+=table[j][2];
						if(add>final)
							final=add;
					}
				}
				else
					BakTrax(level+1);
			}
			if(in[i][2]==table[level-1][1])
			{
				table[level][0]=in[i][2]; table[level][1]=in[i][0]; table[level][2]=in[i][1];
				if(level==5)
				{
					if(table[0][0]==table[level][1])
					{	
						add=0;
						for(j=0;j<level+1;j++)
							add+=table[j][2];
						if(add>final)
							final=add;
					}
				}
				else
					BakTrax(level+1);
			}
			if(in[i][1]==table[level-1][1])
			{
				table[level][0]=in[i][1]; table[level][1]=in[i][2]; table[level][2]=in[i][0];
				if(level==5)
				{
					if(table[0][0]==table[level][1])
					{						
						add=0;
						for(j=0;j<level+1;j++)
							add+=table[j][2];
						if(add>final)
							final=add;
					}
				}
				else
					BakTrax(level+1);
			}
			visited[i]=0;
		}
	}
}

void main()
{
	Input();
	Process();
}