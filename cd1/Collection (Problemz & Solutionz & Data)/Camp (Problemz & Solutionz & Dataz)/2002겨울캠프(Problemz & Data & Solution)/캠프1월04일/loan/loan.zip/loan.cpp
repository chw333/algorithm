#include <fstream.h>
#include <string.h>
#include <conio.h>

#define MAX 102
#define TRUE 1
#define FALSE 0

void initialize(void);
void convert(void);
void process1(void);
void process2(void);

char a[MAX];
int bit[MAX];
char tlen[MAX], two[MAX][MAX];
int ans[MAX];
int aa[MAX], bb[MAX];
int possible;

void initialize(void)
{
	int q,w,e;
	
	tlen[0]=1; two[0][0]='1';
	for (q=0;q<99;q++){
		for (w=0;w<tlen[q];w++){
			two[q+1][w]+=two[q][w]*2-'0';
		}
		tlen[q+1]=tlen[q];
		for (w=0;w<tlen[q];w++){
			if (two[q+1][w]>'9') {
				two[q+1][w]-=10;
				two[q+1][w+1]++;
				if (w==tlen[q]-1) {
					two[q+1][w+1]='1';
					tlen[q+1]++;
				}
			}
		}
	}
}

void main(void)
{
	int q,w,e;
	int loop;

	initialize();

	ifstream in("loan.in");
	in>>loop;

	for (q=1;q<=loop;q++){
		in>>a;
		convert();
		possible=TRUE;
		process1();
		process2();
	}
}

ofstream out("loan.out");

void process1(void)
{
	int q,w,e;
	int what;
	for (q=0;q<=100;q++) aa[q]=0;

	for (q=0;q<=99;q++){
		if (q%2==0) {
			if (aa[q]==0) { //0 or -1
				if (bit[q]==0) {ans[q]=FALSE;}
				else {ans[q]=TRUE;}
			}
			else {	
				if (bit[q]==0) {ans[q]=TRUE;}
				else { ans[q]=FALSE; aa[q+1]--; }
			}
		}
		else {
			if (aa[q]==0) {	//0 or -1
				if (bit[q]==0) {ans[q]=FALSE; }
				else { ans[q]=TRUE; aa[q+1]--; }
			}
			else {
				if (bit[q]==0) { ans[q]=TRUE; aa[q+1]--; }
				else { ans[q]=FALSE; aa[q+1]--; }
			}
		}
	}

	if (aa[100]<0) {
		possible=FALSE;
		out<<"NIE"<<endl;
	}
	else {
		for (q=99;q>=0;q--) {
			if (ans[q]==TRUE) out<<q<<" ";
		}
		out<<endl;
	}
}

void process2(void)
{
	int q,w,e;
	int what;
	for (q=0;q<=100;q++) aa[q]=0;

	for (q=0;q<=99;q++){
		if (q%2==1) {
			if (aa[q]==0) { //0 or -1
				if (bit[q]==0) {ans[q]=FALSE;}
				else {ans[q]=TRUE;}
			}
			else {	
				if (bit[q]==0) {ans[q]=TRUE;}
				else { ans[q]=FALSE; aa[q+1]--; }
			}
		}
		else {
			if (aa[q]==0) {	//0 or -1
				if (bit[q]==0) {ans[q]=FALSE; }
				else { ans[q]=TRUE; aa[q+1]--; }
			}
			else {
				if (bit[q]==0) { ans[q]=TRUE; aa[q+1]--; }
				else { ans[q]=FALSE; aa[q+1]--; }
			}
		}
	}

	if (aa[100]<0) {
		possible=FALSE;
		out<<"NIE"<<endl;
	}
	else {
		for (q=99;q>=0;q--) {
			if (ans[q]==TRUE) out<<q<<" ";
		}
		out<<endl;
	}
}


void convert(void)
{
	int q,w,e;
	int la=strlen(a);
	char temp;
	int check;
	int what, max;

	for (q=0;q<la;q++){
		if (q>=la-1-q) break;
		temp=a[q]; a[q]=a[la-1-q]; a[la-1-q]=temp;
	}

	for (q=99;q>=0;q--){
		bit[q]=0;
		//�� �� two[q]�� a�� ũ�� ��
		la=strlen(a);
		if (tlen[q]>la) continue;
		else if (tlen[q]==la) {
			check=FALSE;
			for (w=la-1;w>=0;w--){
				if (two[q][w]>a[w]) {check=TRUE; break; }
				if (two[q][w]<a[w]) {break; }
			}
			if (check==TRUE) continue;
		}
		
		//�̱��� ��ƿ����� two[q]<=a��� �̾߱�
		bit[q]=1; max=-1;
		for (w=0;w<tlen[q];w++){
			if (a[w]==NULL) what='0'; else what=a[w];
			a[w]=what-two[q][w]+'0';
			if (a[w]<'0') {
				a[w]+=10;
				a[w+1]--;
			}
			if (a[w]>'0') max=w;
		}
		a[max+1]=NULL;	
	}

}

