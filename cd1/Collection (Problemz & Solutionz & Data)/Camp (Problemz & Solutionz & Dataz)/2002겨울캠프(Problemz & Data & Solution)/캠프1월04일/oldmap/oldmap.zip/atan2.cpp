#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

double v[10];

int main(void)
{
	//            pi*2/4
	//            o
	//   pi*3/4   |    pi*1/4
	//      o     |     o
	//            |
	//   pi       |         0 
	//  -o--------+---------o-
	//            |
	//            |
	//      o     |     o -pi*1/4
	//  -pi*3/4   o
	//           -pi*2/4

	         // y, x
	v[0]=atan2( 0, 2);
	v[1]=atan2( 1, 2);
	v[2]=atan2( 2, 2);
	v[3]=atan2( 2, 0);
	v[4]=atan2( 2, -2);
	v[5]=atan2( 0, -2);
	v[6]=atan2( -2, -2);
	v[7]=atan2( -2, 0);
	v[8]=atan2( -2, 2);

	int i;
	for(i=0; i<9; i++) {
		printf("%d, %lf\n", i, v[i]);
	}

	return 0;
}
