#include <fstream.h>
#include <stdlib.h>
#include <conio.h>

#define MAX 10002
#define MAXIMUM 9999999
#define TRUE 1
#define FALSE 0

void inputdata(void);
int process(int );
int compare(int, int, int );
void trace(int );
void outputdata(void);

int n,m;
struct BOX {
	int s,v;
} box[MAX], now[100*MAX];
int top, savetop;
int mom[100*MAX];
int st[MAX];
int use[MAX];
int cont[1002];
int answer;
int possible=TRUE;


void inputdata(void)
{
	int q,w,e;
	int aa,bb;

	ifstream in("pak07.in");
	in>>n;
	for (q=1;q<=n;q++) {
		in>>box[q].s>>box[q].v;
	}
	in>>m;
	for (q=1;q<=m;q++){
		in>>aa>>bb;
		cont[aa]+=bb;
	}
}

int sortf(const void *a, const void *b)
{
	struct BOX P=*(struct BOX *)a;
	struct BOX Q=*(struct BOX *)b;

	if (P.s>Q.s) return 1;
	else if (P.s<Q.s) return -1;
	else if (P.v>Q.v) return 1;
	else if (P.v<Q.v) return -11;
	else return 0;
}

void main(void)
{
	int q,w,e;
	inputdata();
	qsort(&box[1],n,sizeof(box[1]), sortf);

	st[0]=0;
	for (q=1;q<=n;q++) st[box[q].s]=q;
	w=0;
	for (q=1;q<=1000;q++) {
		if (st[q]==0) st[q]=w;
		else w=st[q];
	}
	box[n+1].s=MAXIMUM; box[n+1].v=MAXIMUM;

	for (q=1;q<=1000;q++){
		for (w=1;w<=cont[q];w++) {
			answer+=process(q);
		}
	}
	outputdata();
}

void outputdata(void)
{
	int q,w,e;
	ofstream out("pak.out");
	if (possible==FALSE) {
		out<<"NIE"<<endl;
		return;
	}
	out<<answer<<endl;
}

int process(int what)
{
	int q,w,e;
	int ra,rb;
	int startlevel=MAXIMUM;
	int howto;
	
	ra=0; rb=1; top=0;
	//now[]�迭�� ó�� �κ��� �ʱ�ȭ
	ra=n+1;
	for (q=1;q<=n;q++){
		if (startlevel!=MAXIMUM&&startlevel!=box[q].s) {
			ra=q;
			break;
		}
		if (use[q]==TRUE) continue;
		startlevel=box[q].s;
		top++;
		now[top].v=box[q].v;
		now[top].s=box[q].s;
		mom[top]=-1*q;
		if (now[top].s==what) {
			use[q]=TRUE;
			return now[top].v;
		}
	}
	//������ �ʹ� ������ ĿƮ
	if (startlevel>what) {
		possible=FALSE;
		return 0;
	}

	for (;;){
		if (use[ra]==FALSE) break;
		ra++;
	}

	//�������� ������ ������. 
	for (q=startlevel; ;q++) {
		savetop=top;
		for (;;){
//			cout<<"level "<<q+1<<" : ";
//			cout<<ra<<" = "<<box[ra].s<<" "<<box[ra].v<<"    vs    ";
//			cout<<rb<<"/"<<savetop<<"   : "<<now[rb].v+now[rb+1].v<<endl;
//			getch();
			howto=compare(q+1,ra,rb);
			if (howto==0) {
				rb=savetop+1;
				break;
			}
			if (howto==1) {
				top++;
				now[top].v=box[ra].v;
				now[top].s=box[ra].s;
				mom[top]=-1*ra;
				if (now[top].s==what) {
					trace(top);
					return now[top].v;
				}
				for (;;){
					ra++;
					if (use[ra]==FALSE) break;
				}
			}
			else 
			{
				top++;
				now[top].v=now[rb].v+now[rb+1].v;
				now[top].s=now[rb].s+1;
				mom[top]=rb;
				if (now[top].s==what) {
					trace(top);
					return now[top].v;
				}
				rb+=2;
			}
		}
		if (ra>n&&rb>=top) break;
	}

	possible=FALSE;
	return 0;
}

//a�� �����ؾ� �Ѵٸ� 1, b�� �����ؾ��Ѵٸ� -1 ���� ���� ��Ȳ������ 0�� ����
int compare(int level, int pa, int pb)
{
	int q,w,e;
	if (box[pa].s>level && pb>=savetop) return 0;
	if (box[pa].s>level) return -1;
	if (pb>=savetop) return 1;
	if (box[pa].v<=now[pb].v+now[pb+1].v) return 1;
	else return -1;
}

void trace(int where)
{
	int q,w,e;
	if (mom[where]<0) {
		w=-1*mom[where];
		use[w]=TRUE;
		return;
	}
	else {
		trace(mom[where]);
		trace(mom[where]+1);
		return;
	}
}
