#include <fstream.h>
#include <conio.h>

void initialize(void);
void process1(void);
void process2(void);

ifstream  in("twofive.in");
ofstream out("twofive.out");

int n;
int d[7][7][7][7][7];

void initialize(void)
{
	int q1,q2,q3,q4,q5,w,e;
	d[5][5][5][5][5]=1;

	for (q1=5;q1>=0;q1--){
		for (q2=q1;q2>=0;q2--){
			for (q3=q2;q3>=0;q3--){
				for (q4=q3;q4>=0;q4--){
					for (q5=q4;q5>=0;q5--){
						//d[q1][q2][q3][q4][q5]�� ���� ����Ѵ�
						//�̶� q1>=q2>=q3>=q4>=q5��� ��Ģ�� ��Ű�鼭 ������ ���Դ�
						if (q5+1<=q4) d[q1][q2][q3][q4][q5]+=d[q1][q2][q3][q4][q5+1];
						if (q4+1<=q3) d[q1][q2][q3][q4][q5]+=d[q1][q2][q3][q4+1][q5];
						if (q3+1<=q2) d[q1][q2][q3][q4][q5]+=d[q1][q2][q3+1][q4][q5];
						if (q2+1<=q1) d[q1][q2][q3][q4][q5]+=d[q1][q2+1][q3][q4][q5];
						if (q1<=4) d[q1][q2][q3][q4][q5]+=d[q1+1][q2][q3][q4][q5];
//				cout<<q1<<" "<<q2<<" "<<q3<<" "<<q4<<" "<<q5<<"    "<<d[q1][q2][q3][q4][q5]<<endl; getch();
					}
				}
			}
		}
	}

}


void main(void)
{
	char whatprocess[2];
	initialize();
	in>>whatprocess;
	if (whatprocess[0]=='W') process1();
	else process2();
}

//a[]�� ���° �����ټ��ھ���ϱ��?
void process1(void)
{
	int q,w,e;
	char a[27], what;
	char b[6][6];
	int q1=0,q2=0,q3=0,q4=0,q5=0;
	int answer=1;
	in>>a;

	//2���� ��Ŀ� ���ųְ�
	for (q=1;q<=5;q++){
		for (w=1;w<=5;w++){
			b[q][w]=a[(q-1)*5+w-1];
		}
	}

	//A���� ���������� ä��������. 
	for (q=1;q<=25;q++){
		what='A'+q-1;
		if (b[1][q1+1]==what) {q1++; continue; } else {answer+=d[q1+1][q2][q3][q4][q5]; }
		if (b[2][q2+1]==what) {q2++; continue; } else {answer+=d[q1][q2+1][q3][q4][q5]; }
		if (b[3][q3+1]==what) {q3++; continue; } else {answer+=d[q1][q2][q3+1][q4][q5]; }
		if (b[4][q4+1]==what) {q4++; continue; } else {answer+=d[q1][q2][q3][q4+1][q5]; }
		if (b[5][q5+1]==what) {q5++; } else {cout<<"Something is wrong!!!"<<endl; }
	}
//	cout<<answer<<endl;
	out<<answer<<endl;
}
void process2(void)
{
	int q,w,e;
	int count;
	char b[6][6];
	int q1=0,q2=0,q3=0,q4=0,q5=0;	
	
	in>>count;

	for (q=1;q<=25;q++){
//		cout<<q1<<" "<<q2<<" "<<q3<<" "<<q4<<" "<<q5<<"    "<<count<<endl; 
//		getch();
		if (count<=d[q1+1][q2][q3][q4][q5]) {q1++; b[1][q1]='A'+q-1; continue;} else {count-=d[q1+1][q2][q3][q4][q5]; }
		if (count<=d[q1][q2+1][q3][q4][q5]) {q2++; b[2][q2]='A'+q-1; continue;} else {count-=d[q1][q2+1][q3][q4][q5]; }
		if (count<=d[q1][q2][q3+1][q4][q5]) {q3++; b[3][q3]='A'+q-1; continue;} else {count-=d[q1][q2][q3+1][q4][q5]; }
		if (count<=d[q1][q2][q3][q4+1][q5]) {q4++; b[4][q4]='A'+q-1; continue;} else {count-=d[q1][q2][q3][q4+1][q5]; }
		if (count<=d[q1][q2][q3][q4][q5+1]) {q5++; b[5][q5]='A'+q-1; continue;} else {cout<<"Something is wrong!!!"<<endl; }
	}

//	for (q=1;q<=5;q++)	for (w=1;w<=5;w++) cout<<b[q][w]; cout<<endl;

	for (q=1;q<=5;q++){
		for (w=1;w<=5;w++) out<<b[q][w];
	}out<<endl;

}