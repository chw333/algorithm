#include <fstream.h>
#include <conio.h>

#define MAX 10002
#define MAXIMUM 99999
#define TRUE 1
#define FALSE 0

void initialize(void);
void process(void);
void outputdata(void);

int x;
int n,len[30];
int m;
int one[MAX], zero[MAX];
int an, bn;
char a[MAX], b[MAX];
int answer, possible;
int gone[MAX];
int index[30], list[MAX*2], ltop;
int use[30][MAX];
int ma[MAX], wa[MAX];
int mb[MAX], wb[MAX];
struct {
	int m,w;
} queue[MAX];
int head, tail;

void initialize(void)
{
	int q,w,e;
	answer=0; possible=TRUE;
	ltop=0;
	for (q=1;q<=10000;q++) {
		one[q]=0; zero[q]=0; gone[q]=0;
		ma[q]=0; wa[q]=0; 
		mb[q]=0; wb[q]=0;
		for (w=1;w<=n;w++){
			use[w][q]=0;
		}
	}
}

void main(void)
{
	int loop;
	int q,w,e;

	ifstream in("row.in");
	in>>x;
	for (loop=1;loop<=x;loop++){
		in>>n;
		for (q=1;q<=n;q++) in>>len[q];
		in>>an>>a;
		in>>bn>>b;
		initialize();
		process();
		outputdata();
	}
}

ofstream out("row.out");

void outputdata(void)
{
	int q,w,e;
	int ttt[500], tt2[500], top, plustop;
	int tencount, what;

	if (possible==FALSE) {
		out<<"NO"<<endl;
		return;
	}

	for (q=1;q<=480;q++) ttt[q]=0; tt2[1]=0;
	top=1; ttt[1]=1;
	
	for (q=1;q<=answer;q++){
		plustop=0;
		for (w=1;w<=top;w++){
			ttt[w]=ttt[w]*2;
			if (ttt[w]>100000000) {
				ttt[w]-=100000000;
				tt2[w+1]=1;
				if (w==top) plustop=1;
			}
			else {
				tt2[w+1]=0;
			}
		}
		top+=plustop;
		for (w=1;w<=top;w++) ttt[w]+=tt2[w];
	}

	out<<ttt[top];		
	for (w=top-1;w>=1;w--) {
		what=ttt[w]; tencount=1;
		for (;;){
			tencount++;
			if (what<10) break;
			what/=10;
		}
		for (e=tencount;e<=8;e++) out<<"0";
		out<<ttt[w];
	}
	out<<endl;

}

void process(void)
{
	int q,w,e;
	int stack[MAX], top;
	char pivot, what;
	int ra,rb,oa,ob; //read a, read b, output a, output b
	int aa,bb;
	int nowm, noww;
	int nextm, nextw;
	int onecheck, zerocheck;

	//0�� 1�� ����Ͽ� �ش�.
	for (q=1,w=1;q<=an;q++){
		what=a[q-1];
		if (what=='1') {
			one[w]=1; w++;
		}
		else if (what=='0') {
			zero[w]=1; w++;
		}
		else {
			for (e=w;e<w+len[what-96];e++) {
				ma[e]=what-96;
				wa[e]=e-w+1;
			}
			w+=len[what-96];
		}
	}
	m=w-1;
	for (q=1,w=1;q<=bn;q++){
		what=b[q-1];
		if (what=='1') {
			one[w]=1; w++;
		}
		else if (what=='0') {
			zero[w]=1; w++;
		}
		else {
			for (e=w;e<w+len[what-96];e++){
				mb[e]=what-96;
				wb[e]=e-w+1;
			}
			w+=len[what-96];
		}
	}
	


	//�̰� ������� ���ڿ��� ����
	if (m!=w-1) {
		possible=FALSE;
		return;
	}
	ltop=0;
	for (q=1;q<=n;q++){
		ra=0; rb=0; 
		oa=1; ob=1;
		pivot='a'+q-1;
		for (;;){
			if (ra<rb) {
				what=a[ra];ra++;
				if (what=='0'||what=='1') oa++; 
				else {
					if (what==pivot) {
						ltop++;
						list[ltop]=oa;
						index[q]=ltop;
					}
					oa+=len[what-'a'+1];
				}
				
			}
			else {
				what=b[rb];rb++;
				if (what=='0'||what=='1') ob++; 
				else {
					if (what==pivot) {
						ltop++;
						list[ltop]=ob;
						index[q]=ltop;
					}
					ob+=len[what-'a'+1];
				}
				
			}
			if (ra>an&&rb>bn) break;
		}
	}
/*
	for (q=1;q<=m;q++) cout<<one[q]<<" "; cout<<endl;
	for (q=1;q<=m;q++) cout<<zero[q]<<" "; cout<<endl;
	for (q=1;q<=m;q++) cout<<ma[q]<<" "; cout<<endl;
	for (q=1;q<=m;q++) cout<<wa[q]<<" "; cout<<endl;
	for (q=1;q<=m;q++) cout<<mb[q]<<" "; cout<<endl;
	for (q=1;q<=m;q++) cout<<wb[q]<<" "; cout<<endl;
	cout<<endl;
*/
	use[0][0]=TRUE;
	for (q=1;q<=m;q++){
		if (gone[q]==TRUE) continue;
		head=0; tail=0;
		onecheck=one[q];
		zerocheck=zero[q];

		//ť�� �߰�
		if (use[ma[q]][wa[q]]==FALSE) {
			use[ma[q]][wa[q]]=TRUE;
			tail++;
			queue[tail].m=ma[q];
			queue[tail].w=wa[q];
		}
		if (use[mb[q]][wb[q]]==FALSE) {
			use[mb[q]][wb[q]]=TRUE;
			tail++;
			queue[tail].m=mb[q];
			queue[tail].w=wb[q];
		}
		for (;;){
			head++;
			nowm=queue[head].m;
			noww=queue[head].w;
			for (w=index[nowm-1]+1;w<=index[nowm];w++){
				nextw=list[w]+noww-1;
				gone[nextw]=TRUE;
				if (one[nextw]==TRUE) onecheck=TRUE;
				if (zero[nextw]==TRUE) zerocheck=TRUE;
				if (use[ma[nextw]][wa[nextw]]==FALSE) {
					use[ma[nextw]][wa[nextw]]=TRUE;
					tail++;
					queue[tail].m=ma[nextw];
					queue[tail].w=wa[nextw];
				}
				if (use[mb[nextw]][wb[nextw]]==FALSE) {
					use[mb[nextw]][wb[nextw]]=TRUE;
					tail++;
					queue[tail].m=mb[nextw];
					queue[tail].w=wb[nextw];
				}
			}
			if (head>=tail) break;
		}
		
		if (zerocheck==TRUE&&onecheck==TRUE) {	possible=FALSE;	return;	}
		if (zerocheck==FALSE&&onecheck==FALSE) {answer++;	}
	}
}
