#include <fstream.h>
#include <stdlib.h>


#define MAX 3003
#define MAXm 15002
#define MAXIMUM 9999999
#define TRUE 1
#define FALSE 0

void inputdata(void);
void process(void);
void process2(void);
void process3(void);
void roll(int, int, int);
void outputdata(void);

int n,m;
int pa,pb;
int da[MAX], db[MAX];
short int na[MAX], a[MAX][MAX];
short int nb[MAX], b[MAX][MAX];
char bcheck[MAX][MAX];
int use[MAX];
int minloop[MAX];
int mom[MAX];
int start,save;
int path[MAX], gone[MAX];
int group[MAX];
int stack[MAX], top;

struct {
	int a,b,use;
} edge[MAXm];
int answer;

void inputdata(void)
{
	int q,w,e;
	int aa,bb;
	char ttt[122];
	ifstream in("chaser.in");
//	ifstream im("chaser21.out");  im>>ttt; cout<<ttt<<endl;


	in>>n>>m>>pa>>pb;
	for (q=1;q<=m;q++){
		in>>edge[q].a>>edge[q].b;
		aa=edge[q].a;
		bb=edge[q].b;
		na[aa]++; a[aa][na[aa]]=bb;
		na[bb]++; a[bb][na[bb]]=aa;
	}
}

void main(void)
{
	inputdata();
	process();
//	cout<<"process 1 finished"<<endl;
	process2();
//	cout<<"process 2 finished"<<endl;
	process3();
//	cout<<"process 3 finished"<<endl;
	outputdata();
}

void outputdata(void)

{
	int q,w,e;
	ofstream out("chaser.out");
	if (answer==0) {
		out<<"NIE"<<endl;
//		cout<<"NIE"<<endl;
		return;
	}
	out<<answer<<endl;
//	cout<<answer<<endl;
}

//da[], db[]�迭�� �ʱ�ȭ
void process(void)
{
	int q,w,e;
	int queue[MAX], qdata[MAX], head, tail;
	int min, now, data,next;
	//da[]�迭 �ʱ�ȭ (�ϸ鼭 b[][]�迭�� �ʱ�ȭ �Ѵ�.)
	head=0; tail=1;
	queue[1]=pa; qdata[1]=1; da[pa]=1;
	for (;;){
		head++;
		now=queue[head];
		data=qdata[head];
		for (q=1;q<=na[now];q++){
			if (da[a[now][q]]!=0) continue;

			nb[now]++;
			b[now][nb[now]]=a[now][q];
			mom[a[now][q]]=now;
			bcheck[a[now][q]][now]=TRUE;
			bcheck[now][a[now][q]]=TRUE;

			da[a[now][q]]=data+1;
			tail++;
			queue[tail]=a[now][q];
			qdata[tail]=data+1;
		}
		if (head>=tail) break;
	}
	//db[]�迭 �ʱ�ȭ
	head=0; tail=1;
	queue[1]=pb; qdata[1]=1; db[pb]=1;
	for (;;){
		head++;
		now=queue[head];
		data=qdata[head];
		for (q=1;q<=na[now];q++){
			if (db[a[now][q]]!=0) continue;
			db[a[now][q]]=data+1;
			tail++;
			queue[tail]=a[now][q];
			qdata[tail]=data+1;
		}
		if (head>=tail) break;
	}

	//stack[]�� a�� �� �� �ִ� �κ� �ֱ� 
	stack[top=1]=pa;
	for (q=1;q<=top;q++){
		now=stack[q];
		for (w=1;w<=na[now];w++){
			if (use[a[now][w]]!=0) continue;
			if (da[a[now][w]]>=db[a[now][w]]) continue;
			use[a[now][w]]=1;
			top++;
			stack[top]=a[now][w];
		}
	}
}

//minloop[]�迭�� �ʱ�ȭ�Ѵ�.
void process2(void)
{
	int q,w,e;
	int aa,bb;
	int what, opp;
	int stack[MAX], top;

	for (q=1;q<=m;q++){
		aa=edge[q].a; bb=edge[q].b;
		if (bcheck[aa][bb]==TRUE) continue;
		if (da[aa]>da[bb]) {
			w=aa; aa=bb; bb=w;
		}
		e=bb; top=0;
		for (w=1;w<=da[bb]-da[aa];w++){
			minloop[e]=TRUE;
			e=mom[e];
		}
		w=aa;
		for (;;){
			if (w==e) {
				minloop[w]=TRUE;
				break;
			}
			minloop[w]=TRUE;
			minloop[e]=TRUE;
			w=mom[w]; 
			e=mom[e];
		}

	}

}

	
void process3(void)
{
	int q,w,e;
	int check;

	for (q=1;q<=n;q++){
		if (minloop[q]!=0) {
			if (da[q]<db[q]) {
//				cout<<"1.living point is "<<q<<endl;
				return;
			}
		}
	}

	answer=-1;
	//�̱��� ������ A�� ������
	for (q=1;q<=top;q++) {
		if (db[stack[q]]-1>answer) answer=db[stack[q]]-1;	
	}
}