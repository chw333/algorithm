#include <fstream.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAXN 1000

int N;
int List[MAXN+1][2];
int Set1[MAXN+1], Set2[MAXN+1];

#define INFILE "chaser"
#define OUTFILE "chaser.out"


int two(int a, int b)
{
	int n = a+b;
	int s=1;
	for(;;) {
		s*=2;
		if(s < n ) continue;
		else {
			break;
		}
	}
	if(s==n) return 1;
	return 0;
}

int test(int num)
{
	int i;
	char instr[50], inchar;
	char aa[10000], bb[10000];
	sprintf(instr, "%s%02d.out", INFILE, num);
	ifstream in(instr);
	ifstream yourin(OUTFILE);
	
	for (;;){
		in>>aa;
		yourin>>bb;
		if (strcmp(aa,bb)!=0) {
			cout<<aa<<" is diffrent "<<bb<<endl;
			return 0;
		}
		if (in.eof()!=yourin.eof()) return 0;
		if (in.eof()==1) break;
	}

	return 1;
}



int main(int argc, char **argv)
{
	int i, sum=0;
	int testcase=16;
	char str[50];

	if(argc<2) {
		cout << "test [inputfile]" << endl;
		cout << "--------------------------------" << endl;
		cout << "      inputfile = �������� �̸� " << endl;
		cout << "      �� = test ���_source.exe " << endl;
		return 0;
	}

	for(i=1; i<=testcase; i++) {
        //������ ����
		sprintf(str, "copy %s%02d.in %s.in >> log.txt", INFILE, i, INFILE);
		system(str);
		sprintf(str, "������ �����Ͽ���. %s%02d.in -> %s.in", INFILE, i, INFILE);
		cout << str << endl;

		//���α׷� ������� ������ ��.
		sprintf(str, argv[1]);
		system(str);
		sprintf(str, "���α׷� ����", INFILE, i, INFILE);
		cout << str << endl;

		//ä��
		if(test(i)==1) {
			sum++;
			cout << "��ȣ" << sum << " �����Ͽ����ϴ�. "<< endl;
		} else {
			cout << "no good" << endl;
		}

	}

	char *p;
	strcpy(str, argv[1]);
	p = strchr(str, '.');
	p[0]=0;
	strcat(str, ".ans");

	ofstream out(str);
	out << 100 * sum / testcase << endl;
	cout << endl << "���� : " << 100 * sum / testcase << endl;

	return 0;
}

