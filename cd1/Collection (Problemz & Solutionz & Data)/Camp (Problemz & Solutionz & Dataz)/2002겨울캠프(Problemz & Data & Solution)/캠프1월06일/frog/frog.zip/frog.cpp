#include <fstream.h>

#define MAX 5002

void inputdata(void);
void quick(int, int);
void process(void);
void outputdata(void);

int n;
int maxx, maxy;
int ax[MAX], ay[MAX];
short int d[MAX][MAX];
int answer;

ifstream in("frog.in");
ofstream ot("frog.out");


void inputdata(void)
{
	int q,w,e;

	in>>maxy>>maxx;
	in>>n;
	for (q=1;q<=n;q++){
		in>>ay[q]>>ax[q];
	}
}

void main(void)
{
	inputdata();
	quick(1,n);
	process();
	outputdata();
}

void outputdata(void)
{
	int q,w,e;
	ot<<answer<<endl;
}

void process(void)
{
	int q,w,e;
	int gay,gax, gby,gbx;
//	for (q=1;q<=n;q++) cout<<ay[q]<<" "<<ax[q]<<endl; return;

	for (q=1;q<=n;q++) {
		w=q+1; e=q+2;
		for (;;){
			gay=ay[w]-ay[q]; gax=ax[w]-ax[q];
			gby=ay[e]-ay[w]; gbx=ax[e]-ax[w];
			if (gax==gbx&&gay==gby) {
//				cout<<q<<"("<<ax[q]<<","<<ay[q]<<") "<<w<<"("<<ax[w]<<","<<ay[w]<<") "<<e<<"("<<ax[e]<<","<<ay[e]<<")   ";
				if (d[q][w]==0) {
					if (gay>=ay[q]||gax>=ax[q]||ax[q]-gax>maxx) {
//						cout<<"inserted"<<endl;
						d[w][e]=3;
						if (ay[e]+gay>maxy||ax[e]+gax<=0||ax[e]+gax>maxx) {
							if (d[w][e]>answer) answer=d[w][e];
						}
					}
//					else cout<<endl;
				}
				else {
					d[w][e]=d[q][w]+1;
					if (ay[e]+gay>maxy||ax[e]+gax<=0||ax[e]+gax>maxx) {
						if (d[w][e]>answer) answer=d[w][e];
					}
//					cout<<"inserted"<<endl;
				}
				
				w++; e++;
			}
			else if (gay<gby) {
				w++;
			}
			else if (gay==gby) {
				if (ax[w]+gax<ax[e]) w++;
				else e++;
			}
			else {
				e++;
			}
			if (e>n) break;
		}
//		break;
	}
	return;
	for (q=1;q<=n;q++){
//		for (w=1;w<=n;w++) cout<<d[q][w]<<" "; cout<<endl;
	}
}

void quick(int l, int r)
{
	int pivot=ay[r];
	int pivot2=ax[r];
	int i=l-1, j=r;
	int temp;
		
	if (l>=r) return;

	for (;;){
		while ( (pivot>ay[++i])||(pivot==ay[i]&&pivot2>ax[i]) );
		while ( (pivot<ay[--j])||(pivot==ay[j]&&pivot2<ax[j]) );

		if (i>j) break;
		temp=ax[i]; ax[i]=ax[j]; ax[j]=temp;
		temp=ay[i]; ay[i]=ay[j]; ay[j]=temp;
	}
	temp=ax[i]; ax[i]=ax[r]; ax[r]=temp;
	temp=ay[i]; ay[i]=ay[r]; ay[r]=temp;
	quick(l,i-1);
	quick(i+1,r);

}