#include <fstream.h>
#include <stdlib.h>

#define Nx 100
#define Ax 250
#define Dx 250

ifstream in  ( "lazy10.in" );
ofstream out ( "lazy10.out" );

struct Job {
	int t;
	int a;
	int aa;
	int d;
} J[Nx];

int N, V[Nx], Result;

void input()
{
	int i;
	in>>N;
	for(i=0; i<N; i++) {
		in>>J[i].t>>J[i].a>>J[i].d;
		J[i].aa=J[i].d-J[i].t+1;
	}
}

int process(int t)
{
	int i, min=2000000000, min2=2000000000, tmp;
	if(t==Dx) return 0; 
	for(i=0; i<N; i++) {
//		if(t==0) cout << i << endl;
		if(V[i]==0) {
			if(J[i].a<=t && t<=J[i].aa){
				V[i]=1;
				tmp=process(t+J[i].t)+J[i].t;
				V[i]=0;
				if(min>tmp)min=tmp;
			} else if(t<J[i].a){
				if(J[i].a<min2){
					min2=J[i].a;
				}
			}
		}
	}	
	if(min==2000000000) {
		if(min2==2000000000) return 0;
		else min=process(min2);
	}
	return min;
}

void output()
{
	out<<Result;
}

void datagen()
{
	ofstream oo ("lazy10.in");
	int n=100, i, t, s, e;
	oo << n;
	for(i=0; i<n; i++){
		t=rand()%50+1;
		s=rand()%180+1;
		e=s+t+rand()%20+1;
		oo << endl;
		oo << t << " " << s << " " << e;
	}
}	

void main()
{

	input();
	Result=process(0);
	output();
//	datagen();
}