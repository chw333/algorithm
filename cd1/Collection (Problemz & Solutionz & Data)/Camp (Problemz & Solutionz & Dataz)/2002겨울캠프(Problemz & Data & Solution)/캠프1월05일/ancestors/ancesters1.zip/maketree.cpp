#include <fstream.h>
#include <stdlib.h>
#include <time.h>

#define MAX 100009

int a[MAX];
int oa[MAX], ob[MAX];

void main(void)
{
	int q,w,e;
	int n;
	int aa,bb;
	int wa, wb;

	cin>>n;
	cout<<"��尡 "<<n<<"���� Ʈ���� �����մϴ�"<<endl;

	srand( (unsigned) time (NULL) );

	q=(rand()*rand())%n+1;
	a[q]=1;
	cout<<"root : "<<q<<endl;
	for (q=1;q<n;q++){
		for (;;){
			aa=(rand()*rand())%n+1;
			if (a[aa]==1) break;
		}
		for (;;){
			bb=(rand()*rand())%n+1;
			if (a[bb]==0) break;
		}
		a[bb]=1;
		oa[q]=aa;
		ob[q]=bb;

	}	

	for (q=1;q<10*n;q++){
		aa=(rand()*rand())%(n-1)+1;
		bb=(rand()*rand())%(n-1)+1;
		w=oa[aa]; oa[aa]=oa[bb]; oa[bb]=w;
		w=ob[aa]; ob[aa]=ob[bb]; ob[bb]=w;
	}
	ofstream out("ancesters10.in");
	out<<n<<endl;
	for (q=1;q<n;q++) out<<oa[q]<<" "<<ob[q]<<endl;
	aa=(rand()*rand())%n+1; 
	for (;;){
		bb=(rand()*rand())%n+1;
		if (aa!=bb) break;
	}
	out<<aa<<" "<<bb<<endl;
}
