#include <fstream.h>

#define MAX 100002
#define TRUE 1
#define FALSE 0

void inputdata(void);
void process(void);

int n;
int m[MAX];
int sa,sb;
int gone[MAX];

ifstream in("ancesters10.in");
ofstream ot("ancesters10.out");

void inputdata(void)
{
	int q,w,e;
	int aa,bb;
	in>>n;
	for (q=1;q<n;q++){
		in>>aa>>bb;
		m[bb]=aa;
	}
	in>>sa>>sb;

}

void main(void)
{
	inputdata();
	process();
}

void process(void)
{
	int q,w,e;

	for (q=sa;q!=0;q=m[q]){
		gone[q]=TRUE;
	}
	for (q=sb;q!=0;q=m[q]){
		if (gone[q]==TRUE) {
			ot<<q<<endl;
			return;
		}
	}
}