#include <fstream.h>
#include <stdlib.h>
#include <time.h>

#define INFILE "disk10.in"
#define OUTFILE "disk10.out"

#define MAXN (100+2)

int N, T, M;
int Song[MAXN];
int MaxSong;
int D[MAXN][MAXN][MAXN];



#define MAKEN 100
#define MAKET 30
#define MAKEM 12
#define MAKERANGE 20

void makedata()
{
	ofstream out(INFILE);
	out << MAKEN << " " << MAKET << " " << MAKEM << endl;
	int i, v;
	srand(time(NULL));
	for(i=0; i<MAKEN; i++) {
		if(i!=0) out << " ";
		v=rand()%MAKERANGE +1;
		out << v;
	}
}


//a���� b������ ��ũ �뷮 T�� ���� �� �ִ�
//�ִ� �뷡�� ���� ���
int sortf(const void *a, const void *b)
{
	int *p=(int *)a, *q=(int *)b;
	return *p-*q;
}
int calc(int a, int b)
{
	if( D[a][b][1] ) return D[a][b][1];

	int S[MAXN];
	int i, l, sum;
	for(i=a; i<=b; i++) {
		S[i-a]=Song[i];
	}
	qsort(S, b-a+1, sizeof(S[0]), sortf);

	D[a][b][1]=b-a+1;

	sum=0;
	l=b-a;
	for(i=0; i<=l; i++) {
		sum+=S[i];
		if(sum > T) {
			D[a][b][1]=i;
			break;
		}
	}
	return D[a][b][1];
}


int mf(int a, int b, int group)
{
	if( D[a][b][group] ) return D[a][b][group];
	if(group<=1) {
		D[a][b][group]=calc(a, b);
		return D[a][b][group];
	}

	int i, v, max=0;
	for(i=a+group-2; i<b; i++) {
		v=mf(a, i, group-1);
		v+= calc(i+1, b);
		if(max < v) {
			max=v;
		}
	}
	D[a][b][group]=max;
	return max;
}

void disk()
{
	ifstream in(INFILE);
	in >> N >> T >> M;
	int i, j, k, g;
	for(i=0; i<N; i++) {
		in >> Song[i];
	}

	MaxSong=mf(0,N-1,M);

	ofstream out(OUTFILE);
	out << MaxSong;
}


void main()
{
	//makedata();
	disk();
}
