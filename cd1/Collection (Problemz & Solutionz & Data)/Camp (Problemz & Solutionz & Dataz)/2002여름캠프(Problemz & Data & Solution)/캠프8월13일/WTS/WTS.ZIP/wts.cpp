#include <fstream.h>
#include <string.h>
#include <stdlib.h>
#define Max 200

ifstream in("wts.in");
ofstream out("wts.out");

long StartArr[Max][Max];
long Arr[Max][Max];
int N, M;
long maxWater=0;

int Path[Max];
long Distance[Max];
long PathFlow;

int vis[Max];
int maxPipe;

long Min(long a, long b)
{
	return (a>b)? b:a;
}

int FindPath()
{
	int i, start=0,end=N-1;
	int visit[Max]={0,};
	long max, min;

	for(i=1; i<=end; i++) {
		Distance[i]=Arr[0][i];
		Path[i]=0;
	}
	visit[0]=1;

	for(;;) {
		max=0;
		for(i=1; i<=end; i++) {
			if(visit[i]==0 && max<Distance[i]) {
				start=i;
				max=Distance[i];
			}
		}

		PathFlow=max;
		if(max==0) return 0;
		if(start==end) return 1;

		visit[start]=1;
		for(i=1; i<=end; i++) {
			if(visit[i]==0 && Arr[start][i]!=0) {
				min=Min(Distance[start] , Arr[start][i]);
				if(min > Distance[i]) {
					Distance[i]=min;
					Path[i]=start;
				}
			}
		}
	}
}


void flood_fill(int node)
{
    vis[node]=1;
    int i;
    for(i=0; i<N; i++) {
        if(vis[i]==0 && Arr[node][i]>0) flood_fill(i);
    }
}

void main()
{
	int i,j, start, end;
	long c;
	char str[100], tok[10]="-,", *p;
  
	in >> N >> M;
	for(i=0; i<M; i++) {
		in >> start >> end;
		in >> c;
		Arr[start-1][end-1]=c;
		StartArr[start-1][end-1]=c;	
	}

	int prev, cur;
	while(FindPath()){
		maxWater+=PathFlow;
		cur=N-1;
		for(;;) {
			prev=Path[cur];
			Arr[prev][cur]-=PathFlow;
			Arr[cur][prev]+=PathFlow;
			if(prev==0) break;
			cur=prev;
		}
	}

	flood_fill(0);

	out << maxWater << endl;
	for(i=0; i<N-1; i++) {
		for(j=1; j<N; j++) {
			if(vis[i]==1 && vis[j]==0 && StartArr[i][j]) {
				maxPipe++;
			}
		}
	}
	out << maxPipe << endl;
	for(i=0; i<N-1; i++) {
		for(j=1; j<N; j++) {
			if(vis[i]==1 && vis[j]==0 && StartArr[i][j]) {
				out << i+1 <<" " << j+1 << endl;
			}
		}
	}
}
