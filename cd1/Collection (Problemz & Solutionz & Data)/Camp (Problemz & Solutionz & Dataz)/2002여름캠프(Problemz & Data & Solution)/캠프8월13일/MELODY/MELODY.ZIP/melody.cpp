#include<fstream.h>
#include<string.h>
#include<stdlib.h>
#define infile "melody.in"
#define outfile "melody.out"
#define MAX 301
#define MMAX(a,b) (a>b)?a:b
#define Min(a,b) (a>b)?b:a
int N,M,Map[MAX][MAX],D[MAX][MAX];
char City[MAX][MAX];
void input(void)
{
	int i,j,a,b;
	char data[2][MAX];
	ifstream in(infile);
	in >> N >> M;
	strcpy(City[1],"S");
	strcpy(City[N],"E");
	for(i=2;i<N;i++) itoa(i-1,City[i],10);
	for(i=1;i<=M;i++){
		in >> data[0] >> data[1];
		for(j = 1;j<=N;j++){
			if(strcmp(data[0],City[j])==0)
				a = j;
			if(strcmp(data[1],City[j])==0)
				b = j;
		}
		Map[a][b] = Map[b][a] = 1;
	}
}
void process(void)
{
	int i,j,k,start;
	for(i = 1;i<=N;i++){
		if(Map[1][i] == 1) D[1][i] = 2;
		if(Map[i][1] == 1) D[i][1] = 2;
	}
	for(i = 1;i<=N;i++){
		for(j = 1;j<=N;j++){
			if(i != j && D[i][j] > 0){
				start = MMAX(i,j);
				for(k = Min(start,N);k<=N;k++){
					if(Map[i][k] == 1){
						if(D[k][j] < D[i][j]+1){
							D[k][j] = D[i][j]+1;
						}
					}
					if(Map[k][j] == 1){
						if(D[i][k] < D[i][j]+1){
							D[i][k] = D[i][j]+1;
						}
					}
				}
			}
		}
	}
}
void output(void)
{
	ofstream out(outfile);
	if(D[N][N] == 0) out << 1;
	else out << D[N][N]-1;
}
void main(void)
{
	input();
	process();
	output();
}