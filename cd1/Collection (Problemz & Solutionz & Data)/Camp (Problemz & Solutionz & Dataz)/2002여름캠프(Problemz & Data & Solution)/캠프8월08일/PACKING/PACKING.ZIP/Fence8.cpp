/*
ID: cee09001
PROG: fence8
*/

#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <string.h>

#define INFILE  "packing09.in"
#define OUTFILE "ryu.out"
#define BANG 40

#define max(x,y) ((x>y)?x:y)
#define min(x,y) ((x<y)?x:y)

#define BMAX 200
#define RMAX 1024

int B,R;
int Board[BMAX];
int Rail[RMAX];
long RailS[RMAX];
//int BoardS[BMAX];
int Result;
long Boards;

int sort_function ( const void *a, const void *b )
{
	int A = *(int *) a;
	int B = *(int *) b;
	if ( A > B ) return 1;
	else if ( A == B ) return 0;
	else return -1;
}


void input()
{
	int i, tmp, gabangkki;
	ifstream in ( INFILE );
	in >> R >> gabangkki;
	B = BANG;
//	in >> B >> gabangkki;
	for ( i = 0; i < B; i ++ ) {
//		in >> tmp;
		Board[i] = gabangkki;
	}

	//in >> R >> gabangkki;
	for ( i = 0; i < R; i ++ ) {
		in >> Rail[i];
//		Rail[i] = gabangkki; 
	}
}

void output()
{
	ofstream out ( OUTFILE );
	cout << "("<<R<<")"<< Result << endl;
}

void cal_sum_rail()
{
	int i,sum;
	RailS[0]=Rail[0];
	for ( i = 1; i < R; i ++ ) {
		RailS[i] = RailS[i-1]+Rail[i];
	}
}

void cal_sum_board()
{
	int i, sum;
	Boards = 0;
	for ( i = 0; i < B; i ++ ) {
		Boards += Board[i];
	}
}

int check ( int rail, int st )
{
	int i,j, ret=0, flag=0, tmp, tmp2;
//	if ( Boards < RailS[rail] ) return 0;

	for ( i=st; i<B; i ++ ) {
		if ( Board[i] >= Rail[rail] ) {
			if ( rail == 0 ) {	ret = 1; break;	}
			if ( Board[i] < Rail[0] + Rail[rail] ) tmp = Board[i];
			else tmp = Rail[rail];
			if ( Boards - tmp < RailS[rail-1] ) continue;
			for ( j = 0; j < i; j ++ ) {
				if ( Board[j] == Board[i] ) break;
			}
			if ( j < i ) continue;
			Board[i] -= tmp;
			Boards -= tmp;
			ret = check( rail - 1, 0 );
			Board[i] += tmp;
			Boards += tmp;
			if ( ret == 1 ) break;
		}
	}
	return ret;
}

void process ()
{
	int i;
	qsort((void *)Rail, R, sizeof(Rail[0]), sort_function);
	cal_sum_rail();
	cal_sum_board();

	for ( i = 0; i < R; i ++ ) {
		if ( !check ( i, 0 ) ) {
			Result = i;
			return;
		}
	}
	Result = i;
}

void main()
{
	input();
	process();
	output();
}