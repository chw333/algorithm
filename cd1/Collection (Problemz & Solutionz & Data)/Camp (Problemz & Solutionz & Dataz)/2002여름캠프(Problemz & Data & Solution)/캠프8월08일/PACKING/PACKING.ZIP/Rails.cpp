
#include <stdio.h>
#include <stdlib.h>

#define INFILE  "packing09.in"
#define OUTFILE "ryu.out"
#define BANG 48

#define MAXBOARD 100
#define MAXRAILS 1024

int boards[MAXBOARD];
int nboard; /* number of boards */

/* rails are kept in increasing order */
int rails[MAXRAILS];
int nrails; /* number of rails wanted */

/* prefix sums of the length of rails */
/* e.g. railsum[2] = rails[0] + rails[1] + rails[2] */
long railsum[MAXRAILS];

/* sum of the lengths of boards remaining */
long boardsum = 0;

int try_rail(int i, int st)
 { /* see if we can cut rails 0...i using the remaining boards */
   /* st = board to start checking from */
  int lv, lv2; /* loop variables */
  int rv = 0, t;
  long max;
  int tmp;

  if (i == 1)
   { /* last two boards */
    int f1, f2; /* f[1,2] = found a board for rails[0,1] */

    f1 = f2 = 0;
    for (lv = 0; lv < nboard && (f1 + f2) < 2; lv++)
     {
      if (boards[lv] >= rails[1])
       { /* can cut rails[1] */
        f2++;
         
	/* can we cut both? */
        if (boards[lv] >= rails[0] + rails[1]) 
	 return 1;
       } else if (boards[lv] >= rails[0]) f1=1; /* can cut rail[0] */
     }
    return (f1 + f2) >= 2;
   }

  if (i <= 0)
   { /* handle singleton case */
    for (lv = 0; lv < nboard; lv++)
      if (boards[lv] >= rails[i])
        return 1;
    return 0;
   }

  for (lv = st; lv < nboard; lv++)
   {
    if (boards[lv] > rails[i])
     { /* this board can handle it with left over */

      /* determine amount to cut */
      /* if amount left < rails[0], then we might as well cut all */
      if (boards[lv] < rails[0] + rails[i]) tmp = boards[lv];
      else tmp = rails[i];

      /* make sure there's enough board left after this cut */
      if (boardsum - tmp < railsum[i-1]) continue; 

      /* see if we've already tried to cut a board of this length */
      for (lv2 = 0; lv2 < lv; lv2++)
        if (boards[lv] == boards[lv2])
	  break;
      if (lv2 < lv) continue;

      /* cut board */
      boards[lv] -= tmp;
      boardsum -= tmp;

      /* if next rails (rails[i-1]) is of the same length, then
         it has to be cut from either this board or a later one */
      if (rails[i-1] == rails[i])
        t = try_rail(i-1, lv);
      else /* otherwise, allow the rail to be cut from anywhere */
        t = try_rail(i-1, 0);

      /* uncut rail */
      boards[lv] += tmp;
      boardsum += tmp;

      if (t) return 1; /* we found a solution! */
     } else if (boards[lv] == rails[i])
     { /* we found an exact match, we might as well just use it */
      boards[lv] -= rails[i];
      boardsum -= rails[i];
      if (rails[i-1] == rails[i])
        t = try_rail(i-1, lv);
      else
        t = try_rail(i-1, 0);
      boards[lv] += rails[i];
      boardsum += rails[i];
      return t;
     }
   }

  return 0; /* didn't find a solution */
 }

/* comparer used for qsort */
int int_comp(const void *p1, const void *p2)
 {
  if (*(int *)p1 > *(int *)p2)
    return 1;
  else
    return -1;
 }

int main(int argc, char **argv)
 {
  FILE *fout, *fin;
  int lv; /* loop variable */
  int max;
  long sum;
  int bangkki;

  if ((fin = fopen(INFILE, "r")) == NULL)
   {
	perror ("fopen fin");
	exit(1);
   }
  if ((fout = fopen(OUTFILE, "w")) == NULL)
   {
	perror ("fopen fout");
	exit(1);
   }

  fscanf (fin, "%d %d", &nrails, &bangkki);

  //fscanf (fin, "%d", &nboard);
  nboard=BANG;
  for (lv = 0; lv < nboard; lv++) {
	//fscanf (fin, "%d", &boards[lv]);
	  boards[lv]=bangkki;
  }

  //fscanf (fin, "%d %d", &nrails, bangkki);
  for (lv = 0; lv < nrails; lv++)
    fscanf (fin, "%d", &rails[lv]);

  /* sort the rails */
  qsort(rails, nrails, sizeof(rails[0]), int_comp);

  /* determine the maximum numer of rails that we could get,
     just based on total board-feet */
  sum = 0;

  /* sum the board lengths */
  for (lv = 0; lv < nboard; lv++)
    sum += boards[lv];

  /* subtract out rails, starting at smallest, until sum goes negative */
  for (lv = 0; lv < nrails && sum >= 0; lv++)
    sum -= rails[lv];

  if (sum >= 0)
    max = lv; 
  else
    max = lv-1; /* we got all the boards */

  /* calculate prefix sums */
  sum = 0;
  for (lv = 0; lv < max; lv++)
   {
    sum += rails[lv];
    railsum[lv] = sum;
   }

  /* initialize boardsum */
  for (lv = 0; lv < nboard; lv++)
    boardsum += boards[lv];

  /* start lv at 0, keep increamenting lv as long as
     cutting 0...lv is possible */
  for (lv = 0; lv < max && try_rail(lv, 0); lv++)
    ;

  /* 0..lv-1 is possible, for a total of lv boards */
  //fprintf (fout, "%i\n", lv);
  printf ("%i\n", lv);

  return 0;
 }
