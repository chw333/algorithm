#include <fstream.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define INFILE "packing09.in"
#define OUTFILE "packing09.out"
#define MAXN 100

int N, T;
int Bag[MAXN];
int Visit[MAXN];
int MinBag=MAXN+10;


#define MAKEN 90
#define MAKET 50

void makedata()
{
	int i,v;
	srand(time(NULL));

	ofstream out(INFILE);
	out << MAKEN << " " << MAKET;
	for(i=0; i<MAKEN; i++) {
		if(i%10 == 0) out << endl;
		else out << " ";
		v=rand()%MAKET + 1;
		out << v;
	}
}

int bagnum()
{
	int cnt=0;
	int i, sum=0;
	for(i=0; i<N; i++) {
		if(Visit[i]==1) continue;
		if(sum+Bag[i] > T) {
			sum=Bag[i];
			cnt++;
		} else {
			sum+=Bag[i];
		}
	}
	if(sum!=0) {
		cnt++;
	}

	return cnt;
}

/*
int boundbagnum()
{
	int cnt=0;
	int i, minv=0;
	for(i=0; i<N; i++) {
		if(Visit[i]==0) {
			minv=Bag[i];
			break;
		}
	}

	for(; i<N; i++) {
	}
	if(sum!=0) {
		cnt++;
	}

	return cnt;
}
*/


void dfs(int idx, int bagcnt)
{
	int i, j, sum, bag, newidx;
	int visitBag[MAXN/2], visitBagCnt=0;

	Visit[idx]=1;

	for(i=idx+1; i<N; i++) {
		sum=Bag[idx];
		for(j=i; j<N; j++) {
			if(Visit[j]==1) continue;

			if(sum+Bag[j] > T) {
				break;
			}
			sum+=Bag[j];
			Visit[j]=1;
			visitBag[visitBagCnt]=j;
			visitBagCnt++;
		}

		for(j=idx+1; j<N; j++) {
			if(Visit[j]==0) {
				newidx=j;
				break;
			}
		}
		//���̻� ���ο� ���� ã�� �� ���� ��
		//�Ѳ����� ��� �ϳ��� �鿡 ���� �� ����.
		//���� �Ǵ� �����.
		if(j==N) {
			if(MinBag > bagcnt) {
				MinBag=bagcnt;
			}
		} else {
			sum=0;
			for(j=idx+1; j<N; j++) {
				if(Visit[j]==0) {
				    sum+=Bag[j];
				}
			}
			bag=(sum+(T-1))/T;
			if(bagcnt+bag < MinBag) {
				if(bag==1) {
					//���� �ϳ���
					//bagcnt+1�� ���� �ȴٴ� ��.
					if(MinBag > bagcnt+1) {
						MinBag=bagcnt+1;
						cout << MinBag << endl;
					}
				} else {
					dfs(newidx, bagcnt+1);
				}
			}
		}

		//�湮üũ�� ����
		for(j=0; j<visitBagCnt; j++) {
			Visit[ visitBag[j] ]=0;
		}
		visitBagCnt=0;
	}

	Visit[idx]=0;
}


int sortf(const void *a, const void *b)
{
	int *p=(int *)a, *q=(int *)b;
	return *p-*q;
}

void packing()
{
	int i;
	ifstream in(INFILE);
	in >> N >> T;
	for(i=0; i<N; i++) {
		in >> Bag[i];
	}
	qsort(Bag, N, sizeof(Bag[0]), sortf);

	MinBag=bagnum();
	cout << MinBag << endl;
	dfs(0, 1);

	ofstream out(OUTFILE);
	out << MinBag;
}


void main()
{
	makedata();
	//packing();
}