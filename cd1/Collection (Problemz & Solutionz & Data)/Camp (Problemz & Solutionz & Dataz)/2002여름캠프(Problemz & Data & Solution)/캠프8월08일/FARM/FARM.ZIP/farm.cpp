#include <fstream.h>
#include <stdlib.h>
#include <conio.h>

#define INFILE  "farm05.in"
#define OUTFILE "farm.out"

#define LineMax 100

int Bx1, By1, Bx2, By2;
int Line[LineMax+1][4], Lines, Xs, Ys;
int Myun[101][101][4][4];
int Table[101][101];
int Visit[101][101];
int Area[10000], Ac;
char visitx[100000+1];
char visity[100000+1];

void input()
{
	int i, x1, y1, x2, y2;
	ifstream in ( INFILE );
	in >> Bx1 >> By1 >> Bx2 >> By2;
	in >> Lines;
	for ( i = 0; i < Lines; i ++ ) {
		in >> x1 >> y1 >> x2 >> y2;
		Line[i][0] = (x1<x2)?x1:x2; Line[i][1] = (y1<y2)?y1:y2;
		Line[i][2] = (x1>x2)?x1:x2; Line[i][3] = (y1>y2)?y1:y2;
	}
/*	
	for ( i = 0; i < Lines; i ++ ) {
		cout << Line[i][0] << " ";
		cout << Line[i][1] << " ";
		cout << Line[i][2] << " ";
		cout << Line[i][3] << endl;
	}
*/	
}

int s_f ( const void *a, const void *b )
{
	int A = *(int *)a, B = *(int *)b;
	if ( A > B ) return 1;
	else if ( A == B ) return 0;
	return -1;
}

void ps()
{
	int i, j, x1,y1,x2,y2;
	int tmpx[LineMax*2], tx = 0;
	int tmpy[LineMax*2], ty = 0;
	for ( i = 0; i < Lines; i ++ ) {
		x1 = Line[i][0]; y1 = Line[i][1];
		x2 = Line[i][2]; y2 = Line[i][3];
		if ( x1 == x2 ) {
			if ( !visitx[x1] ) {
				tmpx[tx++] = x1;
				visitx[x1] = 1;
			}
			if ( !visity[y1] ) {
				tmpy[ty++] = y1;
				visity[y1] = 1;
			}
			if ( !visity[y2] ) {
				tmpy[ty++] = y2;
				visity[y2] = 1;
			}
		} else {
			if ( !visity[y1] ) {
				tmpy[ty++] = y1;
				visity[y1] = 1;
			}
			if ( !visitx[x1] ) {
				tmpx[tx++] = x1;
				visitx[x1] = 1;
			}
			if ( !visitx[x2] ) {
				tmpx[tx++] = x2;
				visitx[x2] = 1;
			}
		}
	}
	if ( !visitx[Bx1] ) {
		tmpx[tx++] = Bx1; 
		visitx[Bx1] = 1;
	}
	if ( !visitx[Bx2] ) {
		tmpx[tx++] = Bx2;
		visitx[Bx2] = 1;
	}
	if ( !visity[By1] ) {
		tmpy[ty++] = By1; 
		visity[By1] = 1;
	}
	if ( !visity[By2] ) {
		tmpy[ty++] = By2;
		visity[By2] = 1;
	}
	qsort ( tmpx, tx, sizeof(tmpx[0]), s_f );	
	qsort ( tmpy, ty, sizeof(tmpy[0]), s_f );	
	Xs = tx-1; Ys = ty-1;
	for ( i = 0; i < Ys; i ++ ) {
		for ( j = 0; j < Xs; j ++ ) {
			Myun[i][j][0][0] = tmpx[j+1];
			Myun[i][j][0][1] = tmpy[i];
			Myun[i][j][0][2] = tmpx[j+1];
			Myun[i][j][0][3] = tmpy[i+1];
			
			Myun[i][j][1][0] = tmpx[j];
			Myun[i][j][1][1] = tmpy[i+1];
			Myun[i][j][1][2] = tmpx[j+1];
			Myun[i][j][1][3] = tmpy[i+1];

			Myun[i][j][2][0] = tmpx[j];
			Myun[i][j][2][1] = tmpy[i];
			Myun[i][j][2][2] = tmpx[j];
			Myun[i][j][2][3] = tmpy[i+1];
			
			Myun[i][j][3][0] = tmpx[j];
			Myun[i][j][3][1] = tmpy[i];
			Myun[i][j][3][2] = tmpx[j+1];
			Myun[i][j][3][3] = tmpy[i];
		}
	}
	
	for ( i = 0; i < tx; i ++ ) {
		cout << tmpx[i] << " ";
	}
	cout << endl;
	for ( i = 0; i < ty; i ++ ) {
		cout << tmpy[i] << " ";
	}
	cout << endl;
	getch();
}

int isok ( int i, int j, int dir ) 
{
	int k, ret = 1, x1, y1, x2, y2;
	if ( i < 0 || j < 0 || i >= Ys || j >= Xs ) return 0;
	x1 = Myun[i][j][dir-1][0];
	y1 = Myun[i][j][dir-1][1];
	x2 = Myun[i][j][dir-1][2];
	y2 = Myun[i][j][dir-1][3];
	for ( k = 0; k < Lines; k ++ ) {
		if ( Line[k][0] <= x1 && Line[k][1] <= y1 && 
		     Line[k][2] >= x2 && Line[k][3] >= y2 ) {
			ret = 0; break;
		}
	}				
	return ret;
}

int myunjuk ( int i, int j )
{
	int sx, sy, ex, ey;
	if ( Ac == 7 ) {
		cout << "hello";
	}
	sx = Myun[i][j][3][0];
	sy = Myun[i][j][3][1];	
	ex = Myun[i][j][0][0];
	ey = Myun[i][j][0][3];
	return ((ex-sx) * (ey-sy));
}
		

int dfs ( int i, int j, int ac ) 
{
	int gab = 0;
	Table[i][j] = ac;
	Area[ac] += myunjuk ( i, j );
	if ( i+1 < Ys && Table[i+1][j] == 0 && isok(i,j, 2 ) ) 
		dfs ( i+1, j, ac );
	if ( j+1 < Xs && Table[i][j+1] == 0 && isok(i,j, 1 ) ) 
		dfs ( i, j+1, ac );
	if ( i-1 > -1 && Table[i-1][j] == 0 && isok(i,j, 4 ) ) 
		dfs ( i-1, j, ac );
	if ( j-1 > -1 && Table[i][j-1] == 0 && isok(i,j, 3 ) ) 
		dfs ( i, j-1, ac );
	return 1;
}
void display()
{
	int i, j;
	for ( i = Ys-1; i >= 0; i -- ) {
		for ( j = 0; j < Xs; j ++ ) {
			cout << Table[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
}
		       	
void process()
{
	int i, j;
	ps ();
	Ac = 1;
	for ( i = 0; i < Ys; i ++ ) {
		for ( j = 0; j < Xs; j ++ ) {
 			if ( Table[i][j] == 0 ) {
				dfs ( i, j, Ac );
				display();
				Ac ++;
			}			
		}
	}
	Ac --;
}

void output()
{
	int i;
	ofstream out ( OUTFILE );
	qsort ( &Area[1], Ac, sizeof ( Area[1] ), s_f );
	cout << Ac << endl;
	out << Ac << endl;
	for ( i = 1; i <= Ac; i ++ ) {
		cout << Area[i] << endl;
		out << Area[i] << endl;
	}
}
	
void main()
{
	input();
	process();
	output();
}	
