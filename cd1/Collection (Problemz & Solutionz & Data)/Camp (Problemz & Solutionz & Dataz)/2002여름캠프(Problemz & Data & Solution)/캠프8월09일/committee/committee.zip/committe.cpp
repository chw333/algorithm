#include <fstream.h>
#include <time.h>
#include <stdlib.h>

#define INFILE "committee10.in"
#define OUTFILE "committee10.out"
#define MAXN 101

int N, M;
int Table[MAXN][MAXN];
int Comm[MAXN][MAXN];
int CommColor[MAXN];
int ImsiColor[MAXN];
int MinComm=MAXN+1;


#define MAKEN 100
#define MAKEM 100
#define MAKECNT 1000

int makeTable[MAXN][MAXN];

void makedata()
{
	srand(time(NULL));
	ofstream out(INFILE);
	out << MAKEN << " " << MAKEM << endl;

	int i,j, pa1, pa2, pb1, pb2;
	int prevline=0, line=0,v;
	int prevcol=0, col=0;

	for(i=0; i<MAKEM; i++) {
		v=rand()%MAKEN/10;
		if(v==0) {
			col=rand()%MAKEN;
			makeTable[i][prevcol]=1;
			prevcol=col;
		}
		makeTable[i][col]=1;
	}
	for(i=0; i<MAKEM; i++) {
		v=rand()%MAKEN/10;
		if(v==0) {
			line=rand()%MAKEN;
			makeTable[prevline][i]=1;
			prevline=line;
		}
		makeTable[line][i]=1;
	}
	
	
	for(i=0; i<MAKECNT-MAKEN; i++) {
		pa1=rand()%MAKEN;
		pa2=rand()%MAKEM;
		pb1=rand()%MAKEN;
		pb2=rand()%MAKEM;
		
		makeTable[pa1][pa2]=1;
		makeTable[pb1][pb2]=1;
	}

	for(i=0; i<MAKEN; i++) {
		for(j=0; j<MAKEM; j++) {
			if(j!=0) out << " ";
			out << makeTable[i][j];
		}
		out << endl;
	}

}



int Visit[MAXN];
int GroupCnt;
void group(int start)
{
	Visit[start]=1;
	int i;
	for(i=0; i<N; i++) {
		if(Comm[start][i]==1 && Visit[i]==0) {
			group(i);
		}
	}
}

void checkgroup()
{
	int i;
	for(i=0; i<N; i++) {
		if(Visit[i]==0) {
			group(i);
			GroupCnt++;
		}
	}
	cout << GroupCnt << endl;
}


void coloring(int start)
{
	int i, color;
	//�ڽ��� ���� ĥ�ϱ�.
	color=1;
	for(i=0; i<N; i++) {
		ImsiColor[i]=0;
	}
	for(i=0; i<N; i++) {
		if(Comm[start][i]==1 && CommColor[i]!=0) {
			ImsiColor[ CommColor[i]-1 ]=1;
		}
	}
	for(i=0; i<N; i++) {
		if(ImsiColor[i]==0) {
			CommColor[start]=i+1;
			break;
		}
	}

	//�ڽſ��� ���� �ڽ��� ���� ĥ�ϱ�.
	for(i=0; i<N; i++) {
		if(Comm[start][i]==1 && CommColor[i]==0) {
			coloring(i);
		}
	}
}

void committee()
{
	int i,j,k;
	ifstream in(INFILE);
	in >> N >> M;
	for(i=0; i<N; i++) {
		for(j=0; j<M; j++) {
			in >> Table[i][j];
		}
	}

	for(i=0; i<M; i++) {
		for(j=0; j<N; j++) {
			if(Table[j][i]==1) {
				for(k=j+1; k<N; k++) {
					if(Table[k][i]==1) {
						Comm[j][k]=1;
						Comm[k][j]=1;
					}
				}
			}
		}
	}


	for(i=0; i<N; i++) {
		for(j=0; j<N; j++) {
			cout << Comm[i][j];
		}
		cout << endl;
	}

	int maxcolor;
	for(i=0; i<N; i++) {
		for(j=0; j<N; j++) {
			CommColor[j]=0;
		}
		coloring(i);

		maxcolor=0;
		for(j=0; j<N; j++) {
			if(maxcolor < CommColor[j]) {
				maxcolor=CommColor[j];
			}
		}
		
		if(MinComm > maxcolor) {
			MinComm=maxcolor;
		}
	}

	ofstream out(OUTFILE);
	out << MinComm;
	cout << MinComm << endl;
}


void main()
{
	//makedata();
	committee();
	//checkgroup();
}