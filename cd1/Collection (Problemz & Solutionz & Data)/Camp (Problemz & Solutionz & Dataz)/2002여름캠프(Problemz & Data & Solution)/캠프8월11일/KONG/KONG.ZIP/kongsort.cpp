#include <fstream.h>
#include <stdlib.h>
#include <string.h>

#define INFILE1  "kong05.in"
#define INFILE2  "kong05.out_"
#define OUTFILE1 "kon.tmp"
#define OUTFILE2 "kong05.out"
#define ENDING   -999999999

char p[1000000];
int A[10000000], N;
int lines;

int s_f ( const void *a, const void *b )
{
	int A = *(int *)a;
	int B = *(int *)b;
	if ( A>B ) return 1;
	else if ( A == B ) return 0;
	return -1;
}

void main()
{
	int i, j, a, count;
	ifstream in1 ( INFILE1 );
	in1 >> N;
	in1.close();
	ifstream in2 ( INFILE2 );
	ofstream out1 ( OUTFILE1 );
	ofstream out2 ( OUTFILE2 );
	while ( 1 ) {
		in2.getline ( p, 1000000 );
		if ( in2.eof() ) break;
		strcat ( p, " -999999999" );
		out1 << p << endl;
		lines ++;
	}
	out1.close();
	ifstream in3 ( OUTFILE1 );
	for ( i = 0; i < lines; i ++ ) {
		if ( i != 0 ) out2 << endl;
		count = 0;
		while (1) {
			in3 >> A[count];
			if ( A[count] == ENDING ) break; 
			count ++;
		}
		qsort ( A, count, sizeof(A[0]), s_f );
		for ( j = 0; j < count; j ++ ) {
			if ( j != 0 ) out2 << " ";
			out2 << A[j];
		}
	}
}
