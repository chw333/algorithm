#include <fstream.h>
#include <math.h>

#define INFILE  "contra.in"
#define OUTFILE "contra.out"
#define Min    -2000000000
#define Maxx    2000000000

#define Max 20

int N, M;
int Node[Max];
int Edge[Max][Max];
int D[1048576*2][2];

void input ( )
{
	char c;
	int i, a, b;
	ifstream in ( INFILE );
	in >> N;
	for ( i = 0; i < N; i ++ ) {
		in >> a >> b;
		a --; 
		Node[a] = b;
	}
	for ( i = 0; i < N - 1; i ++ ) {
		in >> a >> b >> c;
		a --; b --;
		Edge[a][b] = Edge[b][a] = (int) c;
	}
	for ( i = 0; i < 1048576*2; i ++ ) {
		D[i][0] = Min;
		D[i][1] = Maxx;
	}
}

void init ( int branch[Max][Max] )
{
	int i, j;
	for ( i = 0; i < N; i ++ ) {
		for ( j =0; j < N; j ++ ) {
			branch[i][j] = 0;
		}
	}
}

int dfs ( int edge[Max][Max], int p, int branch[Max][Max] )
{	
	int i, ret = -1;
	for ( i = 0; i < N; i ++ ) {
		if ( edge[p][i] && !branch[p][i] ) {
			ret = 0;
			branch[p][i] = branch[i][p] = edge[p][i];
			dfs ( edge, i, branch );
		}
	}
	return ret;
}

int calDpos ( int edge[Max][Max] )
{
	int i, j, g = 0;
	for ( i = 0; i < N; i ++ ) {
		for ( j = 0; j < N; j ++ ) {
			if ( edge[i][j] ) {
				g += pow ( 2, i );
				break;
			}
		}
	}
	return g;
}

int recur( int edge[Max][Max] )
{
	int branch[Max][Max];
	int i, j, k, l, c, g, glr[2][2], gtmp, tmp, max = Min, min = Maxx;
	g = calDpos ( edge );
	if ( D[g][0] == Min ) {
		for ( i = 0; i < N - 1; i ++ ) {
			for ( j = i + 1; j < N; j ++ ) {
				if ( !edge[i][j] ) continue;

				c = edge[i][j];
				edge[i][j] = edge[j][i] = 0;

				init ( branch );
				if ( -1 == dfs ( edge, i, branch ) ) {
					glr[0][0] = Node[i]; 
					glr[0][1] = Node[i];
				} else {
					gtmp = recur( branch );
					glr[0][0] = D[gtmp][0];
					glr[0][1] = D[gtmp][1];
				}	

				init ( branch );
				if ( -1 == dfs ( edge, j, branch ) ) {
					glr[1][0] = Node[j];
					glr[1][1] = Node[j];
				} else {
					gtmp = recur( branch );
					glr[1][0] = D[gtmp][0];
					glr[1][1] = D[gtmp][1];
				}

				edge[i][j] = edge[j][i] = c;
				
				for ( k = 0; k < 2; k ++ ) {
					for ( l = 0; l < 2; l ++ ) {
						if ( c == '*' ) tmp = glr[0][k] * glr[1][l];
						else tmp = glr[0][k] + glr[1][l];
						if ( tmp > max ) max = tmp;
						if ( tmp < min ) min = tmp;
					}
				}
			}
		}
		D[g][0] = max;
		D[g][1] = min;
	}
	return g;
}

void process ()
{
	int g;
	g = recur ( Edge );
	M = D[g][0];
}

void output()
{
	ofstream out ( OUTFILE );
	out << M;
}

void main()
{
	input();
	process();
	output();
}