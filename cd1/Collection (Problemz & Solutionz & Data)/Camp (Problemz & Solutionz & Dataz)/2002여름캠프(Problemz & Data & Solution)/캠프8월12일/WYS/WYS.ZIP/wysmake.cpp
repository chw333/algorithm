#include <fstream.h>
#include <stdlib.h>

#define MAX 100

ifstream in1 ( "wys12.in" );
ifstream in2 ( "wys12.out1" );
ofstream out ( "wys12.out" );

int N;
int D[MAX*2];

int sort_function ( const void *a, const void * b )
{
	int A = *(int *) a;
	int B = *(int *) b;
	if ( A > B ) return 1;
	else if ( A == B ) return 0;
	return -1;
}

void main()
{
	int i, j, a, b;
	in1 >> N;
	for ( i = 0; i < N * 2 - 2 - 1; i ++ ) {
		if ( i < N ) in2 >> a >> b;
		else {
			for ( j = 0; j < 3; j ++ ) {
				in2 >> a >> b;
			}
		}
		D[i] = b;
	}
	qsort ( D, N*2-2-1, sizeof ( D[0] ), sort_function );
	for ( i = 0; i < N * 2 - 2 - 1; i ++ ) {
		if ( i != 0 ) out << " ";
		out << D[i];
	}
}
