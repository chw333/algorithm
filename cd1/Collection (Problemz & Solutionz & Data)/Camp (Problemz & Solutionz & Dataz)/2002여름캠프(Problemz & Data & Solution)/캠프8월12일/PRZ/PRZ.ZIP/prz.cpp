#include <fstream.h>
#include <stdlib.h>

#define Range 1000000
#define Max 50000
int N, Interval[50000*2][2];
int Ri, R[50000][2];

void input()
{
	int i, tmp;
	ifstream in ("prz.in");
	in >> N; N *= 2;
	for ( i = 0; i < N; i ++ ) {
		in >> tmp;
		if ( i % 2 ) Interval[i][1] = 1;
		Interval[i][0] = tmp;
	}
}

int sort_function ( const void * a, const void * b )
{
	int A = *(int *)a, B = *(int *)b;
	if ( A > B ) return 1;
	else if ( A == B ) {
		A = *((int *)a + 1); B = *((int *)b + 1 );
		if ( A > B ) return 1;
		else if ( A == B ) return 0;
		else return -1;	
	}
	else return -1;
}

void process()
{
	int i, p = 0;
	ofstream out ( "prz.out" );
	qsort ( Interval, N, sizeof(Interval[0]), sort_function );
	for ( i = 0; i < N; i ++ ) {
		if ( p == 0 ) {
			if ( i != 0 ) out << endl;
			out << Interval[i][0]; 
		}
		if ( Interval[i][1] ) p--;
		else p ++;
		if ( p == 0 ) out << " " << Interval[i][0];
	}
}		

void main()
{
	input();
	process();
//	output();
}
