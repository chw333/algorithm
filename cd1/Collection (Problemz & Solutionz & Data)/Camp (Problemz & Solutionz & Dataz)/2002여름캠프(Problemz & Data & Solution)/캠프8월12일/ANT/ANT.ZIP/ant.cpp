#include <fstream.h>
#include <math.h>

#define Max 2000000000
#define Pmax 5000

int P[9] = { 2, 3, 5, 7, 11, 13, 17, 19, 23 },  
	Pn[9]= {30,19,13,11,  8,  8,  7,  7,  6 }; 

int S[Pmax];
int N, Gd, Gab; 

ifstream in ("ant.in");
ofstream out("ant.out");

void input ()
{
	in >> N;
//	N = 2000000000;
}

void cal( int pi, int gd, int gab, int namuji )
{
	int i, d, tmp = namuji, sw;
	if ( pi > 8 ) {
		if ( (gd > Gd) || ( gd == Gd && Gab > gab ) ) {
			Gd = gd; Gab = gab;
		}
		return;
	}
	for ( i = 0; i <= Pn[pi]; i ++ ) {
		tmp = namuji;
		d = pow ( P[pi], i ) ;
		if ( (tmp / d) > 0 ) tmp /= d;
		else break;
		cal ( pi + 1, gd * (i+1), gab * d, tmp );
	}
}

void output ()
{
	out << Gab;
}

void main()
{
	input();
	cal ( 0, 1, 1, N ); // P level, gab divisor, gab, namuji
	output();
}
