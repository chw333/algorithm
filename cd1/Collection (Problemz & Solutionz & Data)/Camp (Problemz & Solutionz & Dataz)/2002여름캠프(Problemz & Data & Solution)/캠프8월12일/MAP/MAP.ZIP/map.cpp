#include <fstream.h>

#define Max 250
int F[Max][Max], W1[Max][Max], W2[Max][Max], N, R;

void input ()
{
	int i, j;
	ifstream in ("map.in");
	in >> N >> R;
	for ( i = 0; i < N; i ++ ) {
		for ( j = 0; j < N; j ++ ) {
			in >> F[j][i];
		}
	}
}

void process()
{
	int i, j, ii, si, ei, sj, ej, tmp;
	for ( i = 0; i < N; i ++ ) {
		for ( j = 0; j < N; j ++ ) {
			tmp = j - R;
			sj = ( tmp < 0 )?0:tmp;
			tmp = j + R;
			ej = ( tmp >= N )?N-1:tmp;
			for ( ii = sj; ii <= ej; ii ++ ) W1[j][i] += F[ii][i];
		}
	}
	for ( i = 0; i < N; i ++ ) {
		for ( j = 0; j < N; j ++ ) {
			tmp = i - R;
			si = ( tmp < 0 )?0:tmp;
			tmp = i + R;
			ei = ( tmp >= N )?N-1:tmp;
			for ( ii = si; ii <= ei; ii ++ ) W2[j][i] += W1[j][ii];
		}
	}
}
		
void output ()
{
	int i, j;
	ofstream out ("map.out");
	for ( i = 0; i < N; i ++ ) {
		for ( j = 0; j < N; j ++ ) {
			out << W2[j][i] << " ";
		}
		out << endl;
	}
}

void main()
{
	input();
	process();
	output();
}