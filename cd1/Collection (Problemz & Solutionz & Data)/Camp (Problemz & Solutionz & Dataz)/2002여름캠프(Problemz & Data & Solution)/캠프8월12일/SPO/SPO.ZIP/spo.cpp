#include <fstream.h>
#include <stdlib.h>
//#include <conio.h>

#define Max 8000
ifstream in ( "spo.in" );
ofstream out( "spo.out");

struct HATE {
	int n;
	struct HATE * h;
} *Hate[Max*2+1];

int N, M;
int Bfstable[Max+1];
int Result[Max+1];

void input()
{
	int i, a, b;
	struct HATE *tmp1, *tmp2;
	in >> N >> M;
	for ( i = 1; i <= N*2; i ++ ) {
		Hate[i] = (struct HATE *)malloc ( sizeof ( struct HATE ) );
		Hate[i]->n = 0;
		Hate[i]->h = NULL;
	}
	for ( i = 1; i <= M; i ++ ) {
		in >> a >> b;
		tmp1 = Hate[a];
		tmp2 = Hate[b];
		while ( tmp1->h ) tmp1 = tmp1->h;
		while ( tmp2->h ) tmp2 = tmp2->h;
		tmp1->h = (struct HATE *)malloc( sizeof ( struct HATE ) );
		tmp2->h = (struct HATE *)malloc( sizeof ( struct HATE ) );
		tmp1->h->h=tmp2->h->h=NULL;
		tmp1->n = b;
		tmp2->n = a;
	}
}

void output()
{
	int i;
	for ( i = 1; i <= N; i ++ ) {
		if ( i != 1 ) out << endl;
		out << Result[i];
	}
}

int dfssetting ( int n, int level )
{
	int tmp, tmp2;
	struct HATE *hate = Hate[n];
	while ( hate->h ) {
		tmp = hate->n; 
		tmp2 = (tmp+1)/2;
		tmp = (tmp%2)?tmp+1:tmp-1;
		if ( Bfstable[tmp2] != 0 ) {
			if ( Result[tmp2] != tmp ) return -1;
		} else {
			Bfstable[tmp2] = level;
			Result[tmp2] = tmp;
			if( -1 ==  dfssetting ( tmp, level ) ) return -1;
		}
		hate = hate->h;
	}
	return 1;
}

void clearlevel ( int level )
{
	static int count = 0;
	int i;
	for ( i = 1; i <= N; i ++ ) {
		if ( Bfstable[i] > level ) {
			Bfstable[i] = 0;
			Result[i] = 0;
		}
	}
}

int recur ( int level )
{
	int i, tmp, tmp2, r;
	for ( i = 1; i <= N; i ++ ) if ( Bfstable[i] == 0 ) break;
	if ( i > N ) return 1;
	tmp2 = i;
	tmp = tmp2 * 2 - 1;
	for ( i = 0; i < 2; i ++ ) {
		Bfstable[tmp2] = level + 1;
		Result[tmp2] = tmp + i;
		r = dfssetting ( Result[tmp2], level + 1 );
		if ( r == -1 ) {
			clearlevel ( level );
			continue;
		} 
		r = recur ( level+1 );
		if ( r == -1 ) {
			clearlevel ( level );
		} else break;
	} 
	return r;
}

void process()
{
	recur ( 0 );
}

void main()
{
	input();
	process();
	output();
}
