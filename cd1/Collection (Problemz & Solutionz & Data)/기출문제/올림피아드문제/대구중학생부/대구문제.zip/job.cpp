/*
ID: cee09001
PROG: job
*/

#include "fstream.h"
#include "iomanip.h"
#include "string.h"


#define INFILE "job.in"
#define OUTFILE "job.out"
#define MaxM 30


int TA, TB;
int PTime[2][MaxM];
int N, M[2];
int D;

int ComputeTime(int op)
{
	int t,Processed;
	int i;

	t=1;
	for(;;) {  
	    Processed=0;
		for(i=0; i< M[op]; i++) {
			Processed+=t / PTime[op][i];
		}
		if(Processed>=N) break;
		t++;
	}
	return t;
}


int Finish(int Op, int t)
{
    int Res, UpTo;
    int i;
  
    Res=0;
    for(i=0; i<M[Op]; i++) {
        if(t % PTime[Op][i]==0) 
			Res++;
	}
    
    UpTo=0;
    for(i=0; i<M[Op]; i++) {
		UpTo+=(t-1) / PTime[Op][i];
	}

    if( UpTo >= N) {
        Res= 0;
    } else if( UpTo+Res>N ) {
        Res= N-UpTo;
	}
    return Res;
}

void Adjust()
{
    int Inter;
    int t;
    int JB;
  
    D=1; t=0; Inter=0;
	while(D+t<TA) {
		Inter+=Finish(0,D+t);
		JB=Finish(1,TB-t);
		while(Inter<JB) {
			D++;
			Inter+=Finish(0,D+t);
		}
		Inter-=JB;
		t++;
    }
}




int main(int argc, char* argv[])
{
	int i;
	ifstream in(INFILE);
	in >> N >> M[0] >> M[1];
	for(i=0; i<M[0]; i++) {
		in >> PTime[0][i];
	}
	for(i=0; i<M[1]; i++) {
		in >> PTime[1][i];
	}
	
	TA= ComputeTime(0);
	TB= ComputeTime(1);

	//cout << TA << " " << TB << " ";
	Adjust();


	ofstream out(OUTFILE);
	out << TA << " " << D+TB << endl;
	
	return 0;
}

