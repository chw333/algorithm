// 2002. 1 "Inverse"

#include <stdio.h>
#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"

int N;
char board[10];
FILE *inf, *outf;
int res[10];
int soln[9] = {4, 6, 4, 6, 9, 6, 4, 6, 4};
int sol[9][9] = { {5, 6, 8, 9}, {4, 5, 6, 7, 8, 9}, {4, 5, 7, 8}, {2, 3, 5, 6, 8, 9},
					{1, 2, 3, 4, 5, 6, 7, 8, 9}, {1, 2, 4, 5, 7, 8}, {2, 3, 5, 6},
					{1, 2, 3, 4, 5, 6}, {1, 2, 4, 5} };

void initialize_res()
{
	int i;

	for(i=0; i<10; i++)
		res[i] = 0;
}
		
void solve(char* board)
{
	int i, j;

	for(i=0; i<9; i++)
		if (board[i] == 'b') 
			for(j=0; j<soln[i]; j++)
				res[sol[i][j]] = !res[sol[i][j]];
}

void output_result(int* res)
{
	int i;

	for(i=1; i<=9; i++)
		if (res[i]) fprintf(outf, "%d", i);

	fprintf(outf, "\n");
}

void main()
{	
	int i;

	inf = fopen(INPUT_FILE, "r");
	outf = fopen(OUTPUT_FILE, "w");

	fscanf(inf, "%d\n", &N);
	
	for(i=0; i<N; i++) {
		initialize_res();
		fscanf(inf, "%10c", board);		
		solve(board);
		output_result(res);
	}

	fclose(inf);
	fclose(outf);
}