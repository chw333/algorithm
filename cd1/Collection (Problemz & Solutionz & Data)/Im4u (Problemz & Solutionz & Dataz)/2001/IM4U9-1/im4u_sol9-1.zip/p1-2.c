//  ���� ����

#include <stdio.h>
#include <stdlib.h>

#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"
#define MAX_N 20
#define MAX_M 10001

int N;
int num[MAX_N];
long wanted;
long RES = 0;
int found = 0;
int m[MAX_N][MAX_N][MAX_M];
int m_num[MAX_N][MAX_N];
int temp[MAX_M];

void read_input()
{
	FILE *inf;
	int i;

	inf = fopen(INPUT_FILE, "r");
	fscanf(inf, "%d", &N);

	for (i=0; i<N; i++)
		fscanf(inf, "%d", &num[i]);

	fscanf(inf, "%ld", &wanted);

	fclose(inf);
}

void exchange(int *n1, int *n2)
{
	int n3;

	n3 = *n1;
	*n1 = *n2;
	*n2 = n3;
}

void calculate(int *num, int p)
{
	int i, j, k, l;
	int candidate;

	for(i=0; i<MAX_M; i++)		
		temp[i] = 0;

	m[p][p][0] = num[p];
	m_num[p][p] = 1;

	for (i=p-1; i>=0; i--) {
		for(j=i; j<p; j++) 

			for(k=0; k<m_num[i][j]; k++) {				

				temp[m[i][j][k]] = 1;
				for(l=0; l<m_num[j+1][p]; l++)
					temp[m[j+1][p][l]] = 1;

				for(l=0; l<m_num[j+1][p]; l++)
					if (m[i][j][k] + m[j+1][p][l] >= MAX_M) break;
					else temp[m[i][j][k] + m[j+1][p][l]] = 1;

				for(l=0; l<m_num[j+1][p]; l++)
					if (m[i][j][k] - m[j+1][p][l] < 0) break;
					else temp[m[i][j][k] - m[j+1][p][l]] = 1; 

				for(l=0; l<m_num[j+1][p]; l++)
					if (m[i][j][k] * m[j+1][p][l] >= MAX_M) break;
					else temp[m[i][j][k] * m[j+1][p][l]] = 1;

				for(l=0; l<m_num[j+1][p]; l++)
					if (m[j+1][p][l] * 2 > m[i][j][k]) break;
					else if (m[j+1][p][l] != 0 && m[i][j][k] % m[j+1][p][l] == 0) temp[m[i][j][k] / m[j+1][p][l]] = 1;
			}
				
		for(j=0; j<MAX_M; j++)		
			if (temp[j] == 1) {
				m[i][p][m_num[i][p]++] = j;
				if (j <= wanted) candidate = j;
			}
	}
	
	if (candidate == wanted) {
		RES = wanted;
		found = 1;
	}
	else {

		if (candidate > RES) 
			RES = candidate;
	
		for (i=p+1; i<N; i++) {
			exchange(&num[p+1], &num[i]);
			calculate(num, p+1);
			if (found) break;
		}

		for (i=0; i<=p; i++) 
			m_num[i][p] = 0;		
	}		
}

void solve()
{
	int i;
	
	for (i=0; i<N; i++) {
		exchange(&num[0], &num[i]);		
		calculate(num, 0);	
		if (found) break;
	}
}

void output_result()
{
	FILE *outf;
		
	outf = fopen(OUTPUT_FILE, "w");
	fprintf(outf, "%d\n", RES);

	fclose(outf);
}

void main()
{
	read_input();
	solve();
	output_result();
}