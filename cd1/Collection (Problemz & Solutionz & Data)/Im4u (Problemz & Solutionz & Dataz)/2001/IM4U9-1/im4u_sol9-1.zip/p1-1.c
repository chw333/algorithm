//  ���� ����

#include <stdio.h>
#include <stdlib.h>

#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"
#define MAX_N 20

int N;
int num[MAX_N];
long wanted;
long RES = 0;
int found = 0;

void read_input()
{
	FILE *inf;
	int i;

	inf = fopen(INPUT_FILE, "r");
	fscanf(inf, "%d", &N);

	for (i=0; i<N; i++)
		fscanf(inf, "%d", &num[i]);

	fscanf(inf, "%ld", &wanted);

	fclose(inf);
}

void calculate(int k, int s)
{
	int i, j;
	int p1, p2;

	if (num[s] == wanted) {
		found = 1;		RES = wanted;
	}
	else {
		if (num[s] < wanted && num[s] > RES)
			RES = num[s];

		for (i=1; i<k; i++) {

			p1 = num[i];	
			num[i] = num[k-1];
				
			for (j=0; j<i; j++) {

				p2 = num[j];
				
				num[j] = p1 + p2;		calculate(k-1, j);
				if (found) break;

				num[j] = p1 - p2;		calculate(k-1, j);
				if (found) break;				

				num[j] = p2 - p1;		calculate(k-1, j);
				if (found) break;				

				num[j] = p1 * p2;		calculate(k-1, j);
				if (found) break;				

				if (p2 != 0 && p1 % p2 == 0) {
					num[j] = p1 / p2;		calculate(k-1, j);
					if (found) break;				
				}

				if (p1 != 0 && p2 % p1 == 0) {
					num[j] = p2 / p1;		calculate(k-1, j);
					if (found) break;				
				}

				num[j] = p2;
			}

			num[i] = p1;
		}
	}		
}

void solve()
{
	int i;

	for (i=0; i<N-1; i++)
		if (num[i] == wanted) {
			found=1;	RES=wanted;
			break;
		}

	if (!found) calculate(N, N-1);
}

void output_result()
{
	FILE *outf;
		
	outf = fopen(OUTPUT_FILE, "w");
	fprintf(outf, "%d\n", RES);

	fclose(outf);
}

void main()
{
	read_input();
	solve();	
	output_result();
}