//  ��Ƽ�� ����

#include <stdio.h>

#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"
#define MAX_K 100

int K;
int N = 0, M = 0;
int block[2][MAX_K+1];

void read_input()
{
	FILE *inf;
	int i;

	
	inf = fopen(INPUT_FILE, "r");
	fscanf(inf, "%d", &K);

	for (i=0; i<K; i++)
		fscanf(inf, "%d", &block[0][i]);

	for (i=0; i<K; i++)
		fscanf(inf, "%d", &block[1][i]);

	fclose(inf);
}

void exchange(int *n1, int *n2)
{
	int n3;

	n3 = *n1;
	*n1 = *n2;
	*n2 = n3;
}

void solve()
{
	int i, j;
	int p1, p2;

	for(i=0; i<K-1; i++)
		for(j=i+1; j<K; j++) {
			if (block[0][i] < block[0][j]) exchange(&block[0][i], &block[0][j]);
			if (block[1][i] < block[1][j]) exchange(&block[1][i], &block[1][j]);
		}

	block[0][K] = block[0][K] = 0;
		
	N = M = block[0][0];
	p1 = p2 = 1;

	while(block[0][p1] != 0 || block[1][p2] != 0) {
		
		if (block[0][p1] == block[1][p2]) {
			N += block[0][p1];
			M += block[0][p1] * (p1 + p2 + 1);
			p1++;	p2++;
		}
		else if (block[0][p1] > block[1][p2]) {
			N += block[0][p1];			
			M += block[0][p1] * p2;
			p1++;
		}
		else {
			N += block[1][p2];			
			M += block[1][p2] * p1;
			p2++;
		}
	}
}

void output_result()
{
	FILE *outf;
		
	outf = fopen(OUTPUT_FILE, "w");
	fprintf(outf, "%d %d\n", N, M);

	fclose(outf);
}

void main()
{
	read_input();
	solve();
	output_result();
}