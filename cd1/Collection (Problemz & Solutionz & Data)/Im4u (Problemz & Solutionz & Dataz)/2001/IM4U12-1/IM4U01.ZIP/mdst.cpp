#include<stdio.h>

#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"
#define MAX_N 1000
#define MAX_RES 100

int n;
int inp_num[MAX_N];
char history[MAX_RES], res[MAX_RES];
int res_n;
FILE *outf;

void Read_data()
{
	FILE *inf;
	int i;

	inf = fopen(INPUT_FILE, "r");
	fscanf(inf, "%d", &n);

	for(i=0; i<n; i++)
		fscanf(inf, "%d", &inp_num[i]);

	fclose(inf);
}

long mul2(long num)
{
	return (num * 2) % 1000000000;
}

long div2(long num)
{
	return (num / 2);
}

long sort(long num)
{
	int p[10];
	int i, j;
	long ret = 0;

	for (i=0; i<10; i++)	
		p[i] = 0;

	while(num > 0) {
		p[num % 10]++;
		num = num / 10;
	}

	for (i=1; i<10; i++)
		for (j=0; j<p[i]; j++)
			ret = ret * 10 + i;
	
	return ret;
}

long tros(long num)
{
	int p[10];
	int i, j;
	long ret = 0;

	for (i=0; i<10; i++)	
		p[i] = 0;

	while(num > 0) {
		p[num % 10]++;
		num = num / 10;
	}

	for (i=9; i>=0; i--)
		for (j=0; j<p[i]; j++)
			ret = ret * 10 + i;
	
	return ret;
}

int Find_upper_bound(long num)
{
	int count = 0;

	while (num > 1) {
		if (div2(num) < sort(num)) num = div2(num);
		else num = sort(num);
		count++;
	}

	return count;
}

void Output_result()
{
	fprintf(outf, "%s\n", res);
}

void Find_result(long num, int count, char last)
{
	long num_;
	int i;

	if (count > res_n || count == res_n && res[0] != '\0') return;
	if (num == 1) {
			res_n = count;
			for (i=0; i<res_n; i++)
				res[i] = history[i];
			res[res_n] = '\0';
		}
	else {
		if (last != 'M') {
			num_ = div2(num);	history[count] = 'D';	Find_result(num_, count+1, 'D');
		}

		num_ = mul2(num);	history[count] = 'M';	Find_result(num_, count+1, 'M');

		if (last != 'S' || last != 'T') {
			num_ = sort(num);	history[count] = 'S';	Find_result(num_, count+1, 'S');
		}
		if (last != 'S' || last != 'T') {
		num_ = tros(num);	history[count] = 'T';	Find_result(num_, count+1, 'T');
		}
	}
}

void Solve_and_Output()
{
	int i;
	long num;

	outf = fopen(OUTPUT_FILE, "w");

	for (i=0; i<n; i++) {
		num = inp_num[i];
		res_n = Find_upper_bound(num);
		res[0] = '\0';
		Find_result(num, 0, ' ');
		Output_result();
	}		

	fclose(outf);
}

void main()
{
	Read_data();
	Solve_and_Output();
}