//  ö�� �����ϱ�

#include <stdio.h>

#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"
#define MAX_P 1000

int N, M, P;
int hor_num, ver_num;
int hor[MAX_P][4], ver[MAX_P][4];
int hole_num = 0;
int hole[MAX_P][4];
int RES;

void read_input()
{
	FILE *inf;
	int i;
	int x1, y1, x2, y2;

	inf = fopen(INPUT_FILE, "r");
	fscanf(inf, "%d %d", &N, &M);
	fscanf(inf, "%d", &P);

	hor_num = ver_num = 0;

	for (i=0; i<P; i++) {
		fscanf(inf, "%d %d %d %d", &x1, &y1, &x2, &y2);
		if (x1 == x2) {
			ver[ver_num][0] = x1;			ver[ver_num][1] = y1;
			ver[ver_num][2] = x2;			ver[ver_num][3] = y2;
			ver_num++;
		}
		else {
			hor[hor_num][0] = x1;			hor[hor_num][1] = y1;
			hor[hor_num][2] = x2;			hor[hor_num][3] = y2;
			hor_num++;
		}
	}

	fclose(inf);
}

void exchange(int *n1, int *n2)
{
	int n3;

	n3 = *n1;
	*n1 = *n2;
	*n2 = n3;
}

void sort()
{
	int i, j, k;

	for (i=0; i<hor_num; i++)
		if (hor[i][0] > hor[i][2]) exchange(&hor[i][0], &hor[i][2]);

	for (i=0; i<hor_num-1; i++)
		for (j=i+1; j<hor_num; j++)
			if (hor[i][1] > hor[j][1])
				for(k=0; k<4; k++)
					exchange(&hor[i][k], &hor[j][k]);				

	for (i=0; i<ver_num; i++)
		if (ver[i][1] > ver[i][3]) exchange(&ver[i][1], &ver[i][3]);

	for (i=0; i<ver_num-1; i++)
		for (j=i+1; j<ver_num; j++)
			if (ver[i][0] > ver[j][0])
				for(k=0; k<4; k++)
					exchange(&ver[i][k], &ver[j][k]);				
}

void insert_hole(int left, int up, int right, int down)
{
	int k, l;
	int useful = 1;				
	
	for(k=0; k<hole_num; k++)
		if (hole[k][0] <= left  && hole[k][1] <= up &&
			hole[k][2] >= right && hole[k][3] >= down) {
			useful = 0;
			break;
		}

	if (useful) {

		for(k=0; k<hole_num; k++)
			if (hole[k][0] >= left  && hole[k][1] >= up &&
				hole[k][2] <= right && hole[k][3] <= down) {
				for(l=k+1; k<hole_num; k++) {
					hole[l-1][0] = hole[l][0];		hole[l-1][1] = hole[l][1];
					hole[l-1][2] = hole[l][2];		hole[l-1][3] = hole[l][3];
				}
				hole_num--;
			}

		hole[hole_num][0] = left;	hole[hole_num][1] = up;
		hole[hole_num][2] = right;	hole[hole_num][3] = down;									
		hole_num++;
	}
}

void count_the_number_of_hole()
{
	int i, j, k;
	int meet, meet_at_point;
	int big, small;
	int meet_num[MAX_P];

	for (i=0; i<hole_num; i++)
		meet_num[i] = i;

	for (i=1; i<hole_num; i++) {
		for (j=0; j<i; j++) {

			meet = 0;	meet_at_point = 0;

			if ((hole[i][1] <= hole[j][3]) &&
				(hole[j][0] <= hole[i][0] && hole[i][0] <= hole[j][2] ||
				 hole[j][0] <= hole[i][2] && hole[i][2] <= hole[j][2] ||
				 hole[i][0] <= hole[j][0] && hole[j][2] <= hole[i][2])) meet = 1;

			if (hole[i][1] == hole[j][3] && 
				(hole[i][2] == hole[j][0] || hole[i][0] == hole[j][2]))
				meet_at_point = 1;

			if (meet && (!meet_at_point)) {
				if (meet_num[i] > meet_num[j]) {
					small = meet_num[j];   big = meet_num[i];
				}
				else {
					small = meet_num[i];   big = meet_num[j];
				}
				for(k=0; k<hole_num; k++)
					if (meet_num[k] == big) meet_num[k] = small;
			}
		}
	}

	for (i=0; i<hole_num-1; i++)
		for (j=i+1; j<hole_num; j++)
			if (meet_num[i] > meet_num[j]) exchange(&meet_num[i], &meet_num[j]);

	if (hole_num == 0) RES = 0;
	else RES = 1;

	for (i=0; i<hole_num-1; i++)
		if (meet_num[i] != meet_num[i+1]) RES++;
}

void solve()
{
	int i, j, k;
	int com_st, com_en;
	int left, right;

	sort(); 

	for (i=0; i<hor_num-1; i++)
		for (j=i+1; j<hor_num; j++) {

			if (hor[i][0] > hor[j][0]) com_st = hor[i][0];
			else com_st = hor[j][0];
			if (hor[i][2] > hor[j][2]) com_en = hor[j][2];
			else com_en = hor[i][2];

			if (com_st < com_en) {

				left = -1;	right = -1;
				k=0;
				while(ver[k][0] < com_st && k < ver_num)
					k++;
				
				for(; k<ver_num; k++) {
					if (ver[k][0] > com_en) break;
					if (ver[k][1] <= hor[i][1] && ver[k][3] >= hor[j][1]) {
						left = ver[k][0];
						k++;
						break;
					}
				}

				if (left != -1)
					for (; k<ver_num; k++) {
						if (ver[k][0] > com_en) break;
						if (ver[k][1] <= hor[i][1] && ver[k][3] >= hor[j][1])
							right = ver[k][0];
					}

				if (left != -1 && right != -1) 
					insert_hole(left, hor[i][1], right, hor[j][1]);
			}
		}

	count_the_number_of_hole();
}

void output_result()
{
	FILE *outf;
	
	outf = fopen(OUTPUT_FILE, "w");
	fprintf(outf, "%d\n", RES);

	fclose(outf);
}

void main()
{
	read_input();
	solve();
	output_result();
}