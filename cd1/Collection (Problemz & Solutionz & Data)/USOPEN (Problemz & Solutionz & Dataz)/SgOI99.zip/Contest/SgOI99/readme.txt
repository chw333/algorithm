
National Olympiad in Informatics 1999 (Singapore)

0<prob>.in is sample input
0<prob>.out is sample output

<id><prob>.in   <id>=1,2,3,4,5   is input file
<id><prob>.out  <id>=1,2,3,4,5   is standard output file

test.bat is used to test contestant's program, format: test <prob> <id>

