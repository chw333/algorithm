# include <stdio.h>
# include <stdlib.h>
# include <malloc.h>

# define MAXN 30001

int nv;
int edg[MAXN][2];
int brs[MAXN], prs[MAXN];
int *sps, *stv, *trs, *mrk;
FILE *fout;

void citaj() {
  FILE *fin;
  int i, j, k;
  int v1, v2;
  fin = fopen("ZAD5.DAT", "r");
  if (fin == NULL) {
    exit(0);
  }
  fscanf(fin, "%d", &nv);
  for (i = 0; i < nv; i++) brs[i] = 0;
  for (i = 0; i < nv-1; i++) {
    fscanf(fin, "%d%d", &v1, &v2);
    v1--; v2--; brs[v1]++; brs[v2]++;
    edg[i][0] = v1; edg[i][1] = v2;
  }
  sps = (int *)malloc(2*nv*sizeof(int));
  stv = (int *)malloc((nv+1)*sizeof(int));
  trs = (int *)malloc((nv+1)*sizeof(int));
  mrk = (int *)malloc((nv+1)*sizeof(int));
  prs[0] = brs[0];
  for (i = 1; i < nv; i++) prs[i] = prs[i-1]+brs[i];
  for (i = 0; i < nv-1; i++) {
    v1 = edg[i][0]; v2 = edg[i][1];
    sps[--prs[v1]] = v2;
    sps[--prs[v2]] = v1;
  }
  for (i = 0; i < nv; i++) mrk[i] = 0;
}

void obidji() {
  int d;
  int v1, v2;
  FILE *fout;
  fout = fopen("ZAD5.RES", "w");
  for (v1 = 0; brs[v1] != 1; v1++);
  d = 0; stv[0] = v1; trs[0] = 0; mrk[v1] = 1;
  fprintf(fout, "%d\n", v1+1);
  while (d >= 0) {
    v1 = stv[d];
    if (trs[d] == brs[v1]) {
      if (d%2) 
        fprintf(fout, "%d\n", v1+1);
      d--;
      continue;
    }
    if (mrk[v2=sps[prs[v1]+trs[d]]]) {
      trs[d]++; continue;
    }
    d++; stv[d] = v2; trs[d] = 0; mrk[v2] = 1;
    if (d%2 == 0) 
      fprintf(fout, "%d\n", v2+1);
  }
  fclose(fout);
}

main() {
  citaj();
  obidji();
}
 
