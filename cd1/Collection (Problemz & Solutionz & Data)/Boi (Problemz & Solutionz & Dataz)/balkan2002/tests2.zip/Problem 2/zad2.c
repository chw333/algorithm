# include <stdio.h>
# include <malloc.h>
# include "mergem.h"

# define INF 2147483000
# define MAXN 50
# define MAXL 100

struct bst {
  long vr;
  long ind;
  struct bst *l, *r;
} *r[MAXN];

long mm;
long nn;
long kk;
long b[MAXN];
long svr[MAXN];
long lid[MAXN], rid[MAXN], sid[MAXN];

long GetL(long ii, long vr, long *lvr) {
  struct bst *p, *q;
  if (r[ii] == NULL) return(0);
  p = r[ii]; q = NULL;
  while (p != NULL) {
    if (p->vr > vr) { 
      p = p->l;
    } else {
      q = p; p = q->r;
    } 
  }
  if (q != NULL) {
    *lvr = q->vr;
    return(q->ind); 
  } else {
    *lvr = -INF;
    return(0);
  }
}

long GetU(long ii, long vr, long *rvr) {
  struct bst *p, *q;
  if (r[ii] == NULL) return(b[ii]-1);
  p = r[ii]; q = NULL;
  while (p != NULL) {
    if (p->vr < vr) {
      p = p->r;
    } else {
      q = p; p = q->l;
    } 
  }
  if (q != NULL) {
    *rvr = q->vr;
    return(q->ind); 
  } else {
    *rvr = INF;
    return(b[ii]-1);
  }
}

long GetE(long ii, long ind) {
  struct bst *p;
  p = r[ii];
  while (p->ind != ind) 
    if (ind < p->ind) p = p->l; else p = p->r;
  return(p->vr);
}

long GetOK(long ii, long ind) {
  struct bst *p;
  p = r[ii];
  while ((p != NULL) && (p->ind != ind)) 
    if (ind < p->ind) p = p->l; else p = p->r;
  if (p == NULL) return(0); else return(1);
}

void PutN(long ii, long vr, long ind) {
  struct bst *p, *q, *t;
  if (r[ii] == NULL) {
    r[ii] = (struct bst *)malloc(sizeof(struct bst));
    r[ii]->ind = ind;
    r[ii]->vr = vr;
    r[ii]->l = r[ii]->r = NULL;
    return;
  }
  p = r[ii]; q = NULL;
  while (p != NULL) {
    q = p;
    if (vr < p->vr) p = p->l; else p = p->r;
  }
  t = (struct bst *)malloc(sizeof(struct bst));
  t->vr = vr;
  t->ind = ind;
  t->l = t->r = NULL;
  if (q->vr > vr) q->l = t; else q->r = t;
  return;
}

void InitM() {
  long ii;
  Init();
  nn = GetN();
  kk = GetK();
  mm = 0;
  for (ii = 0; ii < nn; ii++) {
    b[ii] = GetLen(ii+1); mm += b[ii];
  }
  for (ii = 0; ii < nn; ii++) {
    r[ii] = NULL; lid[ii] = 0; rid[ii] = b[ii]-1;
  }
}


void FindS(long ii, long vr) {
  long ll, rl, sl;
  long vrl, lvr, rvr;
  ll = GetL(ii, vr, &lvr);
  rl = GetU(ii, vr, &rvr);
  while (ll <= rl) {
    sl = (ll+rl)/2;
    vrl = GetA(ii+1, sl+1);
    PutN(ii, vrl, sl);
    if (vrl > vr) rl = sl-1; else ll = sl+1;
  }
  sid[ii] = rl; svr[ii] = vrl;
}


long FindK() {
  long brp;
  long vrl;
  long ii, jj;
  long ss, sl;
  long tt, xx[MAXN];
  long kk1;
  brp = 0;
  if (kk < mm/2) {
    kk1 = mm/2;
    while (kk < kk1/2) kk1 = kk1/2;
  } else {
    kk1 = mm/2;
    while (mm+kk1 < 2*kk) kk1 = (mm+kk1)/2;
  }
  while(1) {
    if (brp++ == 0) {
      jj = 0;
      sl = (rid[jj]-lid[jj])*kk1/mm;
      sid[jj] = sl;
    } else {
      for (jj = 0; lid[jj] >= rid[jj]; jj++);
      sl = (lid[jj]+rid[jj])/2;
      sid[jj] = sl;
    }
    vrl = GetA(jj+1, sl+1);
    PutN(jj, vrl, sl);
    for (ii = 0; ii < nn; ii++) 
      if (ii != jj) FindS(ii, vrl);
    for (ss = 0, ii = 0; ii < nn; ii++) ss += (sid[ii]+1);
    if (ss < kk) {
      for (ii = 0; ii < nn; ii++) lid[ii] = sid[ii]+1;
      continue;
    }
    if (ss-nn > kk) {
      for (ii = 0; ii < nn; ii++) rid[ii] = sid[ii]-1;
      continue;
    }
    break;
  }
  for (ii = 0; ii < nn; ii++) 
    xx[ii] = GetE(ii, sid[ii]);
  while (ss >= kk) {
    for (jj = 0, ii = 1; ii < nn; ii++)
      if (xx[ii] > xx[jj]) jj = ii;
    tt = xx[jj];
    sid[jj]--;
    if (sid[jj] < 0) xx[jj] = -INF;
    else {
      if (GetOK(jj, sid[jj]))
        xx[jj] = GetE(jj, sid[jj]);
      else
        xx[jj] = GetA(jj+1, sid[jj]+1);
    }
    ss--;
  }
  return(tt);
}
         
main() {
  long w;
  FILE *fout;
  InitM();
  w = FindK();
  fout = fopen("ZAD2.RES", "w");
  fprintf(fout, "%ld\n", w);
  fclose(fout);
  Finish();
}
