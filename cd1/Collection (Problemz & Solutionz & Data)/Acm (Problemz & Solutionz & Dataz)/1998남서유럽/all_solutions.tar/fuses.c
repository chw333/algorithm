/* SWERC'98 - Fuses         */
/* 09/08/98 - Matthias Ruhl */

#include <stdio.h>

#define MAXDEVICES 1000

FILE *inp;
int n,m,fc,c[MAXDEVICES];
char on[MAXDEVICES];
int caseno=1;

int read_data()
{
  int i;

  fscanf(inp,"%d %d %d",&n,&m,&fc);
  if(n == 0 && m == 0 && fc == 0) return 0;
  for(i=0;i<n;i++)
    fscanf(inp,"%d",c+i);
  return 1;
}

void process_data()
{
  int i,d,cc,max;

  for(i=0;i<n;i++)
    on[i] = 0;
  cc = max = 0;

  for(i=0;i<m;i++)
    {
      fscanf(inp,"%d",&d);
      d--;
      if(on[d]) { cc -= c[d]; on[d] = 0; }
      else { cc += c[d]; on[d] = 1; }
      if(cc > max) max = cc;
    }
  printf("Sequence %d\n",caseno++);
  if(max > fc) printf("Fuse was blown.\n\n");
  else
    {
      printf("Fuse was not blown.\n");
      printf("Maximal power consumption was %d amperes.\n\n",max);
    }
}

int main()
{
  inp = fopen("fuses.in","r");
  while(read_data())
    process_data();
  fclose(inp);
  return 0;
}
