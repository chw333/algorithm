#include<stdio.h>
#include<math.h>

#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"
#define MAX_N 1000
#define MAX_M 1000
#define MAX MAX_N * MAX_M
#define MAX_QUEUE 2000

int n, m;
int castle[MAX_N+2][MAX_M+2];
long forward[MAX_N+2][MAX_M+2], backward[MAX_N+2][MAX_M+2];
int queue[MAX_QUEUE][2];
int front = 0, rear = -1;
int res_x, res_y, res_n;

void Read_data()
{
	FILE *inf;
	int i, j;

	inf = fopen(INPUT_FILE, "r");
	fscanf(inf, "%d %d", &n, &m);

	for(i=1; i<=n; i++)
		for(j=1; j<=m; j++)
			fscanf(inf, "%d", &castle[i][j]);

	fclose(inf);
}

void initialize()
{
	int i, j;

	for(i=0; i<=n+1; i++) {
		castle[i][0] = 1;	castle[i][m+1] = 1;
	}

	for(i=1; i<=m; i++) {
		castle[0][i] = 1;	castle[n+1][i] = 1;
	}

	for(i=0; i<=n+1; i++)
		for(j=0; j<=m+1; j++) {
			forward[i][j] = MAX;	backward[i][j] = MAX;
		}
}

bool empty_queue()
{
	if (front == (rear + 1) % MAX_QUEUE) return true;
	else return false;
}

void insert_queue(int y, int x)
{
	rear = (rear + 1) % MAX_QUEUE;
	queue[rear][0] = y;
	queue[rear][1] = x;
}

void delete_queue(int *y, int *x)
{
	*y = queue[front][0];
	*x = queue[front][1];
	front = (front + 1) % MAX_QUEUE;
}

// �Ա����� �� ��ġ���� �ִܰŸ��� ���Ѵ�.
void go_forward()
{
	int y, x;
	
	forward[n][1] = 1;
	insert_queue(n, 1);

	while(!empty_queue()) {
		delete_queue(&y, &x);
		if (castle[y-1][x] == 0 && forward[y-1][x] == MAX) {
			forward[y-1][x] = forward[y][x] + 1;
			insert_queue(y-1, x);
		}
		if (castle[y+1][x] == 0 && forward[y+1][x] == MAX) {
			forward[y+1][x] = forward[y][x] + 1;
			insert_queue(y+1, x);
		}
		if (castle[y][x-1] == 0 && forward[y][x-1] == MAX) {
			forward[y][x-1] = forward[y][x] + 1;
			insert_queue(y, x-1);
		}
		if (castle[y][x+1] == 0 && forward[y][x+1] == MAX) {
			forward[y][x+1] = forward[y][x] + 1;
			insert_queue(y, x+1);
		}
	}
}

// �ⱸ���� �� ��ġ���� �ִܰŸ��� ���Ѵ�.
void go_backward()
{
	int y, x;
	
	backward[1][m] = 1;
	insert_queue(1, m);

	while(!empty_queue()) {
		delete_queue(&y, &x);
		if (castle[y-1][x] == 0 && backward[y-1][x] == MAX) {
			backward[y-1][x] = backward[y][x] + 1;
			insert_queue(y-1, x);
		}
		if (castle[y+1][x] == 0 && backward[y+1][x] == MAX) {
			backward[y+1][x] = backward[y][x] + 1;
			insert_queue(y+1, x);
		}
		if (castle[y][x-1] == 0 && backward[y][x-1] == MAX) {
			backward[y][x-1] = backward[y][x] + 1;
			insert_queue(y, x-1);
		}
		if (castle[y][x+1] == 0 && backward[y][x+1] == MAX) {
			backward[y][x+1] = backward[y][x] + 1;
			insert_queue(y, x+1);
		}
	}
}

void Solve()
{
	int i, j;
	long min_forward, min_backward;

	initialize();
	go_forward();
	go_backward();

// ��� ���� ���Ͽ� �� ���� �㹰���� ���� �ִܰŸ��� ���Ͽ� ���Ѵ�.
	res_n = forward[1][m];
	res_y = res_x = 0;

	for(i=1; i<=n; i++)
		for(j=1; j<=m; j++)
			if (castle[i][j] == 1) {
				min_forward = forward[i-1][j];
				if (forward[i+1][j] < min_forward) min_forward = forward[i+1][j];
				if (forward[i][j-1] < min_forward) min_forward = forward[i][j-1];
				if (forward[i][j+1] < min_forward) min_forward = forward[i][j+1];
				min_backward = backward[i-1][j];
				if (backward[i+1][j] < min_backward) min_backward = backward[i+1][j];
				if (backward[i][j-1] < min_backward) min_backward = backward[i][j-1];
				if (backward[i][j+1] < min_backward) min_backward = backward[i][j+1];

				if (min_forward + min_backward + 1 < res_n) {
					res_n = min_forward + min_backward + 1;
					res_y = i;
					res_x = j;
				}
			}
}

void Output_result()
{
	FILE *outf;

	outf = fopen(OUTPUT_FILE, "w");

	fprintf(outf, "%d %d\n", res_y, res_x);
	fprintf(outf, "%d\n", res_n);

	fclose(outf);
}

void main()
{
	Read_data();
	Solve();
	Output_result();
}