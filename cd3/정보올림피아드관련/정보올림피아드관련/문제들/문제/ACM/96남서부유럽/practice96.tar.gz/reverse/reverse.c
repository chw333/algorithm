#include <stdio.h>
#include <strings.h>
#include <ctype.h>

char line[80];
int len;

int main ()
{
  FILE * in = fopen ("reverse.in","r");
  int i,j;
  int num;
  fscanf (in," %d ", &num);
  for (i=0; i<num;++i)
    {
      fgets (line,80, in);
      for (j=strlen (line)-2;j>=0; --j)
	{
	  printf ("%c",(line[j]));
	}
      printf ("\n");
    }
  printf ("\n");
  return (0);
}

