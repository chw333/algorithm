#include <stdio.h>

int main()
{
  int s, i, h;
  FILE *input = fopen("floppies.in", "r");
  i = 0;
  while (1)
    {
      i++;
      fscanf(input, "%d", &s);
      if (s == 0) break;
      s = (s + 1) / 2;
      h = (s + 1) / 2;
      s += h;
      s = (s + 30000*61  - 1) / (30000*61);
      printf("File #%d\nJohn needs %d floppies.\n", i, s);
      printf("\n");
    }
  fclose(input);
  return 0;
}
