#include <stdio.h>

int main()
{
  int p, s, i;
  FILE* input = fopen("golf.in", "r");
  i = 1;
  while(1)
    {
      fscanf(input, "%d %d", &p, &s);
      if (p == 0) break;
      printf("Hole #%d\n", i++);
      if (s == 1)
	{
	  printf("Hole-in-one.");
	}
      else
	if (s < p - 2)
	  {
	    printf("Double eagle.");
	  }
      else
	if (s > p + 1)
	  printf("Double bogey.");
      else
	if (s == p + 1)
	  printf("Bogey.");
	else 
	  if (s == p)
	    printf("Par.");
	  else
	    if (s == p - 1)
	      printf("Birdie.");
	    else
	      if (s == p - 2)
		printf("Eagle.");
	      else printf("Double eagle.");
      printf("\n\n");
    }
  fclose(input);
  return 0;
}
