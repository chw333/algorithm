/* SWERC'97 - There's treasure everywhere! */
/*  11/9/97 - Matthias Ruhl                */

#include <stdio.h>
#include <ctype.h>
#include <math.h>

int main()
{
  FILE *inp;
  char *dir,*m,map[300];
  int d,caseno = 1;
  double sq2,x,y;
  
  sq2 = sqrt(0.5);
  inp = fopen("treasure.in","r");
  while(fscanf(inp,"%s",map) && strcmp(map,"END"))
    {
      x = y = 0.0;
      m = map;
      while(*m)
	{
	  d = 0;
	  while(isdigit(*m)) d = 10*d + (*m++ - '0');
	  for(dir=m;isalpha(*m);m++);
	  if(*m == ',') *m++ = 0; else *m = 0;
	  if(strcmp(dir,"N") == 0) y += d;
	  if(strcmp(dir,"NE") == 0) { x += sq2*d; y += sq2*d; }
	  if(strcmp(dir,"E") == 0) x += d;
	  if(strcmp(dir,"SE") == 0) { x += sq2*d; y -= sq2*d; }
	  if(strcmp(dir,"S") == 0) y -= d;
	  if(strcmp(dir,"SW") == 0) { x -= sq2*d; y -= sq2*d; }
	  if(strcmp(dir,"W") == 0) x -= d;
	  if(strcmp(dir,"NW") == 0) { x -= sq2*d; y += sq2*d; }
	}
      printf("Map #%d\n",caseno++);
      printf("The treasure is located at (%.3f,%.3f).\n",x,y);
      printf("The distance to the treasure is %.3f.\n\n",sqrt(x*x+y*y));
    }
  fclose(inp);
  return 0;
}
