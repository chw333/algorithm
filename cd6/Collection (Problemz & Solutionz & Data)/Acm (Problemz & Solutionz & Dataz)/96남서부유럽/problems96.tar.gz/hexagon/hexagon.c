#include <stdio.h>

typedef struct 
{
  int assign[5];
  int value;
} dir;

FILE *inp;
int val[3][3];
dir d[3][243];

int asgn[19][3] = 
{ { 0,0,2 }, { 0,1,1 }, { 0,2,0 }, { 1,0,3 }, { 1,1,2 },
  { 1,2,1 }, { 1,3,0 }, { 2,0,4 }, { 2,1,3 }, { 2,2,2 },
  { 2,3,1 }, { 2,4,0 }, { 3,1,4 }, { 3,2,3 }, { 3,3,2 },
  { 3,4,1 }, { 4,2,4 }, { 4,3,3 }, { 4,4,2 } };
int w[5] = { 3,4,5,4,3 };


  /* Sort dir's decreasingly */

int compare_dir(dir *a, dir *b)
{
  return b->value - a->value;
}

void make_dirs()
{
  int a1,a2,a3,a4,a5,i,j,k;

  for(i=0;i<3;i++)
    {
      for(j=a1=0;a1<3;a1++)
	for(a2=0;a2<3;a2++)
	  for(a3=0;a3<3;a3++)
	    for(a4=0;a4<3;a4++)
	      for(a5=0;a5<3;a5++,j++)
		{
		  d[i][j].assign[0] = a1;
		  d[i][j].assign[1] = a2;
		  d[i][j].assign[2] = a3;
		  d[i][j].assign[3] = a4;
		  d[i][j].assign[4] = a5;
		  for(k=0;k<3;k++)
		    if(((a1 == k)*3 + (a2 == k)*4 + (a3 == k)*5 + 
			(a4 == k)*4 + (a5 == k)*3) > 8)
		      {
			d[i][j].value = -1;
			goto bad;
		      }
		  d[i][j].value = 0;
		  for(k=0;k<5;k++)
		    d[i][j].value += w[k]*val[i][d[i][j].assign[k]];
		bad: ;
		}
      qsort(d[i],243,sizeof(dir),compare_dir);
      for(j=k=0;j<243;j++) if(d[i][j].value >= 0) k++;
    }
}

int match(int a1, int a2, int a3)
{
  int i,tile;
  static int used[27];
  
  for(i=0;i<27;i++) used[i] = 0;
  for(i=0;i<19;i++)
    {
      tile = 
	9*d[0][a1].assign[asgn[i][0]]+
	3*d[1][a2].assign[asgn[i][1]]+
	  d[2][a3].assign[asgn[i][2]];
      if(used[tile]) return 0;
      used[tile] = 1;
    }
  return 1;
}

void solve_problem()
{
  int a1,a2,a3;
  int best;
  
  best = -1;
  make_dirs();
  for(a1=0;a1<54;a1++)
    {
      if(d[0][a1].value + d[1][0].value + d[2][0].value <= best) break;
      for(a2=0;a2<54;a2++)
	{
	  if(d[0][a1].value + d[1][a2].value + d[2][0].value <= best) break;
	  for(a3=0;a3<54;a3++)
	    {
	      if(d[0][a1].value + d[1][a2].value + d[2][a3].value <= best) break;
	      if(match(a1,a2,a3)) 
		best = d[0][a1].value + d[1][a2].value + d[2][a3].value;
	    }
	}
    }
  printf("%d\n\n",best);
}

main()
{
  int i,j,k,n;

  inp = fopen("hexagon.in","r");
  fscanf(inp,"%d",&n);
  for(i=0;i<n;i++)
    {
      for(j=0;j<3;j++)
	for(k=0;k<3;k++)
	  fscanf(inp,"%d",&val[j][k]);
      printf("Test #%d\n",i+1);
      solve_problem();
    }
}
