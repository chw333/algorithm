#include<stdio.h>
#include<conio.h>
#include<limits.h>
#include<stdlib.h>
#include<string.h>

#define MAX 21

static int room[MAX][MAX];
static int road[MAX][MAX];
static int check[MAX][MAX];
static int remember[MAX][MAX];
static int addx[4]={-1,0,1,0};
static int addy[4]={0,-1,0,1};
static char str[4];
static int oil[4];
int sx,sy,ex,ey;
int len=INT_MAX,sum;
int numberx,numbery;

void backtr(int x,int y,int csum)
{
	int i,j,count;
	int number;
	int rx,ry;
	check[x][y]=1;
	if(x==ex&&y==ey){
		count=0;
		for(i=0;i<numberx;i++){
			for(j=0;j<numbery;j++){
				if(check[i][j]) count++;
			}
		}
		if(count<len){
			len=count;
			sum=csum;
			for(i=0;i<numberx;i++){
				for(j=0;j<numbery;j++){
					remember[i][j]=check[i][j];
				}
			}
		}
		else if(count==len){
			if(sum>csum){
				len=count;
				sum=csum;
				for(i=0;i<numberx;i++){
					for(j=0;j<numbery;j++){
						remember[i][j]=check[i][j];
					}
				}
			}
		}
		return;
	}
	for(i=0;i<4;i++){
		itoa(road[x][y],str,2);
		number=strlen(str);
		count=3;
		for(j=0;j<4;j++) oil[j]=0;
		for(j=number-1;j>=0;j--){ if(str[j]=='1') oil[count]=1; count--; }
		if(oil[i]){
			rx=x+addx[i], ry=y+addy[i];
			if(!check[rx][ry]){
				if(abs(room[x][y]-room[rx][ry])<10){
					backtr(rx,ry,csum+(abs(room[x][y]-room[rx][ry])));
				}
			}
		}
	}
	check[x][y]=0;
}

void main()
{
	FILE *fs=fopen("4.in2","r");
	FILE *fp=fopen("4.out","w");
	int i,j;
	int a,b,c,d;
	fscanf(fs,"%d %d\n",&numberx,&numbery);
	for(i=0;i<numberx;i++){
		for(j=0;j<numbery;j++){
			fscanf(fs,"%d ",&room[i][j]);
		}
		fscanf(fs,"\n");
	}
	while(1){
		fscanf(fs,"%d %d %d %d\n",&a,&b,&c,&d);
		if(!a&&!b&&!c&&!d) break;
		a--, b--, c--, d--;
		if(a==c){
			if(b<d){
				for(i=b;i<=d;i++) road[a][i]+=1;
			}
			else{
				for(i=d;i<=b;i++) road[a][i]+=4;
			}
		}
		else{
			if(a<c){
				for(i=a;i<=c;i++) road[i][b]+=2;
			}
			else{
				for(i=c;i<=a;i++) road[i][b]+=8;
			}
		}
	}
	fscanf(fs,"%d %d %d %d",&sx,&sy,&ex,&ey);
	sx--, sy--, ex--, ey--;
	check[sx][sy]=1;
	backtr(sx,sy,0);
	fprintf(fp,"%d %d\n",len,sum);
	for(i=0;i<numberx;i++){
		for(j=0;j<numbery;j++){
			fprintf(fp,"%d ",remember[i][j]);
		}
		fprintf(fp,"\n");
	}
}