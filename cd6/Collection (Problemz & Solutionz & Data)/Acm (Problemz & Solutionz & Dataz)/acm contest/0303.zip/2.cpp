// counsel.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <memory.h>

#ifdef _DEBUG
#define OUTFILE "CON"
#else
#define OUTFILE "out.txt"
#endif

struct state
{
	state() : count(0) { memset(next,0,sizeof(next)); }
	state* next[7];
	int count;
};

FILE* fout=fopen(OUTFILE,"w");

int len=0,path[12];

void backtrack_and_print(state* cur)
{
	if(len>=2 && cur->count>=3)
	{
		fprintf(fout,"(");
		for(int lp=0;lp<len;lp++)
		{
			fprintf(fout,"%d ",path[lp]);
		}
		fprintf(fout,": %d )\n",cur->count);
	}
	len++;
	for(int lp=0;lp<7;lp++) if(cur->next[lp])
	{
		path[len-1]=lp;
		backtrack_and_print(cur->next[lp]);
	}
	len--;
}

int main(int argc, char* argv[])
{
	FILE* fin=fopen("in.txt","r");
	int dt[12],lpd,lp;
	for(lpd=0;lpd<12;lpd++)
	{
		dt[lpd]=0;
		for(lp=0;lp<6;lp++)
		{
			int t;
			fscanf(fin,"%d",&t);
			if(t) dt[lpd]++;
		}
		fprintf(fout,"%d ",dt[lpd]);
		fflush(fout);
	}
	fprintf(fout,"\n");
	state root;
	for(lpd=0;lpd<12;lpd++)
	{
		state* cur=&root;
		for(lp=lpd;lp<12;lp++)
		{
			if(!cur->next[dt[lp]]) cur->next[dt[lp]]=new state;
			cur=cur->next[dt[lp]];
			cur->count++;
		}
	}
	backtrack_and_print(&root);
	fclose(fout);
	fclose(fin);
	return 0;
}
