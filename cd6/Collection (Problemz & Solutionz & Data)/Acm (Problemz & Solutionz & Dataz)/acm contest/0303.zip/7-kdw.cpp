#include <fstream.h>

const char infile[20] = "7.inp";
const char outfile[20] = "7.out";

int match[100][100], node1[100], node2[100];
int tree1[100][100], tree2[100][100], n, m, x, y;
int check1[100], check2[100], n1, m1, check3[100];
int check4[100][100], check5[100];

void input();
void output();
void process();
void post(int z);
void maketree(int cost, int z, int p[100], int t[100][100]);
int find (int z, int sw);

main()
{
	input();
	process();
	output();
	return 0;
}

void input()
{
	int i;
	ifstream in(infile);
	in >> n >> m;
	for (i = 0; i < n; i++)
		in >> node1[i];
	for (i = 0; i < m; i++)
		in >> node2[i];
}
void process()
{
	x = 0; y = n;
	maketree(node1[0] - 1, 0, node1, tree1);
	x = 0; y = m;
	maketree(node2[0] - 1, 0, node2, tree2);
	post(0);
}

void output()
{
	int i;
	ofstream out(outfile);
	for (i = 0; i < m; i++)
	{
		if (match[0][i] == 1) {out << "1" << endl << i + 1; return;}
	}
	out << "0" << endl << "0";
	out.close();
}

void maketree(int cost,int z, int p[100], int t[100][100])
{
	while(1)
	{
		if (cost == 0) return;
		x++;
		cost = cost - p[x];
		maketree (p[x] - 1, x, p, t);
		t[z][x] = 1;
	} 
}

void post(int z)
{
	int i, sw, j, k, l;
	for (i = 0; i < n; i++)
	{
		if (tree1[z][i] == 1) post(i);
	}
	n1 = 0;
	for (i = 0; i < n; i++)
	{
		if (tree1[z][i] == 1) check1[n1++] = i;
	}
	for (i = 0; i < m; i++)
	{
		m1 = 0;
		for (j = 0; j < m; j++)
		{
			if (tree2[i][j] == 1) check2[m1++] = j;
		}
		for (j = 0; j < m1; j++)
			check5[j] = 0;
		for (j = 0; j < n1; j++)
			check3[j] = 0;
		for (k = 0; k < n1; k++)
			for (j = 0; j < m1; j++)
				if (match[check1[k]][check2[j]] == 1) check4[k][j] = 1; else check4[k][j] = 0;
		while(1)
		{
			sw = 0;
			for (k = 0; k < n1; k++)
			{
				if (check3[k] == 0)
				{
					for (j = 0; j < m1; j++)
					{
						if (check4[k][j] == 1 && check5[j] == 0)
						{
							check3[k] = 1;
							check5[k] = 1;
							check4[k][j] = 2;
							sw = 1;
							for (l = 0; l < m1; l++)
							{
								if (check4[k][l] == 1 && check5[l] == 0)
								{
									if (find(l, 0) == 2)
									{
										check5[l] = 1;
										check4[k][l] = 2;
										break;
									}
								}
							}
						}								
					}
				}
			}
			if (sw == 0) break;
		}
		for (j = 0; j < n1; j++)
			if (check3[j] == 0) goto a;
		match[z][i] = 1;
a:	;
	}
}

int find (int z, int sw)
{
	int i;
	if (sw == 2)
	{
		for (i = 0; i < n1; i++)
		{
			if (check4[i][z] == 1)
			{
				if (find(i, 1) == 2)
				{
					check4[i][z] = 2;
					return(2);
				}
			}
		}
	}
	else
	{
		if (sw == 1 && check3[z] == 0) {check3[z] = 1; return(2);}	
		for (i = 0; i < n1; i++)
		{
			if (check4[z][i] == 2)
			{
				if (find(i, 2) == 2)
				{
					check4[z][i] = 1;
					return(2);
				}
			}
		}
	}
}
