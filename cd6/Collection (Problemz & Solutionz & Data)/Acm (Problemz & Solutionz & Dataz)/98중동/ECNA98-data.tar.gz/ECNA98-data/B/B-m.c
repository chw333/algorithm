/* Copyright Michael Van Biesbrouck (ACM ICPC ECNA 98) */


#include <stdio.h>
#include <limits.h>

	int
main( void )
{
	int n, L, C, min, i, j, t, k, m, c;
	int Case = 0;
	int len[1024];
	int d[1024][1024]; /* d[i][j] = min dis for sched 1..i on days 1..j */
	while( scanf("%d",&n) && n ){
		/* input */
		scanf("%d %d",&L,&C);
		len[0] = 0;
		for(i=1;i<=n;i++) scanf("%d",len+i);
		/* number of lectures */
		min = 0;
		j = L+1;
		for(i=1;i<=n;i++){
			if( j+len[i] > L ){
				min++;
				j=0;
			}
			j+=len[i];
		}
		/* DP */
		for(i=0;i<=n;i++) for(j=0;j<=min;j++) d[i][j] = INT_MAX;
		d[0][0]=0;
		for(j=1;j<=min;j++) for(i=0;i<=n;i++){
			m = d[i][j-1];
			if( m != INT_MAX) m += (L-10)*(L-10);
			t = len[i];
			for( k=i-1 ; t<=L && k>=0 ; k-- ){
				if( d[k][j-1] != INT_MAX ){
					if( t == L ) c = 0;
					else if( t+10 >= L ) c = -C;
					else c = (L-t-10)*(L-t-10);
					c += d[k][j-1];
					if( c < m ) m = c;
/*	printf("%d %d %d %d %d %d+%d=%d\n",i,j,k,m,t,d[k][j-1],c-d[k][j-1],c); */
				}
				t+=len[k];
			}
			d[i][j] = m;
		}
		/* output */
		if( Case ) printf( "\n" );
		printf( "Case %d:\n\n", ++Case );
		printf( "Minimum number of lectures: %d\n", min );
		printf( "Total dissatisfaction index: %d\n", d[n][min] );
		/*for(i=1;i<=n;i++){
			for(j=1;j<=min;j++) printf( "%10d ", d[i][j] );
			printf("\n");
		}*/
	}

	return 0;
}
