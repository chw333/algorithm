/* Copyright Derek Kisman (ACM ICPC ECNA 98) */


#define SMALL -1000000000

int di[1010][1010];
int tl[1010];
int n, L, C;

main() {
	int i, j, k, x, y, z, prob=1;

	for(;;) {
		scanf( " %d", &n );
		if( n == 0 ) break;
		scanf( " %d %d", &L, &C );
		for( i = 0; i < n; i++ ) scanf( " %d", &tl[i+1] );

		for( i = 0; i <= n; i++ ) for( j = 0; j <= n; j++ ) di[i][j] = 1000000000;
		di[0][0] = 0;

		for( i = 0; i < n; i++ ) {
			if( di[i][n] != 1000000000 ) break;
			for( j = i; j < n; j++ ) {
				if( di[i][j] == 1000000000 ) break;
				x = L;
				for( k = j+1; k <= n; k++ ) {
					x -= tl[k];
					if( x < 0 ) break;
					if( x == 0 ) {
						y = di[i][j];
					} else if( x <= 10 ) {
						y = di[i][j] - C;
					} else {
						y = di[i][j] + (x-10)*(x-10);
					}
					if( y < di[i+1][k] ) di[i+1][k] = y;
				}
			}
		}

		if( prob>1) putchar( '\n' );
		printf( "Case %d:\n\n", prob++ );
		printf( "Minimum number of lectures: %d\n", i );
		printf( "Total dissatisfaction index: %d\n", di[i][n] );
	}
}
