#!/xhbin/perl5 -sw
# Copyright Michael Van Biesbrouck (ACM ICPC ECNA 98)


$debug = 0 if ! defined $debug;

$n=<>;

while($n--){
	%H=();
	%L=();
	$lines=0;

	while(<>){
		chomp;
		$lines++;
		die "bad line" unless /^(\w*)\s+(\w*)\s+(\w+)$/;
		$left = $1;
		$right = $2;
		$bal = $3;
		for $j ((1,-1)){
			for($i="A";$i lt "M";$i++){
				$w = 0;
				while( $left =~ /./g ){
					$w += 100;
					$w += $j if $i eq $&;
				}
				while( $right =~ /./g ){
					$w -= 100;
					$w -= $j if $i eq $&;
				}
				print "$j $i $w\n" if $debug;
				if( !($w == 0 && $bal eq "even") &&
					!($w > 0 && $bal eq "up") &&
					!($w < 0 && $bal eq "down")
				){
					if( $j < 0 ){ $L{$i} = 1; }
					else { $H{$i} = 1; }
				}
			}
		}
		last if $lines == 3;
	}

	for($i="A";$i lt "M";$i++){
		print "$i is the counterfeit coin and it is light.\n" if !exists $L{$i};
		print "$i is the counterfeit coin and it is heavy.\n" if !exists $H{$i};
	}
}

0;
