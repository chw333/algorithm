/* Copyright Derek Kisman (ACM ICPC ECNA 98) */


char ni[16][10000];

int d[10];

void inv( char *n1, char *n2 ) {
	int i, j, k, x, y, z, n;

	for( i = 0; i < 10; i++ ) d[i] = 0;
	for( i = 0; n1[i]; i++ ) d[n1[i]-'0']++;
	x = 0;
	for( i = 0; i < 10; i++ ) if( d[i] ) {
		for( y = d[i], z = 0; y > 0; y /= 10, z++ );
		y = 0;
		while( d[i] > 0 ) {
			n2[x+z-(++y)] = d[i]%10 + '0';
			d[i] /= 10;
		}
		x += z;
		n2[x++] = i+'0';
	}
	n2[x] = 0;
}

main() {
	int i, j, k, x, y, z, n;

	for(;;) {
		scanf( " %s", ni[0] );
		if( ni[0][0] == '-' ) break;
		for( i = 1; i <= 15; i++ ) {
			inv( ni[i-1], ni[i] );
			for( j = 0; j < i; j++ ) if( !strcmp( ni[j], ni[i] ) ) break;
			if( j < i ) break;
		}
		if( i == 16 ) {
			printf( "%s can not be classified after 15 iterations\n", ni[0] );
		} else if( i == 1 && j == 0 ) {
			printf( "%s is self-inventorying\n", ni[0] );
#if 0
		} else if( j == 0 ) {
			printf( "%s is in an inventory loop of length %d\n", ni[0], i );
#endif
		} else if( j == i-1 ) {
			printf( "%s is self-inventorying after %d steps\n", ni[0], i-1 );
#if 0
		} else {
			printf( "%s enters an inventory loop of length %d after %d steps\n",
				ni[0], i-j, j );
#else
		} else {
			printf( "%s enters an inventory loop of length %d\n", ni[0], i-j );
#endif
		}
	}
}
