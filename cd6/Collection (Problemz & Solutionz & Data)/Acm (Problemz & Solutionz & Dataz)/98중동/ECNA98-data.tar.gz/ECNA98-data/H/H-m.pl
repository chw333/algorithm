#!/xhbin/perl5 -sw
# Copyright Michael Van Biesbrouck (ACM ICPC ECNA 98)


$debug = 0 if ! defined $debug;

while_loop:
while(<>){
	chomp;
	last if $_ < 0;
	@n = ( );
	print $_," ";
	for($i=0;$i<15;$i++){
		%h=();
		$n[$i] = $_;
		for($j=0;$j<10;$j++){ $h{$j} = 0 };
		while(/./g){ $h{$&}++; }
		$_="";
		for($j=0;$j<10;$j++){
			if( $h{$j} > 0 ){
				$_ .= $h{$j} . $j;
			}
		}
		for($j=0;$j<=$i;$j++){
			if( $_ eq $n[$j] ){
				if( $i == $j ){
					print "is self-inventorying";
					if( $j == 0 ){
						print "\n";
					} else {
						print " after $j steps\n";
					}
				} else {
#					if( $j == 0 ){
#						print "is in an inventory loop of length ",$i+1,"\n";
#					} else {
#						print "enters an inventory loop of length ",
#							$i-$j+1, " after $j steps\n";
#					}
					print "enters an inventory loop of length ", $i-$j+1, "\n";
				}
				do { $i=0;for(@n,$_){ print $i++, ": ",$_, "\n"; } } if $debug;
	next while_loop;
			}
		}
	}
	print "can not be classified after 15 iterations\n";
}
0;
