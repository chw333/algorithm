/* Copyright Derek Kisman (ACM ICPC ECNA 98) */


int ns[1010];
int s[1010][4];
int sn[1010][4];
int su[5010];
int n, m;

int vis[1010];
int p[1010];
int np;
int v1, v2;

int FindPath( int x, int y ) {
	int i;
	if( vis[x] ) return 0;
	vis[x] = 1;
	if( x == y ) return 1;
	np++;
	for( i = 0; i < ns[x]; i++ ) if( x != v1 || s[x][i] != v2 ) {
		p[np-1] = i;
		if( FindPath( s[x][i], y ) ) return 1;
	}
	np--;
	return 0;
}

main() {
	int i, j, k, m, x, y, z, prob=1, last;

	for(;;) {
		scanf( " %d %d", &n, &m );
		if( n+m == 0 ) break;
		for( i = 0; i < n; i++ ) ns[i] = 0;
		for( i = 0; i < m; i++ ) {
			scanf( " %d %d", &x, &y );
			x--; y--;
			s[x][ns[x]] = y;
			s[y][ns[y]] = x;
			sn[x][ns[x]++] = i;
			sn[y][ns[y]++] = i;
		}
		for( i = 0; i < m; i++ ) su[i] = 0;
		printf( "%d\n\n", prob++ );
		for( i = 0; i < n; i++ ) for( j = 0; j < ns[i]; j++ ) {
			if( !su[sn[i][j]] ) {
				v1 = i;
				v2 = s[i][j];
				np = 0;
				for( k = 0; k < n; k++ ) vis[k] = 0;
				if( FindPath( i, s[i][j] ) ) {
					x = i;
					for( k = 0; k < np; k++ ) {
						y = s[x][p[k]];
						if( !su[sn[x][p[k]]] ) {
							printf( "%d %d\n", x+1, y+1 );
							su[sn[x][p[k]]] = 1;
						}
						x = y;
					}
					printf( "%d %d\n", s[i][j]+1, i+1 );
					su[sn[i][j]] = 1;
				} else {
					printf( "%d %d\n", i+1, s[i][j]+1 );
					printf( "%d %d\n", s[i][j]+1, i+1 );
					su[sn[i][j]] = 1;
				}
			}
		}

		printf( "#\n" );
	}
}
