/* Copyright Derek Kisman (ACM ICPC ECNA 98) */


typedef struct {
	int active;
	int b;
	int na;
	int ft;
	int pc;
	char asr[100];
	char abn[100];
	char at[100][26];
	int s[26];
	int r[26];
} Processor;

Processor p[26];
int N;
char buff[1000];

main() {
	int i, j, k, x, y, z, n, t, na;
	char ch;

	memset( p, sizeof(Processor)*26, 0 );
	scanf( " %d", &N );
	for( i = 0; i < N; i++ ) {
		scanf( " %c", &ch );
		x = ch-'A';
		p[x].active = 1;
		na++;
		scanf( " %d", &p[x].na );
		for( j = 0; j < p[x].na; j++ ) {
			scanf( " %c", &p[x].abn[j] );
			scanf( " %c", &p[x].asr[j] );
			gets( buff );
			for( k = 0; k < 26; k++ ) p[x].at[j][k] = 0;
			for( k = 0; buff[k]; k++ ) if( buff[k] != ' ' ) {
				p[x].at[j][buff[k]-'A'] = 1;
			}
		}
	}
	for( t = 1; na > 0; t++ ) {
		for( i = 0; i < 26; i++ ) if( p[i].active && !p[i].b ) {
			x = p[i].pc;
			if( p[i].asr[x] == 'S' ) {
				for( j = 0; j < 26; j++ ) p[i].s[j] += p[i].at[x][j];
			} else {
				for( j = 0; j < 26; j++ ) p[i].r[j] += p[i].at[x][j];
			}
			if( p[i].abn[x] == 'B' ) {p[i].b = 1; na--;}
			if( ++p[i].pc == p[i].na ) {
				if( !p[i].b ) na--;
				p[i].b = 2;
			}
/*printf( "Executed %d on %c, %sblocked\n", x, i+'A', p[i].b?"":"not " );*/
		}
		for( i = 0; i < 26; i++ ) for( j = 0; j < 26; j++ )
			while( p[i].s[j] > 0 && p[j].r[i] > 0 ) {
				p[j].r[i]--;
				p[i].s[j]--;
			}
		for( i = 0; i < 26; i++ ) if( p[i].b ) {
			if( p[i].b == 2 ) {
				for( j = 0; j < 26; j++ ) if( p[i].s[j] || p[i].r[j] ) break;
				if( j == 26 ) {
					p[i].b = 3;
					p[i].ft = t;
				}
			} else if( p[i].b == 1 ) {
				for( j = 0; j < 26; j++ ) if( p[i].at[p[i].pc-1][j] ) {
					if( p[i].asr[p[i].pc-1] == 'S' ) {
						if( p[i].s[j] ) break;
					} else {
						if( p[i].r[j] ) break;
					}
				}
				if( j == 26 ) {
					p[i].b = 0;
					na++;
				}
			}
		}
	}
	for( i = 0; i < 26; i++ ) if( p[i].active ) {
		if( p[i].b == 3 ) {
			printf( "%c finishes at t=%d\n", i+'A', p[i].ft );
		} else if( p[i].b == 2 ) {
			printf( "%c never finishes because of ", i+'A' );
			x = 0;
			for( j = 0; j < 26; j++ ) if( p[i].s[j] || p[i].r[j] ) {
				if( x ) printf( " and " );
				putchar( j+'A' );
				x = 1;
			}
			putchar( '\n' );
		} else if( p[i].b == 1 ) {
			printf( "%c never finishes because of ", i+'A' );
			x = 0;
			for( j = 0; j < 26; j++ ) if( p[i].s[j] || p[i].r[j] ) {
				if( x ) printf( " and " );
				putchar( j+'A' );
				x = 1;
			}
			putchar( '\n' );
		} else {
			printf( "%c ERROR!\n", i+'A' );
		}
	}
}
