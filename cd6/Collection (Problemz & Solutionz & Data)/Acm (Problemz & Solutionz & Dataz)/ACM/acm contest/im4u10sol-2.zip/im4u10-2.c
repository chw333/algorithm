//  ������ ���� ã��

#include <stdio.h>
#include <math.h>

#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"
#define MAX_N 500
#define sqr(x) ((x)*(x))

int A, B;
int N;
int p[MAX_N], q[MAX_N], r[MAX_N];
int M;
double sec[MAX_N][2];

void read_input()
{
	FILE *inf;
	int i;

	inf = fopen(INPUT_FILE, "r");
	fscanf(inf, "%d %d", &A, &B);
	fscanf(inf, "%d", &N);

	for (i=0; i<N; i++)
		fscanf(inf, "%d %d %d", &p[i], &q[i], &r[i]);

	fclose(inf);
}

void exchange(double *n1, double *n2)
{
	double n3;

	n3 = *n1;
	*n1 = *n2;
	*n2 = n3;
}

void solve()
{
	int i, j;
	int a, b;
	double P, Q, R;
	double x0_1, x0_2, y0_1, y0_2;
	double x1, x2;

	for (i=0; i<N; i++) {
		a = A - p[i];	b = B - q[i];		
		P = sqr(a) + sqr(b);
		Q = sqr(r[i]) * a;
		R = sqr(sqr(r[i])) - sqr(r[i]*b);
		x0_1 = (Q-sqrt(sqr(Q) - P*R)) / P;
		x0_2 = (Q+sqrt(sqr(Q) - P*R)) / P;
		y0_1 = (sqr(r[i]) - x0_1*a)/b;
		y0_2 = (sqr(r[i]) - x0_2*a)/b;
		x1 = p[i] + (sqr(r[i]) + y0_1 * q[i]) / x0_1;
		x2 = p[i] + (sqr(r[i]) + y0_2 * q[i]) / x0_2;

		if (x1 < x2) {
			sec[i][0] = x1;		sec[i][1] = x2;
		}
		else {
			sec[i][0] = x2;		sec[i][1] = x1;
		}
	}

	for (i=0; i<N-1; i++)
		for (j=i+1; j<N; j++)
			if (sec[i][0] > sec[j][0]) {
				exchange(&sec[i][0], &sec[j][0]);
				exchange(&sec[i][1], &sec[j][1]);
			}

	M = N;
	for (i=0; i<M-1; i++)	
		if (sec[i][1] >= sec[i+1][0]) {
			if (sec[i+1][1] > sec[i][1]) sec[i][1] = sec[i+1][1];
			for (j=i+1; j<M-1; j++) {
				sec[j][0] = sec[j+1][0];
				sec[j][1] = sec[j+1][1];
			}
			M--;
		}
}

void output_result()
{
	FILE *outf;
	int i;
	
	outf = fopen(OUTPUT_FILE, "w");
	fprintf(outf, "%d\n", M);

	for (i=0; i<M; i++)
	fprintf(outf, "%.2f %.2f\n", sec[i][0], sec[i][1]);		

	fclose(outf);
}

void main()
{
	read_input();
	solve();
	output_result();
}