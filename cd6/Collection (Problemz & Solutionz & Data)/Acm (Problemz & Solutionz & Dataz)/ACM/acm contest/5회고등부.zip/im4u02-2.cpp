// 2002. 1 "Inverse"

#include <stdio.h>
#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"
#define MAX_N 100

int N, L;
FILE *inf, *outf;
int res[MAX_N+1];

int connect(int k)
{
	if (k == 2) return 3;
	else return 2;
}

void solve()
{
	int i, j;

	res[0] = 1;		res[1] = 2;

	for(i=2; i<=MAX_N; i++)
		for(j=0; j<i; j++) {
			res[i] += res[j] * connect(i-j);
			res[i] = res[i] % 10;
		}
}

void main()
{	
	int i;

	solve();

	inf = fopen(INPUT_FILE, "r");
	outf = fopen(OUTPUT_FILE, "w");

	fscanf(inf, "%d\n", &N);
	
	for(i=0; i<N; i++) {
		fscanf(inf, "%d\n", &L);
		fprintf(outf, "%d\n", res[L]);
	}

	fclose(inf);
	fclose(outf);
}