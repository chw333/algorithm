
#include <stdio.h>
#include <process.h>
#include <math.h>

#define MAXL 150000

long n;
long num;
long x[10000];

void xread(void)
{
   FILE *f;

   if ((f = fopen("input.txt", "rt")) == 0)
     {
       printf("Cannot open input.txt\n");
       exit(1);
     }
   fscanf(f, "%ld", &n);
   fclose(f);
}

void xprocess(void)
{
   long i;
   double code;

   num = 0;
   i = 0; code = 0;
   do
    {
      i++;
      code += log10(i);
    } while ((long)code != (n - 1) && code < MAXL);
   if (code < MAXL)
     while ((long)code == (n - 1))
       {
	 x[num] = i;
	 num++;
	 i++;
	 code += log10(i);
       }
}

void xwrite(void)
{
   FILE *f;
   int i;

   f = fopen("output.txt", "wt");
   if (num)
    {
      fprintf(f, "%ld\n", num);
      for (i = 0; i < num; i++)
	fprintf(f, "%ld\n", x[i]);
    }
     else
	 fprintf(f, "NO\n");
   fclose(f);
}

void main(void)
{
   xread();
   xprocess();
   xwrite();
}