/* crypto.c */

#include <stdio.h>
#include <ctype.h>
#include <string.h>

const int len = 10;
const char *let = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

int main()
{
	char s1[250], s2[250];
	FILE *f1, *f2;
	unsigned char key[len];
	int i, k, c;
	char *p;

	printf("Input file: "); gets(s1);
	f1 = fopen(s1, "rt");
	printf("Output file: "); gets(s2);
	f2 = fopen(s2, "wt");
	printf("Key (%d bytes): ", len);
	for (i = 0; i < len; ++i) scanf("%d", &key[i]);
	k = 0;
	while ((c = fgetc(f1)) != EOF) {
		p = strchr(let, toupper(c));
		if (p != NULL) {
			i = ((p - let) + key[k]) % strlen(let);
			c = let[i];
			k = (k + 1) % len;
		}
		fputc(c, f2);
	}
	fclose(f1);
	fclose(f2);
	return 0;
}
