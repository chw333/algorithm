/* Sample solution for the problem Teleports, BOI'01 */
/* O(m+n) */
/* Tomek Czajka, 24.05.2001 */

#include <iostream>
#include <fstream>
#include <stack>
#include <vector>
using namespace std;

const char *fileIn = "tel.in";
const char *fileOut = "tel.out";

// number of teleports on each island
int n[2];
// teleport destinations for both islands
vector<int> dest[2];
// how many teleports send to a given teleport on the first island
vector<int> inDegree;
// output - true if the teleport is in "sending" mode
vector<bool> sending[2];


void read() {
  ifstream f(fileIn);
  f >> n[0] >> n[1];
  for(int i=0;i<2;++i) {
    dest[i].resize(n[i]);
    for(int j=0;j<n[i];++j) {
      int x; f >> x;
      dest[i][j]=x-1; // we start numbering from 0
    }
  }
}

void write() {
  ofstream f(fileOut);
  for(int i=0;i<2;++i) {
    for(int j=0;j<n[i];++j) {
      f << (sending[i][j] ? '1' : '0');
    }
    f << '\n';
  }
}

void init() {
  sending[0].assign(n[0],false);
  sending[1].assign(n[1],true);
  inDegree.assign(n[0],0);
  for(int i=0;i<n[1];++i)
    inDegree[dest[1][i]]=inDegree[dest[1][i]]+1; // not ++ !!!!
}

void calc() {
  stack<int> zeroDeg; // the "bad" ones
  
  for(int i=0;i<n[0];++i) {
    if(inDegree[i]==0) zeroDeg.push(i);
  }
  
  while(!zeroDeg.empty()) {
    int x = zeroDeg.top(); zeroDeg.pop();
    sending[0][x]=true;
    int y = dest[0][x];
    if(sending[1][y]) {
      int z = dest[1][y];
      sending[1][y]=false;
      inDegree[z]=inDegree[z]-1; // not -- !!!!
      if(inDegree[z] == 0) zeroDeg.push(z);
    }
  }
}

int main() {
  read(); // nteleports,destinations
  init(); // indegree,sending
  // now the island 1 is sending to island 0
  // but some receiving teleports on island 0 are not getting anything
  calc(); // and now we correct that
  write();
}
