/*
  Test generator, Teleports, BOI'01
  Tomek Czajka, 25.05.2001
*/

#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <vector>
using namespace std;

int n[2];
vector<int> dest[2];

int random(int a,int b) {
  return a + rand()%(b-a+1);
}

void shuffle() {
  vector<int> perm[2];
  for(int i=0;i<2;++i) {
    perm[i].resize(n[i]);
    for(int j=0;j<n[i];++j) perm[i][j]=j;
    for(int j=n[i]-1;j>=1;--j)
      swap(perm[i][j],perm[i][random(0,j)]);
  }
  for(int i=0;i<2;++i) {
    vector<int> ndest(n[i]);
    for(int j=0;j<n[i];++j)
      ndest[perm[i][j]] = perm[1-i][dest[i][j]];
    dest[i]=ndest;
  }
}

void genRandom(int a,int b) {
  n[0]=a;
  n[1]=b;
  for(int i=0;i<2;++i) {
    dest[i].resize(n[i]);
    for(int j=0;j<n[i];++j)
      dest[i][j]=random(0,n[1-i]-1);
  }
}

void genTwoLists(int a) {
  n[0]=n[1]=a;
  for(int i=0;i<2;++i) dest[i].resize(n[i]);
  for(int i=0;i<a/2;++i) {
    dest[0][i]=i;
    dest[1][i]=min(i+1,a/2-1);
  }
  for(int i=a/2;i<a;++i) {
    dest[1][i]=i;
    dest[0][i]=min(i+1,a-1);
  }
  shuffle();
}

void write(const char *fn) {
  ofstream f(fn);
  f << n[0] << ' ' << n[1] << '\n';
  for(int i=0;i<2;++i) {
    for(int j=0;j<n[i];++j) {
      if(j>0) f << ' ';
      f << (dest[i][j]+1);
    }
    f << '\n';
  }
}

int main() {
  srand(314159);
  genRandom(10,10);
  write("tel1.in");
  genRandom(100,107);
  write("tel2.in");
  genRandom(1000,1005);
  write("tel3.in");
  genTwoLists(1000);
  write("tel4.in");
  genRandom(10006,10000);
  write("tel5.in");
  genTwoLists(10000);
  write("tel6.in");
  genRandom(50000,1000);
  write("tel7.in");
  genRandom(1000,50000);
  write("tel8.in");
  genRandom(50000,49987);
  write("tel9.in");
  genTwoLists(50000);
  write("tel10.in");
}
