/* A worse solution for the problem Teleports, BOI'01 */
/* O(m(m+n)) */
/* Tomek Czajka, 25.05.2001 */

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

const char *fileIn = "tel.in";
const char *fileOut = "tel.out";

// number of teleports on each island
int n[2];
// teleport destinations for both islands
vector<int> dest[2];
// output - true if the teleport is in "sending" mode
vector<bool> sending[2];


void read() {
  ifstream f(fileIn);
  f >> n[0] >> n[1];
  for(int i=0;i<2;++i) {
    dest[i].resize(n[i]);
    for(int j=0;j<n[i];++j) {
      int x; f >> x;
      dest[i][j]=x-1; // we start numbering from 0
    }
  }
}

void write() {
  ofstream f(fileOut);
  for(int i=0;i<2;++i) {
    for(int j=0;j<n[i];++j) {
      f << (sending[i][j] ? '1' : '0');
    }
    f << '\n';
  }
}

void init() {
  sending[0].assign(n[0],false);
  sending[1].assign(n[1],true);
}

int findUseless() {
  vector<bool> receives(n[0],false);
  for(int i=0;i<n[1];++i)
    if(sending[1][i]) receives[dest[1][i]]=true;
  for(int i=0;i<n[0];++i)
    if(!sending[0][i] && !receives[i]) return i;
  return -1;
}

void calc() {
  for(;;) {
    int x=findUseless();
    if(x==-1) break;
    sending[0][x]=true;
    int y = dest[0][x];
    sending[1][y]=false;
  }
}

int main() {
  read(); // nteleports,destinations
  init(); // sending
  // now the island 1 is sending to island 0
  // but some receiving teleports on island 0 are not getting anything
  calc(); // and now we correct that
  write();
}
