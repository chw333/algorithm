/* solution checker for Teleports, BOI'01 */
/* check tel.out against tel.in */
/* Tomek Czajka, 24.05.2001 */

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <vector>
using namespace std;

const char *fileIn = "tel.in";
const char *fileOut = "tel.out";

// no of teleports on each island
int n[2];
// teleport destinations
vector<int> dest[2];
// is the teleport in "sending" mode?
vector<bool> sending[2];


// convert int to string
string st(int x) {
  if(x>9) return st(x/10)+char(x+'0');
  else return string()+char(x+'0');
}

void error(const string &err) {
  cout << "Error: " << err << "\n";
  exit(1);
}

void readIn() {
  ifstream f(fileIn);
  
  f >> n[0] >> n[1];
  for(int i=0;i<2;++i) {
    dest[i].resize(n[i]);
    for(int j=0;j<n[i];++j) {
      int x; f >> x;
      dest[i][j]=x-1;
    }
  }
}

void readOut() {
  ifstream f(fileOut);
  char c;
  
  for(int i=0;i<2;++i) {
    sending[i].resize(n[i]);
    for(int j=0;j<n[i];++j) {
      f >> c;
      if(!cin) error("Output too short");
      if(c!='0' && c!='1') error("Invalid character in output");
      sending[i][j] = (c=='1');
    }
  }
  f >> c;
  if(f) error("Output too long"); 
}

void check() {
  for(int i=0;i<2;++i) {
    vector<bool> receives(n[1-i],false);
    for(int j=0;j<n[i];++j) {
      if(sending[i][j]) receives[dest[i][j]]=true;
    }
    for(int j=0;j<n[1-i];++j) {
      if(sending[1-i][j] && receives[j])
        error("Teleport ("+st(1-i+1)+","+st(j+1)+") in sending mode receives");
      if(!sending[1-i][j] && !receives[j]) 
        error("teleport ("+st(1-i+1)+","+st(j+1)+") in receiving mode is useless");
    }
  }
}

int main() {
  readIn(); // n,dest
  readOut(); // sending
  check();
  cout << "Solution OK!\n";
}
