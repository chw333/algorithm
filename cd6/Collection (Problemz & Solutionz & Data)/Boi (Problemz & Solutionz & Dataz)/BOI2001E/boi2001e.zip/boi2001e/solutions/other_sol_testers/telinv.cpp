/* This program verifies if a file meets the input specification of */
/* the problem Teleports, BOI'01 */
/* Tomek Czajka, 24.05.2001 */

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cctype>
using namespace std;

const int MAX = 50000;

char next;
void read(istream &f) { next=f.get(); }
int n[2]; // number of teleports

void error(const char *err) {
  cout << "Error: " << err << "\n";
  exit(1);
}

void skipSpace(istream &f) {
  if(next==' ') read(f);
  else error("Expected space");
}

void skipEoln(istream &f) {
  if(next=='\n') read(f);
  else error("Expected END OF LINE");
}

int readInt(istream &f,int lower,int upper) {
  if(!isdigit(next) || next=='0') error("Expected integer");
  int r=0;
  while(isdigit(next)) {
    r=10*r+(next-'0');
    read(f);
    if(r>upper) error("Integer too big");
  }
  if(r<lower) error("Integer too small");
  return r;
}

int main(int argc,char *argv[]) {
  if(argc!=2) error("use telinv <filename>");
  ifstream f(argv[1]);
  read(f);
  n[0]=readInt(f,1,MAX);
  skipSpace(f);
  n[1]=readInt(f,1,MAX);
  skipEoln(f);
  for(int i=0;i<2;++i) {
    for(int j=0;j<n[i];++j) {
      if(j>0) skipSpace(f);
      readInt(f,1,n[1-i]);
    }
    skipEoln(f);
  }
  if(next!=EOF) error("Expected END OF FILE");
  cout << "OK!\n";
}
